import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { readVstestDiscoveryDiagnostic } from '../../tools/test/vstest-discovery-diagnostic.mjs';
const root='/workspace/FsusBlog';
const out=path.join(root,'.tmp/chain-3582-authenticated-transport',process.argv[2]??'working');
fs.mkdirSync(out,{recursive:true});
const sourceCommit=spawnSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).stdout.trim();
const workingTree=spawnSync('git',['status','--porcelain'],{cwd:root,encoding:'utf8'}).stdout;
if((process.argv[2]??'').startsWith('frozen-')&&workingTree)throw Error('frozen run requires clean tracked candidate: no execution');
const methods={
 "FsusBlog.Server.Tests.Unit.ArticleVaultExecutionTests.Executor_LoadsSealedReferenceAndDuplicateReplaysTerminalResult":1,
 "FsusBlog.Server.Tests.Unit.ArticleVaultExecutionTests.Executor_RejectsRevisionPermissionLifecycleAndDependencyDriftBeforeWriter":1,
 "FsusBlog.Server.Tests.Unit.ArticleVaultExecutionTests.Executor_StopsAtCancellationBoundaryWithoutStartingNextGroup":1,
 "FsusBlog.Server.Tests.Unit.ArticleVaultExecutionTests.Executor_FailsClosedOnWriterReceiptTamper":1,
 "FsusBlog.Server.Tests.Unit.ArticleVaultExecutionTests.Executor_FailsClosedOnResealedReceiptMismatch":9,
 "FsusBlog.Server.Tests.Unit.ArticleVaultExecutionTests.Executor_RejectsDuplicateOutboxAndAuditReferencesAcrossGroup":1,
 "FsusBlog.Server.Tests.Unit.ArticleVaultExecutionTests.Executor_PersistsCancelledTerminalWhenCancellationOccursInsideWriter":1,
 "FsusBlog.Server.Tests.Unit.ArticleVaultExecutionTests.Executor_PersistsCancelledTerminalWhenCancellationOccursDuringObservation":1,
 "FsusBlog.Server.Tests.Unit.ArticleVaultExecutionTests.Executor_StopsWhenPlanExpiresAfterObservationBeforeWriter":1,
 "FsusBlog.Server.Tests.Unit.ArticleVaultExecutionTests.Executor_RejectsExpiredPlanBeforeObservationOrWriter":1,
 "FsusBlog.Server.Tests.Unit.ArticleVaultExecutionTests.Executor_RecoversCommittedGroupAfterTerminalWriteFailureWithoutRepeatingWriter":1,
 "FsusBlog.Server.Tests.Unit.ArticleVaultExecutionTests.TerminalResultEquivalence_IgnoresOnlyCompletionTimestamp":1,
 "FsusBlog.Server.Tests.Unit.ArticleVaultExecutionTests.Payload_CannotCarryLifecycleRightsOwnerPathOrImportFallback":1,
 "FsusBlog.Server.Tests.Unit.ArticleVaultExecutionTests.Bundle_RejectsPayloadMembershipAndActualSourceByteMismatch":1,
 "FsusBlog.Server.Tests.Unit.ArticleVaultExecutionTests.GroupIdempotency_IsBoundToSiteVaultPlanGroupAndOperations":1,
 "FsusBlog.Server.Tests.Unit.ArticleVaultExecutionTests.ResultVerifier_RejectsResealedMembershipAndWriterReferenceTamper":1,
 "FsusBlog.Server.Tests.Unit.ArticleVaultExecutionTests.GroupVerifier_RejectsExecutedOperationInFailedAttemptLedger":1,
 "FsusBlog.Server.Tests.Unit.ArticleVaultExecutionTests.ExecutionSource_HasNoFilesystemWatcherImportOrDirectArticleMutationSidePath":1,
 "FsusBlog.Server.Tests.Unit.ArticleVaultExecutionTests.ExecutionBoundary_RejectsConstructorOnlyForbiddenReferences":8,
 "FsusBlog.Server.Tests.Unit.ArticleVaultExecutionTests.ExecutionBoundary_AcceptsBenignMethodsAndConstructors":1,
 "FsusBlog.Server.Tests.Unit.ArticleVaultExecutionTests.ExecutionBoundary_AcceptsCompiledValidationErrorsWithoutFilesystemAccess":2,
 "FsusBlog.Server.Tests.Unit.ArticleVaultRecoveryServiceRegistrationTests.ProtectedStageComposition_SharesSoleWriterStorageAndExistingKeysWithoutIo":1,
 "FsusBlog.Server.Tests.Unit.ArticleVaultRecoveryServiceRegistrationTests.ProtectedStageComposition_MissingOriginalOwnerLeavesRegistrationUnchanged":3,
 "FsusBlog.Server.Tests.Unit.ArticleVaultRecoveryServiceRegistrationTests.ProtectedStageComposition_RefusesDuplicateAndCompetingEncryptedStorage":2,
 "FsusBlog.Server.Tests.Unit.ArticleVaultRecoveryServiceRegistrationTests.EncryptedRecoveryComposition_RequiresProtectionAndUsesTheSoleStorageInstance":1,
 "FsusBlog.Server.Tests.Unit.ArticleVaultRecoveryServiceRegistrationTests.EncryptedRecoveryComposition_BindsExistingKeysToActualProtectionWithoutCreatingOrReadingKeys":1,
 "FsusBlog.Server.Tests.Unit.ArticleVaultRecoveryServiceRegistrationTests.BackupProtectionComposition_RequiresExistingKeyOwnerAndSharesTheActualProvider":1,
 "FsusBlog.Server.Tests.Unit.ArticleVaultRecoveryServiceRegistrationTests.ProductionComposition_ResolvesTheExistingPostgresCheckpointStoreWithinEachScope":1,

 'FsusBlog.Server.Tests.Unit.ArticleVaultRecoveryServiceRegistrationTests.RuntimeVaultSiteComposition_BindsProtectedStageOnlyWhenOriginalKeyOwnerExists':2,
 'FsusBlog.Server.Tests.Unit.ArticleVaultRecoveryServiceRegistrationTests.RuntimeWithoutExplicitVaultSite_DoesNotEnableProtectedStageEvenWithExistingKeys':1,
 'FsusBlog.Server.Tests.Unit.ArticleVaultAuthenticatedConflictReviewAdapterTests.HttpContextMapping_RequiresRealAdminSidInsteadOfOrdinaryAccountSid':2,
 'FsusBlog.Server.Tests.Unit.ArticleVaultAuthenticatedConflictReviewAdapterTests.AuthenticatedHost_MapsOnlyExactStoredDocumentAndPreservesCanonicalCurrentRefusal':1,
 'FsusBlog.Server.Tests.Unit.ArticleVaultAuthenticatedConflictReviewAdapterTests.MissingAuthenticatedAdminSession_RefusesBeforePrivateStoreRead':4,
 'FsusBlog.Server.Tests.Unit.ArticleVaultAuthenticatedConflictReviewAdapterTests.ScopeActorOrLivePermissionMismatch_RefusesWithoutCreatingAlternativeAuthority':5,
 'FsusBlog.Server.Tests.Unit.ArticleVaultAuthenticatedConflictReviewAdapterTests.CancelledHostRead_RefusesBeforeLookupAndMayRepeatAgainstSameCanonicalInputs':1,
 'FsusBlog.Server.Tests.Unit.ArticleVaultRecoveryHistoryTransportTests.ExactHistoricalRead_UsesCurrentPermissionAndOriginalReadersWithoutGrantsOrWrites':1,
 'FsusBlog.Server.Tests.Unit.ArticleVaultRecoveryHistoryTransportTests.EndpointAuthorization_RejectsBeforePrivateReads':2,
 'FsusBlog.Server.Tests.Unit.ArticleVaultRecoveryHistoryTransportTests.CrossScopeOrPermissionDrift_FailsClosedWithoutWriting':6,
 'FsusBlog.Server.Tests.Unit.ArticleVaultRecoveryHistoryTransportTests.ClosedPayloadAndFrame_RejectUnknownAmbiguousOrFallbackRequests':5,
 'FsusBlog.Server.Tests.Unit.ArticleVaultRecoveryHistoryTransportTests.MissingTrustedComposition_ReturnsRealUnavailableWithoutBreakingOtherAuthoring':1
};
const expected=78;
const names=Object.keys(methods);
if(names.length!==40||Object.values(methods).reduce((a,b)=>a+b,0)!==expected)throw Error('allowlist-count-invalid: no test execution');
if(process.env.FSUSBLOG_TEST_REDIS_DIAGNOSTICS)throw Error('unreviewed global diagnostic opt-in: no test execution');
const filter=names.map(n=>'FullyQualifiedName='+n).join('|');
if(!filter||!filter.split('|').every(n=>/^FullyQualifiedName=[A-Za-z0-9_.]+$/.test(n)))throw Error('positive-fqn-filter-invalid: no test execution');
const sourceFiles=['src/backend/Services/ArticleVault/ArticleVaultAuthenticatedConflictReviewAdapter.cs','src/backend/Infrastructure/Bootstrap/ArticleVaultRecoveryServiceCollectionExtensions.cs','src/backend/Infrastructure/Bootstrap/RuntimeDomainServiceCollectionExtensions.cs','tests/backend/Unit/ArticleVaultAuthenticatedConflictReviewAdapterTests.cs','tests/backend/Unit/ArticleVaultRecoveryServiceRegistrationTests.cs','tests/backend/Unit/ArticleVaultExecutionTests.cs','tests/backend/Unit/ArticleVaultRecoveryHistoryTransportTests.cs','tests/backend/Unit/ArticleVaultRecoveryCheckpointReaderTests.cs','tests/backend/Helpers/TestInfrastructure/EndpointSecurityTestHost.cs','tests/backend/Helpers/TestInfrastructure/RedisOperationFailureDiagnosticCollector.cs'];
const hashes=Object.fromEntries(sourceFiles.map(p=>[p,crypto.createHash('sha256').update(fs.readFileSync(path.join(root,p))).digest('hex')]));
const command=(argv,log)=>{
 const startedUtc=new Date().toISOString();const r=spawnSync('dotnet',argv,{cwd:root,encoding:'utf8',maxBuffer:64*1024*1024});
 fs.writeFileSync(path.join(out,log),String(r.stdout??'')+String(r.stderr??''));
 fs.writeFileSync(path.join(out,log+'.command.json'),JSON.stringify({argv:['dotnet',...argv],startedUtc,endedUtc:new Date().toISOString(),exitCode:r.status,signal:r.signal,error:r.error?.message??null},null,2)+'\n');
 if(r.error||r.signal||r.status!==0)throw Error('command failed; no next/test fallback: '+log);
};
const diagDir=path.join(out,'discovery');fs.mkdirSync(diagDir,{recursive:true});
command(['test','tests/backend/FsusBlog.Server.Tests.csproj','--configuration','Release','--no-build','--no-restore','--list-tests','--filter',filter,'--diag',path.join(diagDir,'union.txt')],'discovery.log');
const discovery=readVstestDiscoveryDiagnostic(diagDir,{expectedSource:path.join(root,'tests/backend/bin/Release/net10.0/FsusBlog.Server.Tests.dll')});
const selected=discovery.records.filter(r=>names.includes(r.fullyQualifiedName));
const actual=Object.fromEntries(names.map(n=>[n,selected.filter(r=>r.fullyQualifiedName===n).length]));
if(selected.length!==expected||names.some(n=>actual[n]!==methods[n]))throw Error('exact-case-count-mismatch: no test execution '+JSON.stringify(actual));
const preflight={sourceCommit,workingTree,sourceFiles:hashes,expectedCaseCount:expected,expectedMethods:methods,actualCaseCount:selected.length,actualMethods:actual,selected,filter,discoveryHostLogSha256:crypto.createHash('sha256').update(fs.readFileSync(discovery.file)).digest('hex'),fixtureReview:{selectedClasses:'original execution owner (21 methods/37 cases), original registration controls (7/10), new runtime/auth adapter controls and original historical endpoint controls; no collection/class/assembly fixtures',setup:'new adapter uses original pure checkpoint fixture and NSubstitute proposal/permission ports; exact refusal input not acquisition receipt. Original execution fixture uses controlled in-memory proposal/result stores and observation/writer ports with all owned CancellationTokenSources disposed, no hooks or external IO. Original/new RuntimeDI uses actual factory with owned unopened NpgsqlDataSource and SqlSugar port mock. Existing history uses original EndpointSecurityTestServer/TestServer and real AEDS encoder/auth pipeline, controlled claims/permission/store ports.',cleanup:'all selected server/client/message/response/DI scopes/data source and CancellationTokenSource use disposal; no physical network or DB connections, file/native handles or production keys',assemblyHook:'RedisOperationFailureDiagnosticCollector original opt-in absent'},heldAudits:false,replacementHarness:false};
fs.writeFileSync(path.join(out,'preflight.json'),JSON.stringify(preflight,null,2)+'\n');
console.log('preflight verified exact positive FQNs='+names.length+' cases='+selected.length);
command(['test','tests/backend/FsusBlog.Server.Tests.csproj','--configuration','Release','--no-build','--no-restore','--filter',filter,'--logger','trx;LogFileName=authenticated-transport.trx','--results-directory',out],'working-tests.log');
const trx=fs.readFileSync(path.join(out,'authenticated-transport.trx'),'utf8');
const counters=Object.fromEntries([...trx.match(/<Counters ([^>]*)/)[1].matchAll(/(\w+)="(\d+)"/g)].map(m=>[m[1],Number(m[2])]));
if(counters.total!==expected||counters.passed!==expected||counters.failed!==0||counters.notExecuted!==0)throw Error('exact execution case/count mismatch');
if(spawnSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).stdout.trim()!==sourceCommit)throw Error('candidate changed during run');
const assemblies=['FsusBlog.Server.Tests.dll','FsusBlog.Server.dll','FsusBlog.Core.dll','FsusBlog.Shared.dll'];
fs.writeFileSync(path.join(out,'result.json'),JSON.stringify({sourceCommit,counters,assemblies:Object.fromEntries(assemblies.map(f=>[f,crypto.createHash('sha256').update(fs.readFileSync(path.join(root,'tests/backend/bin/Release/net10.0',f))).digest('hex')])),qualification:false},null,2)+'\n');
console.log(JSON.stringify({sourceCommit,counters,output:out}));
