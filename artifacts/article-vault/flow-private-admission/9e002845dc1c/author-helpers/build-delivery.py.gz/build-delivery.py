import gzip, hashlib, json, pathlib, shutil, subprocess

scratch = pathlib.Path('/workspace/chain-1975-evidence/flow-private-recovery-20261011')
repo = pathlib.Path('/workspace/chain1975-runtime-attempt-borrow')
source = '9e002845dc1c7f6b3b69219b02fed7e1fc0903a2'
before = 'd8d0e93f913ceecf9c4946df3ad9b0c0283ab8d7'
relative = 'artifacts/article-vault/flow-private-admission/9e002845dc1c'
out = repo/relative
assert not out.exists()
def digest(b): return hashlib.sha256(b).hexdigest()
def put(path, b):
    dest=out/path; dest.parent.mkdir(parents=True,exist_ok=True); dest.write_bytes(b)
def js(path, value): put(path,(json.dumps(value,indent=2,ensure_ascii=False)+'\n').encode())
def gz(path,b): put(path,gzip.compress(b,mtime=0))
def git(*args): return subprocess.check_output(['git',*args],cwd=repo)
def show(sha,path): return git('show',sha+':'+path)

assert git('rev-parse','HEAD').decode().strip()==source
assert not git('status','--porcelain').strip()
for p in sorted(scratch.glob('*')):
    if p.is_file() and p.suffix=='.json': put('records/'+p.name,p.read_bytes())
    elif p.is_file() and p.suffix=='.log': gz('logs/'+p.name+'.gz',p.read_bytes())
    elif p.is_file() and p.suffix in ['.py','.sh','.cjs']:
        gz('author-helpers/'+p.name+'.gz',p.read_bytes())
    elif p.is_file() and p.name in ['new-admission-controls.txt','approved-admission-controls.txt','reader-controls.txt','preapproval-composite.test.ts','executed-composite.test.ts','proposed-private-admission.patch','pr-before-body.md']:
        gz('author-history/'+p.name+'.gz',p.read_bytes())
for p in sorted(scratch.glob('*-run/topology.jsonl')):
    put('topology/'+p.parent.name+'.jsonl',p.read_bytes())
put('records/source-remote-readback.txt',(scratch/'source-remote-readback.txt').read_bytes())

packages=[
 ('reviewer/independent-review-0324e7adb18f-portable.zip','2ebd1847308a3ddcd12a3e7bfaa637ec8a04177d5ed9f9aaed59c491f02a7fa1','libfile_5081d9affd908191a8c3c85d1a63ebec'),
 ('reviewer/f1-rerun/independent-0324-probe-supplement.zip','1968063b05967a4d6d40603159f90105aeb8f966299da12167775667295c6631','libfile_706196d672188191bfe6bd1582bfe46d')]
for path,expected,library in packages:
    b=(scratch/path).read_bytes(); assert digest(b)==expected;put('reviewer/'+pathlib.Path(path).name,b)
original=scratch/'reviewer/original/independent-review-0324e7adb18f'
supplement=scratch/'reviewer/f1-rerun/original/independent-0324-probe-supplement'
for name in ['review.json','probe-selector-failure.json','public-state-probe.ts','prepare-public-state-probe.py']:
    p=original/name
    if p.suffix in ['.ts','.py']:gz('reviewer/original/'+name+'.gz',p.read_bytes())
    else:put('reviewer/original/'+name,p.read_bytes())
for name in ['manifest.json','execution-verification.json','original-probe-binding.json','single-probe-execution.json','single-probe-report.json','selection-verification.json']:
    put('reviewer/supplement/'+name,(supplement/name).read_bytes())
manifest=json.loads((supplement/'manifest.json').read_text())
for entry in manifest['entries']:
    b=(supplement/entry['path']).read_bytes();assert len(b)==entry['bytes'] and digest(b)==entry['sha256']
probe=(original/'public-state-probe.ts').read_bytes()
assert digest(probe)=='e6f363c70dc2c02bc48c90b0c222459df456b2df4d24905d8daf0a6e8eb7a9de'
assert probe== (supplement/'original-probe.ts').read_bytes()
assert probe in show(source,'tests/frontend/unit/composables/useImageUploadRuntime.test.ts')
js('reviewer/package-binding.json',{'packages':[{'libraryId':library,'file':pathlib.Path(path).name,'sha256':expected} for path,expected,library in packages], 'supplementEveryManifestEntryVerified':True,'firstPackageHasManifest':False,'originalF1ByteIdentical':True,'currentIndependentReview':'PENDING','qualification':False})

binding=json.loads((scratch/'source-binding.json').read_text())
for item in binding['fourPaths']:
    for phase,sha in [('pre',before),('post',source)]:
        b=show(sha,item['path']);assert digest(b)==item[phase]['sha256']
        gz('source/'+phase+'/'+item['path']+'.gz',b)
patch=git('diff','--binary',before,source)
gz('source/four-path-source.patch.gz',patch)
subprocess.run(['git','apply','--reverse','--check','-'],input=patch,cwd=repo,check=True)
js('source/reverse-check.json',{'source':source,'before':before,'patchSha256':digest(patch),'command':['git','apply','--reverse','--check','-'],'exitCode':0,'qualification':False})
for path in ['.tmp/gate-logs/preflight.json','.tmp/release-evidence/test-plan.json']:
    assert (repo/path).is_file();put('actual-producer/'+path.removeprefix('.tmp/'),(repo/path).read_bytes())

prior='artifacts/article-vault/flow-ack-recovery/0324e7adb18f'
prior_receipts=['records/preserved-history-binding.json','records/prefix-correct-setup.json','records/prefix-correct-setup-report.json','records/prefix-five-proven-report.json','records/negative-five-source-binding.json','records/prefix-five.json','records/whole-history.json']
historical=[]
for path in prior_receipts:
    b=show(before,prior+'/'+path); historical.append({'commit':before,'path':prior+'/'+path,'sha256':digest(b),'bytes':len(b),'oldSourceRerunHere':False})
js('records/negative-history-binding.json',{'priorReceipts':historical,'priorManifest':{'commit':before,'path':prior+'/manifest.json','sha256':digest(show(before,prior+'/manifest.json'))},'original28And17':'immutable prior source-bound receipts; all45 current ordinary controls PASS; not rerun old source here','original9And5':'immutable previous stage negative controls preserved, current all14 PASS','qualification':False})
js('approval-and-boundary.json',{
 'parentThread':'01a1142b-a0b5-7419-a4df-a8bbe54660dd','approval':'parent explicitly approved minimal read-only module export before source implementation; no permission blocker remains',
 'approvedSignature':'getImageUploadRuntimeAdmissionError(runtime: ReturnType<typeof useImageUploadRuntime>): ReturnType<typeof createAppError> | null',
 'implementation':'factory-only WeakMap registration original returned instance -> reader of same original private shallowReactive holder; no second ledger, public-flag input, stale snapshot cache or mutating export',
 'reader':'fresh sanitized code/message only; no cause/details/ACK/token/File/callback payload; unknown/clone/native proxy/inherited fail closed',
 'flow':'capture original instance; query before clear/start/resume/context assignment/capture; public cleanupRequired display-only; null local admission is not canonical business release',
 'rawIdentity':'nested original Files/SDK bindings/promises/cause/ACK remain raw; shallow holder replaces original private fields, does not duplicate obligations',
 'allowedTransportControl':'one precomplete real mocked abort ACK while original work pending; complete0; not postACK business cleanup',
 'postAck':'zero abort, duplicate init/complete or receiver release in all actual original ACK failure controls',
 'prohibitions':'no Writer/#4153, Shared/#4155, #4170, server activation, migration, held QA, production DB, issue closure, merge, deployment or package publication',
 'qualification':False})
js('author-history/preparation-failures.json',{
 'admission-before':'wrong repository cwd failed node_modules resolution before tests; admission-before-correct actual6 selected',
 'exploratory-approved':'wrong edit cwd stopped before product edit; shell repeated unchanged source155PASS/6FAIL; historical repeat-before despite label',
 'finalize-prefix':'historical helper failed missing manifest in first reviewer package, before product restoration/cleanup; never rerun as active helper',
 'verify-current-first-attempt':'author aggregation assertion expected TAP # prefix; actual Node runner uses Unicode info prefix; exit1 before any cleanup. Corrected parser accepts actual tests37/pass37/fail0; successful complete verification recorded.',
 'draftNewSix':'first six new oracles refined only to parent-approved publicflag display-only and sanitized diagnostics; both versions preserved. Original154/F1/9/5 and first154 file bytes unchanged.',
 'uncommittedExploratory':'161PASS then167PASS are history only; formal evidence is frozen9e167PASS with actual hooks',
 'proposalFiles':'proposed-contract.json/proposed patch and prior proposed-source are initial unapproved design history, not final implementation or permission state',
 'qualification':False})
js('reviewer-handoff.json',{
 'to':'01a1219d-1a8a-7640-be37-1002c0f51014','viaParent':'01a1142b-a0b5-7419-a4df-a8bbe54660dd','delivery':'prepared for parent forwarding; no outbound cross-thread tool available; not claimed delivered',
 'source':source,'tree':binding['tree'],'branch':binding['branch'],'draftPr':'https://github.com/Ozwasyd/FsusBlog/pull/4151','publicationHead':'artifact-only descendant supplied by final response and PR, source bytes unchanged',
 'previousVerdict':'0324 independent original154PASS but MUST_FIX F1; initial selector0 FAIL/behavior UNRUN; supplemental original probe actual1FAIL. Author also reproduced unchanged original probe1FAIL; capture remains1 and late assertions UNRUN.',
 'currentVerdict':'author ordinary167PASS only; independent F1 disposition PENDING',
 'originalProbe':'reviewer/original/public-state-probe.ts.gz; lossless1970 bytes; also unchanged in committed runtime test',
 'exactPattern':'Independent Flow recovery public flag reset must not clear or replace original File context$',
 'reproduction':'official documented preflight and local FsusUI setup; original Vitest list before run; use existing runner/setup hooks and explicit topology env; run commands in records/f1-after.json and records/focused.json; no selector fallback/oracle change',
 'reviewChecklist':['single factory registration + original same private state; no extra obligation/cache','original runtime captured by Flow before admission, before all replacement/capture paths','fresh diagnostic contains no mutable original error or payload','unknown/clone/proxy/inherited fail closed before property trap/capture','original154/F1/9/5 byte/fixture retention; full167 execution hooks and PID departure','postACK zeroabort; precomplete cancellation actual separate abortACK not receiver release','display flagfalse/true, fresh current anchor, secondFlow, options.runtime substitution, normal void/batch and reactive cancellation controls'],
 'heldGates':'all product/server/native/browser/receipt/custody/cohort/race/security/migration/QA PAUSED/UNRUN; no whole-chain acceptance',
 'qualification':False})
old_status=show(before,prior+'/issue-status.md').decode()
table=old_status[old_status.index('| Issue |'):]
table=table.replace('current ordinary runtime138/API16','current ordinary runtime151/API16')
table=table.replace('plus current local ACK consumer recovery.','plus current local ACK consumer recovery and private Flow admission. Current F1 repair has author167PASS; same-reviewer verification remains pending.')
put('issue-status.md',('''# Entire ownership remains OPEN

Current frozen source9e002845dc1c7f6b3b69219b02fed7e1fc0903a2 has author ordinary167PASS
(runtime151/API16), original2 positive and37 prerequisite PASS. Original154/140/139,
original9/5 and old45 controls retained. Original F1 reproduced1FAIL before, same
oracle1PASS after. Independent current review remains PENDING with same reviewer
01a1219d-1a8a-7640-be37-1002c0f51014. Prior0324 overall MUST_FIX remains history.
The approved read-only original-instance admission reader establishes local Flow
admission only, not canonical business receive/release. Types244/244 and old Refs
footer remain FAIL. No terminal migration or product qualification resumed.

'''+table).encode())
put('README.md',('''# F1 private Flow admission — author delivery, independent review pending

冻结源码 `9e002845dc1c7f6b3b69219b02fed7e1fc0903a2`，tree
`9b8b0857444bccec3ab1a276385712843b75bd61`；起始 origin/master
`9d72a1c93b297f719d8695a642cdfb1615cf1d51`。原分支
`codex/chain-1975-runtime-attempt-borrow`，原 draft PR
[4151](https://github.com/Ozwasyd/FsusBlog/pull/4151)。发布 HEAD 是该源码的仅证据后继，
精确 SHA 由 PR 和最终交付给出；本目录 manifest 绑定全部交付字节，不自称产品资格。

相对 `d8d0e93f913ceecf9c4946df3ad9b0c0283ab8d7`，源码提交只改四个既有路径：
原 runtime、Flow、runtime unit tests、现行 architecture overview。整个 PR 含继承实现
和历史证据，不能描述成只有四文件。本轮修复公开 cleanupRequired 可写导致 Flow
丢弃/替换原 File/context 的 F1。父任务批准的唯一新增 export 是只读
`getImageUploadRuntimeAdmissionError(runtime)`，factory 私有 WeakMap 绑定原返回实例
和原有私有状态 reader；Flow 固定捕获该实例，clear/start/resume/context/capture 前读取。
未知、clone、proxy、继承对象 fail closed。公共 ref 仅显示；返回 null 只代表本地准入。
诊断为新的 code/message，不暴露真实 cause/token/ACK/File/可变闭包。

原独立报告为 `0324` 的154项 PASS但总体 MUST_FIX F1。初始 `^leaf$` 选择器匹配0、
行为 UNRUN；原 reviewer 后续原 probe 实际1FAIL。作者未改原 oracle，只用严格发现后的
后缀锚定 pattern 复现1FAIL，修后同一 probe1PASS。修前原 F1 三个 File/context 断言失败，
硬 message 断言实际 `upload_attachment_input_invalid`，capture仍1；后续 snapshot/cause/
init/complete/zeroabort 断言 UNRUN。另加有效当前 canonical anchor 控制才独立证明修前
capture1→2和实际本地 SDK source变化；修后 capture/source 保持原值。两类证据不混用。

| 冻结源码实际检查 | 结果 |
| --- | --- |
| 原 Vitest discovery/full runtime+API | 167唯一名称，167PASS/0FAIL/0SKIP，167对真实hooks，workers退出 |
| 原 F1严格单项 | 1PASS，150项不在selector内，1对hooks |
| 原九项/原两项positive | 9PASS / 2PASS，各自hooks匹配 |
| 原154/140/139、九/五、old45 | 原完整文件去除新增块/import后字节一致；当前全部PASS |
| 新 admission/reader | 6+6 PASS，false/true、clear/start/resume/capture、File/context、实例和负控 |
| 原37 prerequisite / preflight / style | PASS，命令/exit/run identity及实际producer输出归档 |
| 本次源码 commit-range | PASS，d8..9e |
| 全量 application types | FAIL exit2；current/baseline244/244，完整多行诊断新增0/移除0 |
| 全继承 history | FAIL，旧9defbe367缺Refs；未改历史 |

精确命令、cwd、UTC、run identity、source SHA、exit code见 [records](records/current-runs.json)
及各同名 command record。原 runner `vitest.config.ts`、既有 setup hooks及锁定依赖未改；
实际 local FsusUI `0e5c56050e8dd3e9ca3735078489d35a0bb6e3d2`、Vue3.5.33、
官方 Node24.16.0、Vitest4.1.11、TS6.0.3、HappyDOM20.9。wrapper记录
`FSUSBLOG_USE_LOCAL_FSUSUI=1` /实际 SDK root、workers1和明确 topology env。
复核从现行仓库 setup/preflight开始，再执行 records中的 discovery/focused/f1命令；
归档 helper是本次执行历史，不是替代 runner 或 qualification authority。

新增原 F1+12控制，原154和原9/5绝未更改。最初新增六项 draft oracle 只为遵守父任务
批准的 display-only flag与sanitized diagnostic协议而调整；draft/approved完整字节都以
lossless gzip保留。错误cwd、重复修前执行、缺manifest的旧helper失败、聚合脚本误读
Node输出前缀等失败不删除/升级；具体见 [history](author-history/preparation-failures.json)。
预提交161/167 exploratory PASS不是冻结receipt。老28/17和九/五负史引用已提交原始
SHA/bytes，未伪称本轮重跑旧源码。原两个 reviewer ZIP SHA及补充manifest逐项已验证。

26个自建 dependency links和本轮两份临时隔离fixture已清理；锁定cache及SDK源码保留。
patch反向check PASS，四路径前后 Git blob/sourceimages和source SHA绑定。
本提交后还将从发布Git bytes逐项核验manifest并保持四源码blob完全一致。

[同一reviewer交接](reviewer-handoff.json) 仅交给父任务转发，当前独立复核 PENDING。
[全部16项状态](issue-status.md) 保持OPEN：#1975终态cutover/build/receipt/isolated apply/
repeat/真实backup+restore仍PAUSED，#1976等待实际#1975。其余执行与tracking关口逐项列明。
canonical业务receiver/current receipt/host缺失，#4170 IsSuccess/Recorded不代表浏览器
接收释放或physicaldelete。所有ACK后失败控制zeroabort；另一个precomplete取消控制的
真实mocked abortACK仅属transport取消。没有业务cleanup、Writer/#4153、Shared/#4155、
#4170或server activation，没有production DB/held QA/issue关闭/merge/auto-merge/包发布/
deploy/跨链冲突处理。原回调、正常void及batch控制PASS不授予业务release。
''').encode())
entries=[]
for p in sorted(out.rglob('*')):
    if p.is_file():
        b=p.read_bytes();entries.append({'path':str(p.relative_to(out)),'sha256':digest(b),'bytes':len(b)})
js('manifest.json',{'source':source,'tree':binding['tree'],'qualification':False,'entries':entries})
print(json.dumps({'directory':relative,'manifestEntries':len(entries),'source':source,'files':len(entries)+1}))
