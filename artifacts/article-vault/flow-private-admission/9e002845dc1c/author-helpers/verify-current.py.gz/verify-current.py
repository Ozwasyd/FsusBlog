import collections, datetime, hashlib, json, os, pathlib, subprocess

root = pathlib.Path('/workspace/chain-1975-evidence/flow-private-recovery-20261011')
repo = pathlib.Path('/workspace/chain1975-runtime-attempt-borrow')
source = '9e002845dc1c7f6b3b69219b02fed7e1fc0903a2'
def read(name): return json.loads((root / name).read_text())
def write(name, value): (root / name).write_text(json.dumps(value, indent=2) + '\n')
def sha(data): return hashlib.sha256(data).hexdigest()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip() == source
results = {}
for label, expected, head in [
    ('focused', (167, 0, 0), source), ('f1-after', (1, 0, 150), source),
    ('nine-after', (9, 0, 142), source), ('positive', (2, 0, 149), source),
    ('f1-before', (0, 1, 138), 'd8d0e93f913ceecf9c4946df3ad9b0c0283ab8d7'),
    ('admission-before-correct', (1, 5, 139), 'd8d0e93f913ceecf9c4946df3ad9b0c0283ab8d7'),
    ('baseline-composite', (155, 6, 0), 'd8d0e93f913ceecf9c4946df3ad9b0c0283ab8d7')]:
    report = read(label + '-report.json'); command = read(label + '.json')
    actual = tuple(report[x] for x in ['numPassedTests', 'numFailedTests', 'numPendingTests'])
    assert actual == expected, (label, actual)
    assert command['head'] == head and command['qualification'] is False
    assert command['exitCode'] == (1 if expected[1] else 0)
    cases = [a for suite in report['testResults'] for a in suite['assertionResults'] if a['status'] in ['passed', 'failed']]
    events = [json.loads(line) for line in (root / (label + '-run/topology.jsonl')).read_text().splitlines()]
    starts = [e for e in events if e['event'] == 'start']; finishes = [e for e in events if e['event'] == 'finish']
    assert len(cases) == len(starts) == len(finishes) == sum(expected[:2])
    key = lambda e: (e['workerProcessId'], e['task']['id'], e['task']['name'])
    assert collections.Counter(map(key, starts)) == collections.Counter(map(key, finishes))
    assert collections.Counter(a['title'] for a in cases) == collections.Counter(e['task']['name'] for e in starts)
    pids = sorted({e['workerProcessId'] for e in starts})
    assert all(not pathlib.Path('/proc', str(pid)).exists() for pid in pids), pids
    results[label] = dict(passed=actual[0], failed=actual[1], outsideSelector=actual[2], actualStarts=len(starts), actualFinishes=len(finishes), workerPids=pids, allWorkersExited=True, source=head, commandRecord=label+'.json')

full = read('focused-report.json')
names = [a['fullName'] for s in full['testResults'] for a in s['assertionResults']]
roster = read('discovery-roster.json')
assert len(names) == len(set(names)) == len(roster) == 167
assert set(names) == {r['name'].replace(' > ', ' ') for r in roster}
before = read('baseline-composite-report.json')
original = [a for s in before['testResults'] for a in s['assertionResults'] if 'Flow private recovery admission' not in a['fullName'] and 'Independent Flow recovery public flag reset' not in a['fullName']]
assert len(original) == 154 and all(a['status'] == 'passed' for a in original)
assert {a['fullName'] for a in original} <= set(names)
assert read('current-test-retention.json')['allOriginal154CompleteFileBytesAfterOnlyNewBlocksAndImportRemoval']
for label in ['preflight', 'prerequisites', 'style', 'current-range', 'discovery']:
    assert read(label+'.json')['head'] == source and read(label+'.json')['exitCode'] == 0
prerequisite_log = (root/'prerequisites.log').read_text()
assert 'tests 37' in prerequisite_log and 'pass 37' in prerequisite_log and 'fail 0' in prerequisite_log
types = read('application-type-delta.json')
assert types['currentCount'] == types['baselineCount'] == 244 and types['added'] == types['removed'] == [] and not types['fullTypecheckPassed']
assert read('whole-history.json')['exitCode'] == 1

write('current-runs.json', {
    'source': source, 'tree': subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=repo,text=True).strip(),
    'qualification': False, 'authorVerificationOnly': True, 'independentCurrentReview': 'PENDING same original reviewer',
    'runs': results, 'discovery': {'unique':167,'exactExecutedRosterMatches':True,'fallback':False},
    'original154': 'byte-identical after removing only appended new blocks and approved import; passed before and after',
    'original9And5': 'unchanged assertions; current all PASS; original negative history retained at prior committed artifacts',
    'originalF1': {'sha256': read('current-test-retention.json')['originalF1Sha256'], 'before':'actual 1FAIL: three context/File assertions fail; hard error-message assertion actual upload_attachment_input_invalid; capture remains1; later snapshot/cause/init/complete/zeroabort assertions UNRUN', 'after':'same unchanged oracle actual1PASS; all assertions reached', 'selector':'explicit suffix anchor selects exact1, old ^leaf$ selector0 is retained as FAIL/behavior UNRUN'},
    'freshCurrentAnchorControl': 'separate new test: real original current canonical anchor; before actual capture1->2/local SDK source mutation, after no additional capture/source mutation; ordinary local unit environment only',
    'approvedNewControls': {'newAdmission':6,'newReader':6,'originalF1':1,'allCurrentPassed':True,'draftSixOracleChange':'only six newly authored draft controls updated for parent-approved display-only flag and sanitized diagnostic; original154/F1/9/5 untouched; both drafts archived'},
    'preflight':'PASS actual producer outputs archived', 'prerequisites':'37PASS', 'style':'PASS', 'currentRange':'PASS d8..9e',
    'fullApplicationTypes':types, 'wholeInheritedHistory':'FAIL old 9defbe367fc3ce869eef7a41aa29d9be3d1d5c37 missing Refs footer; no rewrite',
    'setupAndExploratoryFailures':'admission-before wrong cwd launches no tests; exploratory-approved is unchanged-source repeated BEFORE after failed edit; initial finalize-prefix helper failed missing first reviewer manifest; all retained, not promoted',
    'heldGates':'PAUSED/UNRUN: server/native/browser/product/receipt/custody/cohort/race/security/migration/QA; no canonical business receiver release or postACK abort',
})

# Validate every owned disposable link before removing any; preserve shared cache and SDK sources.
ui = pathlib.Path('/workspace/chain1975-runtime-borrow-fsusui/vue/packages/node_modules')
front = repo/'src/frontend/node_modules'
baseline = pathlib.Path('/workspace/chain1975-runtime-borrow-type-baseline/src/frontend/node_modules')
cache = pathlib.Path('/workspace/chain1975-intent-source-alias-verification/src/frontend/node_modules')
links = sorted(p for p in ui.rglob('*') if p.is_symlink())
assert len(links) == 24 and front.is_symlink() and baseline.is_symlink()
info = []
for p in links + [front, baseline]:
    target = str(p.readlink())
    assert target.startswith(str(front)+'/') or target.startswith(str(cache)), (p,target)
    info.append({'path':str(p),'target':target})
locks = []
for filename in ['package.json','package-lock.json']:
    paths = [repo/'src/frontend'/filename, cache.parent/filename, baseline.parent/filename]
    data = [p.read_bytes() for p in paths]; assert data[0] == data[1] == data[2]
    locks.append({'filename':filename,'sha256':sha(data[0]),'bytes':len(data[0]),'allThreePathsIdentical':True,'paths':list(map(str,paths))})
write('locked-inputs.json', {'files':locks,'noPackageOrLockMutation':True,'qualification':False})
tmp = root/'prerequisite-tmp'
fixtures = [{'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(tmp.rglob('*')) if p.is_file()]
assert len(fixtures) == 2
for p in links: p.unlink()
for p in sorted((p for p in ui.rglob('*') if p.is_dir()), key=lambda p: len(p.parts), reverse=True): p.rmdir()
ui.rmdir(); front.unlink(); baseline.unlink()
import shutil
shutil.rmtree(tmp)
assert cache.is_dir() and not ui.exists() and not front.exists() and not baseline.exists()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).strip()
write('cleanup.json', {'timeUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'ownedLinksRemoved':26,'links':info,'ownDisposableFixturesRemoved':fixtures,'allRecordedWorkersExited':True,'sharedLockedCachePreserved':True,'sdkSourcePreserved':True,'productWorktreeCleanBeforeEvidence':True,'qualification':False})
print(json.dumps({'focused':results['focused'],'F1':results['f1-after'],'cleanup':26}))
