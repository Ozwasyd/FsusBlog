## Linked Issue

Refs #1975

当前 draft/WIP。相关工作：[AssetId seal #1976](https://github.com/Ozwasyd/FsusBlog/issues/1976)、[runtime #2258](https://github.com/Ozwasyd/FsusBlog/issues/2258)、[business coordination #2263](https://github.com/Ozwasyd/FsusBlog/issues/2263)。这些 issue 均未终态验收或关闭。

## Scope Summary

- 原调用链在 raw uploadFile 返回后才 await onFileUploaded，消费者失败越过 runtime 的 ACK recovery catch。本次把该消费者移到原 onSessionReady 回调及已有有限 withSession scope 中等待；失败/取消/过期/旧owner结果由原 runtime 先保留真实 ACK、snapshot、first error、generation/uploadId 与原 binding，再释放借用。
- parent 已批准且本次只扩展一个公开签名：`onSessionReady?: (borrow: ImageUploadSessionBorrow, completionUrl: string) => void | Promise<void>`。第二参由 runtime 在同一原操作严格验证 actual complete ACK 后给出，冻结的 ACK副本提供真实 URL，caller不能供应或构造。原单参 callback、正常 fulfilled void 和 batch success兼容；没有 canonical business receive/release 语义。
- 本次相对 `22813e9b81db72a0d01b1a0752551a1f96ab9c89` 只改原runtime、原Flow、既有runtime unit tests、current architecture overview四个既有路径；另一个提交只增加104个证据文件。整个 PR还包含继承实现与多阶段证据，不能将整个PR描述成四文件或已独立验收的变化。
- 测试源码 `0324e7adb18f8aecfa870e86dec1153046a9f782`，tree `168b91f10b5713fdc11d723b4b058b4630e07eb8`；发布HEAD `d8d0e93f913ceecf9c4946df3ad9b0c0283ab8d7`。103项manifest逐项从发布Git bytes核验，末提交源码blob完全不变，patch reverse-check通过。起始origin/master `9d72a1c93b297f719d8695a642cdfb1615cf1d51`；branch `codex/chain-1975-runtime-attempt-borrow`。
- 没有新增loan/ledger/global receipt/local verified business flag/token持久化/实际cleanup/DI或transport activation；Writer/#4153、cleanup business/#4170、Shared/#4155和API transport由原owner保持，本次未动。

## Change Classification

- [x] Behavior change
- [ ] Format-only
- [ ] Naming-only
- [ ] Generated output
- [x] Public contract change
- [ ] External naming exception
- Contract impact: compatible

## Tests Run

- [ ] `./tools/test.sh fast`
- [ ] Targeted backend tests: held，未恢复。
- [x] Targeted frontend checks: frozen源上154PASS(runtime138/API16)，0FAIL/0SKIP；original runner list严格发现154唯一名称，真实setup154start/154finish匹配，worker已退出；原2positive PASS。
- [x] Other: original37 prerequisite controls、preflight、runtime/Flow/API style和本次完整commit-range PASS。full application types仍FAIL exit2/2、244/244、全段多行诊断差异新增0/移除0；whole inherited history仍FAIL，旧9defbe367缺Refs。

原140/139测试字节保留，只插入14个case；原九个archived failure探针全文和SHA保持不变。原九在当前修前22813真实9FAIL/0PASS，修后同名9PASS；新增五在同一修前产品源码4FAIL/1PASS，当前5PASS。老28/17修前receipt保持原绑定，本stage未伪称重跑；当前154中45个原控制全部PASS。

第一次prefix-nine设置路径错误，不能作9项复现；prefix-correct-setup才是真实9FAIL。exploratory-extra153PASS/1FAIL是新增替换owner测试误写初始空source，修正为比较实际原source；原140/9未改。首轮正式PASS缺topology env，保留记录；带真正hooks的focused-proven/positive-proven完成复跑。verbatim控制块末尾空行的staging失败保留，以lossless gzip归档而未裁剪原字节。cleanup的两次局部断言停止也保留，最终27自建links、负控worktree及ownTMPDIR实际清理，共享锁定cache保留。

## UI Evidence

- [ ] Screenshots or video attached for UI changes
- [ ] Mobile layout checked
- [ ] Dark mode checked
- [x] Accessibility and reduced-motion impact considered

本次为非视觉runtime协议变化。真实local FsusUI代码及原pending owner/editor参与普通HappyDOM/Vitest夹具；不构成native/browser/product acceptance。held视觉/产品关口未运行。

## Coding Convention

- [x] C# mother-style mapping checked
- [x] Formatter/linter run
- [x] No tool default overrides repository style
- [x] Mechanical formatting separated from logic
- [x] `.git-blame-ignore-revs` updated when applicable
- Formatter identity: none
- Formatter version: none
- Formatter command: none
- Formatter idempotence evidence: none
- Blame-ignore revision: none

## External Naming Exception

- Exceptions manifest: none

## Documentation / Intent

- [x] Public API docs updated
- [x] Ownership/security/performance intent updated
- [x] Historical handoff archived or source-of-truth updated
- [x] TODO/FIXME references valid issues

`docs/architecture/overview.md`维护现行callback/finite-access/local-recovery边界；候选evidence和reviewer handoff为历史/提议交接，不是第二份业务账本。

## Compatibility And Risk

- [x] Cross-language coding conventions reviewed
- [x] Document lifecycle updated: stable facts are current; issue handoffs are historical/proposed; generated docs identify their producer
- [x] External wire / ABI / database / third-party names preserved or explicitly adapted
- [x] Public API impact reviewed
- [x] AEDS frame / binary contract impact reviewed
- [x] Database migration impact reviewed
- [x] Security, auth, moderation, PoW, or privacy impact reviewed
- [x] Docs updated or a reason is recorded below
- [x] Known limitations updated if applicable

这些review项描述本次四路径差异；不升级继承PR范围或held产品验收。唯一公开变化为已批准的同一实际ACK URL第二参；原File/intent/borrow/provider约束不放宽。成功void仅为callback fulfilment。消费者物理永久pending时，执行仍pending，原有限scope撤销access/signal；没有虚构物理取消、任意RPC timeout或超时释放授权。ACK后控制路径zeroabort/reinit/recomplete，拒绝重入/替换/延迟结果写入另一owner。

## Performance Claim

- Claim level: none
- Evidence path: none
- Non-goals: 性能、heap/custody、产品可用性、native/browser及全部held资格。

## Release Note

- Audience: none
- Category: none
- Summary: none

## Generated Output

- Generator source: none
- Generated outputs: none
- Digest/evidence: none
- Automation identity: none

## Rollout / Rollback

- Rollout: 仅隔离branch及原draft PR，等待同一原reviewer有界独立复验；不得merge/auto-merge/发布包/部署/关闭issue。
- Rollback: 若独立复验或真实集成发现回归，以正常revert `0324e7adb18f8aecfa870e86dec1153046a9f782` 回滚本次源码；回滚不授予cleanup/接收/释放/reupload权限。
- Deferred work: canonical recovery receiver/current business receipt及原Writer/host integration仍缺；独立审查交接给同一thread `01a1219d-1a8a-7640-be37-1002c0f51014`。本环境无cross-thread dispatch工具，handoff已备妥交由parent，不宣称已独立审查或已送达。
- Known limitations: full types244项、旧9def Refs footer、非协作callback物理pending；#1975终态cutover/build/receipt/isolated apply/repeat/真实backup+restore仍PAUSED，#1976等待实际#1975。全16项执行/跟踪关口开放。

## Notes For Reviewers

- 本次无C#/wire/ABI/schema/auth/PoW/隐私/DB/视觉改动，相关checkbox表示边界已核对，不表示实际产品/安全/迁移资格。普通证据不是governed generated contract；非机械change无需formatter idempotence/blame revision；本次无注册external naming例外。
- real canonical receiver/release ACK和当前业务receipt缺失，保留义务仅在原runtime/Flow实例内。#4170 IsSuccess或Recorded不能当浏览器接收/释放ACK，不证明physicaldelete。没有receiver时不能用localreset/loanrelease/cancel/void成功放行原failure recovery。
- prior c93独立PASS仅绑定source c93c4c37a58dd66fde473aa885552ea4663d4af3、metadata0c1576、139 ordinary tests及old45；不是本次0324e7adb fix的review。原独立包Library libfile_ed7d4c31112c819187b584ee67d7b636，ZIP SHA256fb2d0cf509872603a88c7503d38252fc2836693b09d97fed4c1c6c1baaf3cdfb，review.json SHA256be515c87b497261a4083af3d178d1bcf1d012e6e1bc4b5db602c814f975aa195；历史selector失败/dependent UNRUN也未升级。
- server/native/browser/product/receipt/custody/cohort/race/security/migration/held QA持续PAUSED/UNRUN；无production DB授权，缺真实backup时destructive contract不受支持。无兄弟PR merge、猜测commit消费、跨链冲突解决或global barrier后的最终review/merge。
- [交付说明及精确命令](https://github.com/Ozwasyd/FsusBlog/blob/d8d0e93f913ceecf9c4946df3ad9b0c0283ab8d7/artifacts/article-vault/flow-ack-recovery/0324e7adb18f/README.md) · [原runner报告](https://github.com/Ozwasyd/FsusBlog/blob/d8d0e93f913ceecf9c4946df3ad9b0c0283ab8d7/artifacts/article-vault/flow-ack-recovery/0324e7adb18f/records/current-runs.json) · [完整16项状态](https://github.com/Ozwasyd/FsusBlog/blob/d8d0e93f913ceecf9c4946df3ad9b0c0283ab8d7/artifacts/article-vault/flow-ack-recovery/0324e7adb18f/issue-status.md) · [四路径绑定](https://github.com/Ozwasyd/FsusBlog/blob/d8d0e93f913ceecf9c4946df3ad9b0c0283ab8d7/artifacts/article-vault/flow-ack-recovery/0324e7adb18f/records/source-binding.json) · [同一reviewer交接材料](https://github.com/Ozwasyd/FsusBlog/blob/d8d0e93f913ceecf9c4946df3ad9b0c0283ab8d7/artifacts/article-vault/flow-ack-recovery/0324e7adb18f/reviewer-handoff.json) · [103项manifest](https://github.com/Ozwasyd/FsusBlog/blob/d8d0e93f913ceecf9c4946df3ad9b0c0283ab8d7/artifacts/article-vault/flow-ack-recovery/0324e7adb18f/manifest.json)。
