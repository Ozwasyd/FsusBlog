# Authorized exact-selector supplement — original unchanged Flow probe

Production source0324e7adb18f8aecfa870e86dec1153046a9f782,
tree168b91f10b5713fdc11d723b4b058b4630e07eb8.
Only the original failed probe selector was corrected under explicit parent authorization.
Original probe SHA256 e6f363c70dc2c02bc48c90b0c222459df456b2df4d24905d8daf0a6e8eb7a9de.
Original test composite SHA2560f37e107ef2bfcd825e17dba5fe61d927a5c258d7a53f2509b41d93f94c8d854.
No production source, assertion/oracle, fixture or input changed.

Result: actual1FAIL0PASS,138 original runtime cases outside selector, exit1.
Original setup records exactly one matched start/finish pair, worker84129 departed.
Actual probe PID84104; UTC2026-10-11T12:15:46.578816+00:00 to12:15:54.997225+00:00.
Original Node24.16.0/Vitest4.1.11, same original config/setup/runner and genuine
FsusUI0e5c56050e8dd3e9ca3735078489d35a0bb6e3d2 with real physical Vue3.5.33 graph.
Mandatory original preflight exit0. Original Release assets reused; no native qualification.

F1 core is dynamically confirmed at ordinary unit scope:
line520 fails after public cleanupRequired=false and clearPending: original context lost.
line524 fails after replacement start: original context not retained.
line525 fails: original File not retained.
Each observes actualfalse vs expectedtrue using genuine original owner/document/intent/
registry/editor fixtures and unchanged original source.

Refinement: the original probe also expected upload_completion_recovery_required at527.
Actual error is upload_attachment_input_invalid because its original anchor is stale
after the first capture. The capture-count assertion at523 passed (still1); no new capture,
commitCreated or source mutation is demonstrated by this exact unchanged-input run.
The fourth failed assertion remains untouched. Hard failure at527 means snapshot equality,
recovery cause, init/complete counts and zeroabort assertions at528-533 were NOT EXECUTED.
Do not claim those assertions passed or broaden this result to server/Writer behavior.

Selection is exact: original155-case CLI discovery equals original unmodified probe-input
discovery. The same original CLI prepareVitest/collect implementation supplies real task
objects; its exact original getTaskFullName reader is observed without replacing a parser,
host, task or runner. Original interpretTaskModes selects exactly1 actual task. Original CLI
list with that anchored pattern independently reports exactly the same one name and file.
The actual full matcher name (file is separately bound) is:
useImageUploadRuntime Independent Flow recovery public flag reset must not clear or replace original File context
The exact pattern is:
^useImageUploadRuntime Independent Flow recovery public flag reset must not clear or replace original File context$
Only its exact original runtime test file is passed to the execution command.
No wildcard/substring broadening, alternate oracle or other test execution occurred.

Previous selectorFAIL/behaviorUNRUN is retained byte-exact under unchanged-prior-failure-history/.
The old source review and ZIP SHA2562ebd1847308a3ddcd12a3e7bfaa637ec8a04177d5ed9f9aaed59c491f02a7fa1
remain unchanged. This is a new authorized supplemental execution, not retroactive acceptance.
Canonical receiver/business release absent; Writer/SharedDI/4170 and all held server/
backup/migration/native/browser/product/receipt/custody/security/cohort/race scopes remain
excluded. Historical154PASS, type244/244FAIL and old9def RefsFAIL are unchanged, not rerun.
No source-wide/full-chain or product qualification; qualification=false.

25 own links removed, original probe overlay restored, source/UI clean, no review Node workers.
Original locked caches preserved. Raw command logs, actual JSON report, original topology,
input hashes, frozen composite source and exact selectors are included for portable review.
Remap only checkout/output/pinned executable/genuine UI paths for future reproduction;
preserve original source/config/runner/inputs/locked setup and validate exact original
full-name/file selection after mandatory original preflight. Any failure stops affected
execution; no fallback to all tests or held qualification.

## Actual argv/cwd/source/results


preflight: actual exit0; source 0324e7adb18f8aecfa870e86dec1153046a9f782

```bash
cd /workspace/runtime-flow-ack-public-state-probe
/workspace/runtime-repair-review-evidence/node-setup/node-v24.16.0-linux-x64/bin/node tools/run-test-matrix.mjs preflight
```

cli-discovery: actual exit0; source 0324e7adb18f8aecfa870e86dec1153046a9f782

```bash
cd /workspace/runtime-flow-ack-public-state-probe/src/frontend
/workspace/runtime-repair-review-evidence/node-setup/node-v24.16.0-linux-x64/bin/node node_modules/vitest/vitest.mjs list --config vitest.config.ts ../../tests/frontend/unit/composables/useImageUploadRuntime.test.ts ../../tests/frontend/unit/api/upload.test.ts --json=/workspace/runtime-flow-ack-probe-supplement-evidence/cli-discovery-tests.json
```

original-task-discovery: actual exit0; source 0324e7adb18f8aecfa870e86dec1153046a9f782

```bash
cd /workspace/runtime-flow-ack-public-state-probe/src/frontend
/workspace/runtime-repair-review-evidence/node-setup/node-v24.16.0-linux-x64/bin/node /workspace/runtime-flow-ack-probe-supplement-evidence/discover-exact-selector.mjs
```

exact-cli-selection: actual exit0; source 0324e7adb18f8aecfa870e86dec1153046a9f782

```bash
cd /workspace/runtime-flow-ack-public-state-probe/src/frontend
/workspace/runtime-repair-review-evidence/node-setup/node-v24.16.0-linux-x64/bin/node node_modules/vitest/vitest.mjs list --config vitest.config.ts ../../tests/frontend/unit/composables/useImageUploadRuntime.test.ts --testNamePattern '^useImageUploadRuntime Independent Flow recovery public flag reset must not clear or replace original File context$' --json=/workspace/runtime-flow-ack-probe-supplement-evidence/exact-cli-selection-tests.json
```

single-probe-execution: actual exit1; source 0324e7adb18f8aecfa870e86dec1153046a9f782

```bash
cd /workspace/runtime-flow-ack-public-state-probe/src/frontend
/workspace/runtime-repair-review-evidence/node-setup/node-v24.16.0-linux-x64/bin/node node_modules/vitest/vitest.mjs run --config vitest.config.ts ../../tests/frontend/unit/composables/useImageUploadRuntime.test.ts --testNamePattern '^useImageUploadRuntime Independent Flow recovery public flag reset must not clear or replace original File context$' --reporter=json --outputFile=/workspace/runtime-flow-ack-probe-supplement-evidence/single-probe-report.json
```
