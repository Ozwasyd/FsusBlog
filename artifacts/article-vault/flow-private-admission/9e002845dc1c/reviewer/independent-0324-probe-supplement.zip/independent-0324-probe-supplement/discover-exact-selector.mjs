import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
import { q as originalCliApi } from '/workspace/runtime-borrow-install/node_modules/vitest/dist/chunks/cli-api.CnMVyzaz.js';
import { getTests, interpretTaskModes } from '/workspace/runtime-borrow-install/node_modules/@vitest/runner/dist/utils.js';

const evidence='/workspace/runtime-flow-ack-probe-supplement-evidence';
const source='0324e7adb18f8aecfa870e86dec1153046a9f782';
const filters=['../../tests/frontend/unit/composables/useImageUploadRuntime.test.ts','../../tests/frontend/unit/api/upload.test.ts'];
const originalBinding=JSON.parse(fs.readFileSync(evidence+'/original-probe-binding.json','utf8'));
const originalRunnerPath='/workspace/runtime-borrow-install/node_modules/@vitest/runner/dist/chunk-artifact.js';
const runnerSource=fs.readFileSync(originalRunnerPath,'utf8');
const matcherFunction=runnerSource.match(/function getTaskFullName\(task\) \{\n\treturn [^\n]+;\n\}/u)?.[0];
assert.ok(matcherFunction,'original private full-name reader source must be located exactly');
// Read-only metadata extraction on real collected task objects. The original runner
// still owns collection and interpretTaskModes; no task, parser, host or test is replaced.
const originalFullNameReader=Function('return ('+matcherFunction+')')();
const ctx=await originalCliApi.prepareVitest('test',{config:'vitest.config.ts',watch:false,run:true},undefined,undefined,filters);
try {
  const collected=await ctx.collect(filters,{staticParse:false});
  assert.equal(collected.unhandledErrors.length,0);
  const files=ctx.state.getFiles();
  const tasks=getTests(files);
  assert.equal(tasks.length,155);
  const rows=tasks.map(task=>({taskId:task.id,file:task.file.filepath,leafName:task.name,
    matcherFullName:originalFullNameReader(task),mode:task.mode}));
  assert.equal(new Set(rows.map(row=>row.file+'\0'+row.matcherFullName)).size,155);
  assert.ok(rows.every(row=>row.matcherFullName && row.leafName && ['run','queued'].includes(row.mode)));
  const exactFile='/workspace/runtime-flow-ack-public-state-probe/tests/frontend/unit/composables/useImageUploadRuntime.test.ts';
  const target=rows.filter(row=>row.file===exactFile && row.leafName===originalBinding.name);
  assert.equal(target.length,1);
  const escape=value=>value.replace(/[.*+?^${}()|[\]\\]/gu,'\\$&');
  const pattern='^'+escape(target[0].matcherFullName)+'$';
  const regexp=new RegExp(pattern);
  assert.deepEqual(rows.filter(row=>regexp.test(row.matcherFullName)),target);
  for(const file of files) interpretTaskModes(file,regexp,undefined,undefined,undefined,false,false,ctx.config.allowOnly);
  const actuallySelected=getTests(files).filter(task=>task.mode!=='skip');
  assert.equal(actuallySelected.length,1);
  assert.equal(actuallySelected[0].id,target[0].taskId);
  const output={status:'PASS',source,collected155ActualOriginalTasks:rows,
    originalCliCollectionImplementation:true,staticParse:false,originalConfig:'vitest.config.ts',
    originalRunnerPath,originalRunnerSha256:crypto.createHash('sha256').update(runnerSource).digest('hex'),
    originalFullNameReaderSource:matcherFunction,originalFullNameReaderSha256:crypto.createHash('sha256').update(matcherFunction).digest('hex'),
    actualTarget:target[0],exactAnchoredPattern:pattern,expectedCount:1,actualOriginalMatcherSelectedCount:1,
    allOtherCasesExcluded:true,fileArgument:filters[0],qualifiesOnlySupplementSelection:true,
    previousSelectorFailurePreserved:true,noTestsOrFixturesOrProductionChanged:true};
  fs.writeFileSync(evidence+'/exact-selector.json',JSON.stringify(output,null,2)+'\n');
  console.log(JSON.stringify({status:'PASS',actualCollected:155,actualSelected:1,file:target[0].file,matcherFullName:target[0].matcherFullName,pattern}));
} finally {
  await ctx.close();
}
