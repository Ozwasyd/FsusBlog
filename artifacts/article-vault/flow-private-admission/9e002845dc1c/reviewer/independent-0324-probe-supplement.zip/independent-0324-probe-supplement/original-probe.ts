
  it('Independent Flow recovery public flag reset must not clear or replace original File context', async () => {
    const file = fileOf(73), host = attachmentHost(), runtime = useImageUploadRuntime()
    const failure = new Error('independent-original-consumer-refused'), capture = vi.spyOn(host.owner, 'capture')
    const rejected = vi.fn()
    const flow = useImageUploadFlow({ runtime, getOptions: () => options, getWasmOnly: () => false,
      taskRegistry: host.documentOwner, onFileUploaded: async () => { throw failure } })
    await flow.startUpload({ files: [file], attachmentInput: { ...host, origin: 'pick' }, notifyOnError: false })
    const context = flow.pendingContext.value, snapshot = storedSnapshot()
    expect(runtime.cleanupRequired).toBe(true)
    expect(context?.files[0]).toBe(file)
    expect(capture).toHaveBeenCalledOnce()
    // Same writable public-state reset as the original retained author control.
    // It is not a canonical receiver or release acknowledgement.
    runtime.cleanupRequired = false
    flow.clearPending()
    expect.soft(flow.pendingContext.value === context).toBe(true)
    await flow.startUpload({ files: [fileOf(64, 'independent-replacement.png')],
      attachmentInput: { ...host, origin: 'pick' }, onError: rejected, notifyOnError: false })
    expect.soft(capture.mock.calls.length).toBe(1)
    expect.soft(flow.pendingContext.value === context).toBe(true)
    expect.soft(flow.pendingContext.value?.files[0] === file).toBe(true)
    expect(rejected).toHaveBeenCalledOnce()
    expect(rejected.mock.calls[0]![1].message).toBe('upload_completion_recovery_required')
    expect(storedSnapshot().snapshot).toEqual(snapshot.snapshot)
    const recovery = await runtime.abandon().catch(error => error)
    expect(recovery.cause).toBe(failure)
    expect(api.initUploadSession).toHaveBeenCalledOnce()
    expect(api.completeUpload).toHaveBeenCalledOnce()
    expect(api.abortUpload).not.toHaveBeenCalled()
  })

