import hashlib
import json
import pathlib
import shlex
import zipfile

e=pathlib.Path('/workspace/runtime-flow-ack-probe-supplement-evidence')
d=pathlib.Path('/workspace/runtime-review-library-delivery-0324-probe-supplement')
d.mkdir(parents=True,exist_ok=True)
verification=json.loads((e/'execution-verification.json').read_text())
labels=['preflight','cli-discovery','original-task-discovery','exact-cli-selection','single-probe-execution']
runs=[json.loads((e/(label+'.json')).read_text()) for label in labels]
assert all(run['exitCode']==(1 if run['label']=='single-probe-execution' else 0) for run in runs)
report={'verdict':'F1 core context-loss dynamically confirmed by one unchanged original bounded probe',
    'source':'0324e7adb18f8aecfa870e86dec1153046a9f782','sourceTree':'168b91f10b5713fdc11d723b4b058b4630e07eb8',
    'scope':'Parent-authorized sole exact-selector correction and one source-level ordinary unit reproduction; no source/oracle/input change',
    'actualResult':verification,'actualRuns':runs,'setup':json.loads((e/'setup.json').read_text()),
    'selection':json.loads((e/'selection-verification.json').read_text()),'cleanup':json.loads((e/'cleanup.json').read_text()),
    'F1ScopeRefinement':'Confirmed original File/context loss only. This exact original-input run does not demonstrate new capture, commitCreated or source mutation; old anchor invalidation prevents those paths. Additional original error-message expectation failed and subsequent assertions were not reached.',
    'previousHistory':'Previous selector FAIL / behavior UNRUN, source review, raw logs and archive unchanged. This authorized supplement has separate execution identity and does not rewrite the previous result.',
    'unchangedLimits':'Canonical receiver/business release absent; Writer/SharedDI/4170, all server/backup/migration/native/browser/product/held QA remain unapproved. No full-chain acceptance. Original154 PASS remains historical; no full154 rerun here. Type244/244 FAIL and inherited9def Refs FAIL unchanged.',
    'qualification':False,'sourceModified':False,'testAssertionsAndInputHashesUnchanged':True,'executionCount':1,
    'previousReviewLibraryId':'libfile_5081d9affd908191a8c3c85d1a63ebec','previousArchiveSha256':'2ebd1847308a3ddcd12a3e7bfaa637ec8a04177d5ed9f9aaed59c491f02a7fa1'}
(e/'report.json').write_text(json.dumps(report,indent=2)+'\n')
readme='''# Authorized exact-selector supplement — original unchanged Flow probe

Production source0324e7adb18f8aecfa870e86dec1153046a9f782,
tree168b91f10b5713fdc11d723b4b058b4630e07eb8.
Only the original failed probe selector was corrected under explicit parent authorization.
Original probe SHA256 e6f363c70dc2c02bc48c90b0c222459df456b2df4d24905d8daf0a6e8eb7a9de.
Original test composite SHA2560f37e107ef2bfcd825e17dba5fe61d927a5c258d7a53f2509b41d93f94c8d854.
No production source, assertion/oracle, fixture or input changed.

Result: actual1FAIL0PASS,138 original runtime cases outside selector, exit1.
Original setup records exactly one matched start/finish pair, worker84129 departed.
Actual probe PID84104; UTC2026-10-11T12:15:46.578816+00:00 to12:15:54.997225+00:00.
Original Node24.16.0/Vitest4.1.11, same original config/setup/runner and genuine
FsusUI0e5c56050e8dd3e9ca3735078489d35a0bb6e3d2 with real physical Vue3.5.33 graph.
Mandatory original preflight exit0. Original Release assets reused; no native qualification.

F1 core is dynamically confirmed at ordinary unit scope:
line520 fails after public cleanupRequired=false and clearPending: original context lost.
line524 fails after replacement start: original context not retained.
line525 fails: original File not retained.
Each observes actualfalse vs expectedtrue using genuine original owner/document/intent/
registry/editor fixtures and unchanged original source.

Refinement: the original probe also expected upload_completion_recovery_required at527.
Actual error is upload_attachment_input_invalid because its original anchor is stale
after the first capture. The capture-count assertion at523 passed (still1); no new capture,
commitCreated or source mutation is demonstrated by this exact unchanged-input run.
The fourth failed assertion remains untouched. Hard failure at527 means snapshot equality,
recovery cause, init/complete counts and zeroabort assertions at528-533 were NOT EXECUTED.
Do not claim those assertions passed or broaden this result to server/Writer behavior.

Selection is exact: original155-case CLI discovery equals original unmodified probe-input
discovery. The same original CLI prepareVitest/collect implementation supplies real task
objects; its exact original getTaskFullName reader is observed without replacing a parser,
host, task or runner. Original interpretTaskModes selects exactly1 actual task. Original CLI
list with that anchored pattern independently reports exactly the same one name and file.
The actual full matcher name (file is separately bound) is:
useImageUploadRuntime Independent Flow recovery public flag reset must not clear or replace original File context
The exact pattern is:
^useImageUploadRuntime Independent Flow recovery public flag reset must not clear or replace original File context$
Only its exact original runtime test file is passed to the execution command.
No wildcard/substring broadening, alternate oracle or other test execution occurred.

Previous selectorFAIL/behaviorUNRUN is retained byte-exact under unchanged-prior-failure-history/.
The old source review and ZIP SHA2562ebd1847308a3ddcd12a3e7bfaa637ec8a04177d5ed9f9aaed59c491f02a7fa1
remain unchanged. This is a new authorized supplemental execution, not retroactive acceptance.
Canonical receiver/business release absent; Writer/SharedDI/4170 and all held server/
backup/migration/native/browser/product/receipt/custody/security/cohort/race scopes remain
excluded. Historical154PASS, type244/244FAIL and old9def RefsFAIL are unchanged, not rerun.
No source-wide/full-chain or product qualification; qualification=false.

25 own links removed, original probe overlay restored, source/UI clean, no review Node workers.
Original locked caches preserved. Raw command logs, actual JSON report, original topology,
input hashes, frozen composite source and exact selectors are included for portable review.
Remap only checkout/output/pinned executable/genuine UI paths for future reproduction;
preserve original source/config/runner/inputs/locked setup and validate exact original
full-name/file selection after mandatory original preflight. Any failure stops affected
execution; no fallback to all tests or held qualification.

## Actual argv/cwd/source/results

'''
for run in runs:
    readme+='\n'+run['label']+': actual exit'+str(run['exitCode'])+'; source '+run['source']+'\n\n'
    readme+='```bash\ncd '+shlex.quote(run['cwd'])+'\n'+shlex.join(run['argv'])+'\n```\n'
(e/'README.md').write_text(readme)
entries=[]
for path in sorted(e.rglob('*')):
    if path.is_file() and path.name!='manifest.json':
        data=path.read_bytes()
        entries.append({'path':str(path.relative_to(e)),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
(e/'manifest.json').write_text(json.dumps({'source':report['source'],'entries':entries},indent=2)+'\n')
archive=d/'independent-0324-probe-supplement.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as output:
    for path in sorted(e.rglob('*')):
        if path.is_file():
            output.write(path,'independent-0324-probe-supplement/'+str(path.relative_to(e)))
with zipfile.ZipFile(archive) as output:
    assert output.testzip() is None
    for entry in entries:
        data=output.read('independent-0324-probe-supplement/'+entry['path'])
        assert len(data)==entry['bytes'] and hashlib.sha256(data).hexdigest()==entry['sha256']
identity={'file':str(archive),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,
    'entries':len(entries)+1,'reportJsonSha256':hashlib.sha256((e/'report.json').read_bytes()).hexdigest(),'allEntryHashesVerified':True}
(d/'archive-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
print(json.dumps(identity))
