import hashlib
import json
import pathlib
import subprocess
import sys

e=pathlib.Path('/workspace/runtime-flow-ack-probe-supplement-evidence')
r=pathlib.Path('/workspace/runtime-flow-ack-public-state-probe')
selector=json.loads((e/'exact-selector.json').read_text())
assert selector['status']=='PASS' and selector['expectedCount']==selector['actualOriginalMatcherSelectedCount']==1
assert json.loads((e/'preflight.json').read_text())['exitCode']==0
binding=json.loads((e/'original-probe-binding.json').read_text())
assert hashlib.sha256((r/'tests/frontend/unit/composables/useImageUploadRuntime.test.ts').read_bytes()).hexdigest()==binding['testCompositeSha256']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==binding['productionSource']
mode=sys.argv[1]
assert mode in ['list','run']
if mode=='list':
    label='exact-cli-selection'
    report=['--json='+str(e/'exact-cli-selection-tests.json')]
else:
    label='single-probe-execution'
    validation=json.loads((e/'selection-verification.json').read_text())
    assert validation['status']=='PASS' and validation['actualOriginalCliSelectedCount']==1
    assert not (e/(label+'.json')).exists() and not (e/(label+'.log')).exists()
    report=['--reporter=json','--outputFile='+str(e/'single-probe-report.json')]
argv=['python3',str(e/'run-record.py'),label,str(r/'src/frontend'),
      '/workspace/runtime-repair-review-evidence/node-setup/node-v24.16.0-linux-x64/bin/node',
      'node_modules/vitest/vitest.mjs',mode,'--config','vitest.config.ts',selector['fileArgument'],
      '--testNamePattern',selector['exactAnchoredPattern'],*report]
result=subprocess.run(argv)
raise SystemExit(result.returncode)
