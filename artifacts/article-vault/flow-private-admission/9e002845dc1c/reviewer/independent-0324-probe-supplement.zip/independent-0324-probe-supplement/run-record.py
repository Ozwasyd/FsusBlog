import datetime, json, os, pathlib, subprocess, sys

evidence = pathlib.Path('/workspace/runtime-flow-ack-probe-supplement-evidence')
label, cwd, *argv = sys.argv[1:]
env = dict(os.environ)
env['PATH'] = '/workspace/runtime-repair-review-evidence/node-setup/node-v24.16.0-linux-x64/bin' + ':' + env['PATH']
env['FSUSBLOG_USE_LOCAL_FSUSUI'] = '1'
env['FSUSBLOG_RUN_ID'] = 'independent-flow-ack-supplement-' + label + '-0324e7adb18f'
env['FSUSBLOG_LOCAL_FSUSUI_ROOT'] = '/workspace/runtime-borrow-ui'
env['FSUSBLOG_VITEST_MAX_WORKERS'] = '1'
env['FSUSBLOG_PRODUCTION_FRESH_OUTPUT_ROOT'] = str(evidence / label)
env['FSUSBLOG_VITEST_RUNTIME_TOPOLOGY_EVIDENCE'] = str(evidence / label / 'topology.jsonl')
(evidence / label).mkdir(exist_ok=True)
record = {
    'label': label, 'cwd': cwd, 'argv': argv,
    'source': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=cwd, text=True).strip(),
    'startUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'qualification': False,
    'environment': {key: env[key] for key in ['PATH', 'FSUSBLOG_RUN_ID', 'FSUSBLOG_USE_LOCAL_FSUSUI', 'FSUSBLOG_LOCAL_FSUSUI_ROOT',
        'FSUSBLOG_VITEST_MAX_WORKERS', 'FSUSBLOG_PRODUCTION_FRESH_OUTPUT_ROOT', 'FSUSBLOG_VITEST_RUNTIME_TOPOLOGY_EVIDENCE']}
}
with (evidence / (label + '.log')).open('w') as log:
    process = subprocess.Popen(argv, cwd=cwd, env=env, stdout=log, stderr=subprocess.STDOUT)
    record['pid'] = process.pid
    record['exitCode'] = process.wait()
record['stopUtc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
(evidence / (label + '.json')).write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({key: record[key] for key in ['label', 'source', 'pid', 'exitCode', 'startUtc', 'stopUtc']}))
sys.exit(record['exitCode'])
