import hashlib
import json
import pathlib
import subprocess

e=pathlib.Path('/workspace/runtime-flow-ack-probe-supplement-evidence')
r=pathlib.Path('/workspace/runtime-flow-ack-public-state-probe')
prior=pathlib.Path('/workspace/runtime-flow-ack-review-evidence')
ui=pathlib.Path('/workspace/runtime-borrow-ui')
node='/workspace/runtime-repair-review-evidence/node-setup/node-v24.16.0-linux-x64/bin/node'
source='0324e7adb18f8aecfa870e86dec1153046a9f782'
git=lambda *a:subprocess.check_output(['git',*a],cwd=r)
assert git('rev-parse','HEAD').decode().strip()==source
assert not git('status','--porcelain')
assert hashlib.sha256(pathlib.Path(node).read_bytes()).hexdigest()=='b2959781cc5a74c357ffa02367efa8a0330cbb1c9cb347732fdfaaaca381cbcd'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ui,text=True).strip()=='0e5c56050e8dd3e9ca3735078489d35a0bb6e3d2'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=ui)
binding=json.loads((prior/'public-state-probe-binding.json').read_text())
probe=(prior/'public-state-probe.ts').read_bytes()
assert hashlib.sha256(probe).hexdigest()==binding['probeSha256']
path='tests/frontend/unit/composables/useImageUploadRuntime.test.ts'
original=git('show',source+':'+path)
assert hashlib.sha256(original).hexdigest()==binding['testOriginalSha256']
marker=b"  it.each([\n    ['reviewer-258-byte'"
assert original.count(marker)==1
updated=original.replace(marker,probe+marker)
assert hashlib.sha256(updated).hexdigest()==binding['testCompositeSha256']
(r/path).write_bytes(updated)
assert git('diff','--name-only').decode().splitlines()==[path]
assert not (r/'src/frontend/node_modules').exists()
assert not (ui/'vue/packages/node_modules').exists()
commands=[]
prepare=[node,'src/frontend/scripts/prepare-local-fsusui-install.mjs','prepare','--frontend-root',str(r/'src/frontend'),'--fsusui-root',str(ui),'--output','/workspace/runtime-flow-ack-probe-supplement-install-input']
commands.append(prepare)
subprocess.run(prepare,cwd=r,check=True,stdout=(e/'official-prepare.log').open('w'),stderr=subprocess.STDOUT)
for filename in ['package.json','package-lock.json']:
    assert pathlib.Path('/workspace/runtime-flow-ack-probe-supplement-install-input',filename).read_bytes()==pathlib.Path('/workspace/runtime-borrow-install',filename).read_bytes()
(r/'src/frontend/node_modules').symlink_to('/workspace/runtime-borrow-install/node_modules',target_is_directory=True)
verify=[node,'src/frontend/scripts/prepare-local-fsusui-install.mjs','verify','--frontend-root',str(r/'src/frontend'),'--fsusui-root',str(ui)]
commands.append(verify)
subprocess.run(verify,cwd=r,check=True,stdout=(e/'official-verify.log').open('w'),stderr=subprocess.STDOUT)
links=[]
for name in ['runtime-dom','runtime-core','reactivity','shared']:
    path=ui/'vue/packages/node_modules/@vue'/name
    assert not path.exists() and not path.is_symlink()
    path.parent.mkdir(parents=True,exist_ok=True)
    target=r/'src/frontend/node_modules/@vue'/name
    path.symlink_to(target,target_is_directory=True)
    actual=target.resolve()
    assert json.loads((actual/'package.json').read_text())['version']=='3.5.33'
    links.append({'path':str(path),'target':str(target),'physical':str(actual),'version':'3.5.33'})
logger=(prior/'run-record.py').read_text().replace(str(prior),str(e)).replace("'independent-flow-ack-'","'independent-flow-ack-supplement-'")
logger=logger.replace("['PATH', 'FSUSBLOG_USE_LOCAL_FSUSUI'", "['PATH', 'FSUSBLOG_RUN_ID', 'FSUSBLOG_USE_LOCAL_FSUSUI'")
(e/'run-record.py').write_text(logger)
(e/'original-probe.ts').write_bytes(probe)
(e/'original-probe-binding.json').write_text(json.dumps(binding,indent=2)+'\n')
failed=(prior/'probe-selector-failure.json').read_bytes()
(e/'prior-selector-failure.json').write_bytes(failed)
(e/'setup.json').write_text(json.dumps({'source':source,'testAndProbeExactPreviousBytes':True,'testCompositeSha256':binding['testCompositeSha256'],'probeSha256':binding['probeSha256'],
    'allOriginal154CallsAndAssertionsUnchanged':True,'productionSourceChanged':False,'officialHelperCommands':commands,'originalLockedInputsByteIdentical':True,'vueLinks':links,
    'FsusUI':'0e5c56050e8dd3e9ca3735078489d35a0bb6e3d2','nodeBinarySha256':hashlib.sha256(pathlib.Path(node).read_bytes()).hexdigest(),
    'priorSelectorFailureHash':hashlib.sha256(failed).hexdigest(),'authorization':'Parent expressly authorized sole selector correction and one bounded supplement execution; original failed result remains immutable.'},indent=2)+'\n')
print('Setup PASS; exact original probe restored, production source untouched')
