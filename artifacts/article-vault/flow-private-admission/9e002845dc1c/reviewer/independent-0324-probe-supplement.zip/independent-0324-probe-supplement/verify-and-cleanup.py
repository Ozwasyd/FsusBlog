import collections
import hashlib
import json
import os
import pathlib
import shutil
import subprocess

e=pathlib.Path('/workspace/runtime-flow-ack-probe-supplement-evidence')
r=pathlib.Path('/workspace/runtime-flow-ack-public-state-probe')
ui=pathlib.Path('/workspace/runtime-borrow-ui')
prior=pathlib.Path('/workspace/runtime-flow-ack-review-evidence')
source='0324e7adb18f8aecfa870e86dec1153046a9f782'
run=json.loads((e/'single-probe-execution.json').read_text())
report=json.loads((e/'single-probe-report.json').read_text())
selector=json.loads((e/'exact-selector.json').read_text())
assert run['source']==source and run['exitCode']==1
all_assertions=[a for f in report['testResults'] for a in f['assertionResults']]
counts=collections.Counter(a['status'] for a in all_assertions)
assert counts=={'failed':1,'skipped':138}
selected=[a for a in all_assertions if a['status']=='failed']
assert selected[0]['title']==selector['actualTarget']['leafName']
assert selected[0]['fullName']==selector['actualTarget']['matcherFullName']
messages=selected[0]['failureMessages']
assert len(messages)==4
for line in [520,524,525]:
    assert any('expected false to be true' in message and f'.test.ts:{line}:' in message for message in messages)
assert any("expected 'upload_attachment_input_invalid' to be 'upload_completion_recovery_required'" in message and '.test.ts:527:' in message for message in messages)
assert not any('.test.ts:523:' in message for message in messages)
events=[json.loads(line) for line in (e/'single-probe-execution/topology.jsonl').read_text().splitlines()]
assert len(events)==2 and events[0]['event']=='start' and events[1]['event']=='finish'
assert events[0]['task']==events[1]['task']
assert events[0]['task']['name']==selected[0]['title']
assert events[0]['workerProcessId']==events[1]['workerProcessId']
binding=json.loads((e/'original-probe-binding.json').read_text())
test='tests/frontend/unit/composables/useImageUploadRuntime.test.ts'
composite=(r/test).read_bytes()
assert hashlib.sha256(composite).hexdigest()==binding['testCompositeSha256']
frozen=e/'frozen-inputs'/test
frozen.parent.mkdir(parents=True,exist_ok=True)
frozen.write_bytes(composite)
inputs=[]
for path in ['src/frontend/src/composables/useImageUploadRuntime.ts','src/frontend/src/composables/useImageUploadFlow.ts',
             'src/frontend/vitest.config.ts','src/frontend/vitest.shared.mjs','tests/frontend/support/unit/setup.ts']:
    data=subprocess.check_output(['git','show',source+':'+path],cwd=r)
    assert data==(r/path).read_bytes()
    out=e/'frozen-inputs'/path
    out.parent.mkdir(parents=True,exist_ok=True)
    out.write_bytes(data)
    inputs.append({'path':path,'blob':subprocess.check_output(['git','rev-parse',source+':'+path],cwd=r,text=True).strip(),
                   'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'source':source})
(e/'frozen-input-bindings.json').write_text(json.dumps(inputs,indent=2)+'\n')
for path in ['.tmp/gate-logs/preflight.json','.tmp/release-evidence/test-plan.json']:
    out=e/'independent-original-preflight'/pathlib.Path(path).name
    out.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(r/path,out)
for path in ['public-state-probe.json','public-state-probe.log','public-state-probe-report.json','probe-selector-failure.json']:
    destination=e/'unchanged-prior-failure-history'/path
    destination.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(prior/path,destination)
original=subprocess.check_output(['git','show',source+':'+test],cwd=r)
assert subprocess.check_output(['git','diff','--name-only'],cwd=r,text=True).splitlines()==[test]
(r/test).write_bytes(original)
modules=ui/'vue/packages/node_modules'
prefix=str(r/'src/frontend/node_modules')+'/'
links=[path for path in modules.rglob('*') if path.is_symlink() and os.readlink(path).startswith(prefix)]
assert len(links)==24
frontend=r/'src/frontend/node_modules'
assert frontend.is_symlink() and os.readlink(frontend)=='/workspace/runtime-borrow-install/node_modules'
links.append(frontend)
removed=[]
for path in links:
    removed.append({'path':str(path),'target':os.readlink(path)})
    path.unlink()
empty=[]
parents={pathlib.Path(item['path']).parent for item in removed if '/runtime-borrow-ui/' in item['path']}
for parent in sorted(parents,key=lambda path:len(path.parts),reverse=True):
    if parent!=modules and parent.exists() and not list(parent.iterdir()):
        parent.rmdir()
        empty.append(str(parent))
assert not list(modules.iterdir())
modules.rmdir()
empty.append(str(modules))
statuses=[]
for root in [r,ui]:
    status=subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True)
    assert status=='',status
    statuses.append({'checkout':str(root),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'status':status})
processes=subprocess.check_output(['ps','-eo','pid,ppid,state,args'],text=True)
active=[line for line in processes.splitlines() if 'node_modules/vitest' in line or 'vitest/dist/chunks' in line or 'node tools/run-test-matrix.mjs' in line]
assert active==[],active
old_archive=pathlib.Path('/workspace/runtime-review-library-delivery-0324e7adb18f/independent-review-0324e7adb18f-portable.zip')
assert hashlib.sha256(old_archive.read_bytes()).hexdigest()=='2ebd1847308a3ddcd12a3e7bfaa637ec8a04177d5ed9f9aaed59c491f02a7fa1'
assert (e/'prior-selector-failure.json').read_bytes()==(prior/'probe-selector-failure.json').read_bytes()
cleanup={'ownedLinksRemoved':25,'removedLinks':removed,'emptyOwnedParentsRemoved':empty,'originalProbeTestOverlayRestored':True,
         'sourceStatuses':statuses,'activeReviewNodeWorkers':active,'previousReportAndFailureHistoryUnchanged':True,'sharedLockedCachesPreserved':True}
(e/'cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n')
verification={'productionSource':source,'testCompositeSha256':binding['testCompositeSha256'],'originalProbeSha256':binding['probeSha256'],
    'originalOracleAndInputsUnchanged':True,'actualExecuted':1,'failed':1,'passed':0,'outsideSelector':138,'actualExitCode':1,
    'actualFullName':selected[0]['fullName'],'exactFile':selector['actualTarget']['file'],'hookStarts':1,'hookFinishes':1,
    'workerPids':[events[0]['workerProcessId']],'workerDeparted':True,'assertionFailures':messages,
    'F1Core':'Dynamically confirmed ordinary-unit context loss: line520 original context not retained after public reset+clearPending; lines524/525 original context/File not retained after rejected replacement start.',
    'additionalMessageExpectation':'Original probe line527 expected upload_completion_recovery_required; actual upload_attachment_input_invalid because original attachment anchor is no longer current. This assertion was not changed.',
    'broaderCaptureClaim':'Not demonstrated. Original capture-count soft assertion at523 passes: capture remains1. No new capture/source mutation observed in this exact unchanged-input run.',
    'unreachedAssertions':'Lines528-533 snapshot equality, recovery cause, init/complete counts and zeroabort assertions did not execute after hard failure at527. Do not claim their PASS here.',
    'oldSelectorFailBehaviorUnrunPreserved':True,'supplementAuthorizedExecutionCount':1,'rerunOrOracleChange':False,
    'qualification':False,'WriterOrProductOrHeldQAAccepted':False}
(e/'execution-verification.json').write_text(json.dumps(verification,indent=2)+'\n')
print(json.dumps({'actualSelected':1,'actualFailed':1,'F1CoreConfirmed':True,'newCaptureDemonstrated':False,'ownedLinksRemoved':25,'sourceClean':True}))
