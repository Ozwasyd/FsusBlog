# Original independent Flow ACK recovery review

Source0324e7adb18f8aecfa870e86dec1153046a9f782,
tree168b91f10b5713fdc11d723b4b058b4630e07eb8.
Published author evidence d8d0e93f913ceecf9c4946df3ad9b0c0283ab8d7.
Verdict: MUST_FIX, one deterministic static P2 finding F1.
Extra dynamic public-state probe selector FAIL; behavior UNRUN, not a demonstrated test failure.
Original ordinary154 results remain independently PASS, not source/product acceptance.

F1: After genuine consumer failure settles, startUpload finally clears private activeRun.
Flow method admission then checks only writable public runtime.cleanupRequired. Set that
flag false, as the preserved original new public-state control already does; clearPending
can set original pendingContext null. A replacement start overwrites File/context and
capture/commitCreated precede private runtime.uploadFile admission. Private runtime still
refuses new init/complete and grants no abort. The retained File/context can nevertheless
be discarded and a new intent/source mutation admitted before that refusal. This conflicts
with retention until real recovery and with treating public flags as no release receipt.
This is a static source trace, not actual probe execution, live backend or Writer evidence.
Original1975 should make controlled Flow retention/admission follow its original private
recovery obligation; do not add a business receiver, second ledger, token persistence or loan.

Independent checks: original preflight PASS0; exact154 unique nonempty discovery identities;
154PASS138runtime/16API, zero fail/skip and154 exact original start/finish pairs.
Original positive2PASS; original9after9PASS; original37 prerequisite controlsPASS, zero skip.
Source style, last-commit range and complete four-new-commit range from c93 evidencePASS0.
All original139/140 complete test calls/hooks/imports unchanged; original9 block byte-exact.
All45 previous protocol/filename/zeroGUID controls passed current154. Original11 safety
identities passed;2 base calls byte-identical and9 previously reviewed adaptations remain
documented, without claiming all11 original base calls preserved byte-identical.
Before fixture product22813e9b81db72a0d01b1a0752551a1f96ab9c89 plus exact current test overlay:
same original9 actual9FAIL; new5 actual4FAIL1PASS. No missing selected controls.
The full current test overlay gives129 runtime cases outside9 selector, whereas the author
earlier nine-only insertion had124 outside. This input/count distinction is explicit.
Original old28/17 before results are immutable history, not rerun or upgraded here.

The extra probe preflight PASS0 and discovery155 matched original154 plus exactly one
added bounded case. The reviewer selected ^leaf-name$, but original Vitest recursively
matches full suite/file names. Actual command exit0 selected0,139 outside, no hooks.
The pre-run leaf-only selector claim is inadmissible. probe-selector-failure.json records
FAIL/UNRUN and affected execution stopped. No retry, alternative runner, fallback or test
oracle change occurred. public-state-probe.ts is portable source for a later authorized run;
the suffix-only selector below is a future correction and was NOT EXECUTED in this review.

Remaining: canonical recovery receiver/current business receipt/release absent. Normal
fulfilled void/batch do not establish business acceptance. Noncooperative callbacks can
remain physically pending after finite revocation; timer/flag/loan release is no physical
termination or cleanup ACK. Writer2246/SharedDI/4170 activation and server/backup/migration/
native/browser/product/receipt/custody/security/cohort/race/ProjectXML/Git scopes remain held.
Author application types FAIL244/244 zero delta, not independently rerun. Old9def Refs
footer FAIL remains; new-range PASS does not waive history. No full-chain/source-wide gate.

Official setup uses original Node24.16.0 SHA256
b2959781cc5a74c357ffa02367efa8a0330cbb1c9cb347732fdfaaaca381cbcd,
Vitest4.1.11/TypeScript6.0.3/Vue3.5.33, genuine FsusUI
0e5c56050e8dd3e9ca3735078489d35a0bb6e3d2 and six original Release WASM assets.
Initial original helper verify failed twice on six prior review-owned empty scoped parent
directories. The failed cleanup reader initially expected only@vue; no files were removed.
Only empty parents verified against previous owned cleanup were removed, then unchanged
official helper succeeded. No preflight/tests launched before setup completed. Initial
static-tool binding failed on one extra delimiter newline; first static output inadmissible;
exact original extraction/format function binding then succeeded read-only. All failures
are retained separately. These are not product/permission/cancellation or rate-limit errors.

27 own links removed;2 fixture test overlays restored; six scoped empty parents and root
removed after cleanup. Four original source/UI checkouts clean; no active review Node workers.
Shared locked caches and previous c93 Library ZIP identity preserved unchanged.
author-published/ remains author evidence:103 entries plus manifest=104 byte/SHA-verified files.
All independent data are outside that directory. No authority receipt was copied as admission.

## Reproduction

Use recorded original source, Node binary, official task-local locked helper inputs,
unchanged runner/config/hooks and genuine original UI physical Vue graph. Remap only
filesystem checkout/output/executable/UI paths. Mandatory original preflight and exact
original collection/selector checks precede each bounded execution. Any actual preflight,
selector, hook, permission or registry failure stops that affected execution. Never fall
back to all tests, replace host/parser, modify locks/types or run held tiers.

Review source and complete c93-to-current patch, source images, original control bytes,
static-inspection.json, setup.json, fixture/probe binding records and actual run logs/reports.
Each actual command below has cwd/source/env/UTC/PID/exit in its JSON record. The probe
record's exit0 is not accepted as execution success. Expected before failures retain exit1.

Future NOT-RUN corrected probe pattern:
`Independent Flow recovery public flag reset must not clear or replace original File context$`
It must be validated against actual original full task names before any later authorized run.

## Actual commands and results


preflight: actual exit0; source 0324e7adb18f8aecfa870e86dec1153046a9f782

```bash
cd /workspace/runtime-flow-ack-review
/workspace/runtime-repair-review-evidence/node-setup/node-v24.16.0-linux-x64/bin/node tools/run-test-matrix.mjs preflight
```

discovery: actual exit0; source 0324e7adb18f8aecfa870e86dec1153046a9f782

```bash
cd /workspace/runtime-flow-ack-review/src/frontend
/workspace/runtime-repair-review-evidence/node-setup/node-v24.16.0-linux-x64/bin/node node_modules/vitest/vitest.mjs list --config vitest.config.ts ../../tests/frontend/unit/composables/useImageUploadRuntime.test.ts ../../tests/frontend/unit/api/upload.test.ts --json=/workspace/runtime-flow-ack-review-evidence/discovery-tests.json
```

focused: actual exit0; source 0324e7adb18f8aecfa870e86dec1153046a9f782

```bash
cd /workspace/runtime-flow-ack-review/src/frontend
/workspace/runtime-repair-review-evidence/node-setup/node-v24.16.0-linux-x64/bin/node node_modules/vitest/vitest.mjs run --config vitest.config.ts ../../tests/frontend/unit/composables/useImageUploadRuntime.test.ts ../../tests/frontend/unit/api/upload.test.ts
```

positive: actual exit0; source 0324e7adb18f8aecfa870e86dec1153046a9f782

```bash
cd /workspace/runtime-flow-ack-review/src/frontend
/workspace/runtime-repair-review-evidence/node-setup/node-v24.16.0-linux-x64/bin/node node_modules/vitest/vitest.mjs run --config vitest.config.ts ../../tests/frontend/unit/composables/useImageUploadRuntime.test.ts --testNamePattern '(runs compression and hashing before init, uploads every required part, then completes once|borrows actual compressed facts and retains a bound handle after public session and original lease clear)$'
```

nine-after: actual exit0; source 0324e7adb18f8aecfa870e86dec1153046a9f782

```bash
cd /workspace/runtime-flow-ack-review/src/frontend
/workspace/runtime-repair-review-evidence/node-setup/node-v24.16.0-linux-x64/bin/node node_modules/vitest/vitest.mjs run --config vitest.config.ts ../../tests/frontend/unit/composables/useImageUploadRuntime.test.ts --testNamePattern 'Flow consumer recovery' --reporter=json --outputFile=/workspace/runtime-flow-ack-review-evidence/nine-after-report.json
```

prerequisites: actual exit0; source 0324e7adb18f8aecfa870e86dec1153046a9f782

```bash
cd /workspace/runtime-flow-ack-review
/workspace/runtime-repair-review-evidence/node-setup/node-v24.16.0-linux-x64/bin/node --test tests/tools/execution-envelope-policy.test.mjs tests/tools/local-production-profile-resources.test.mjs tests/tools/matrix-fixture-profile.test.mjs tests/tools/linux-cgroup-membership-locator.test.mjs
```

source-style: actual exit0; source 0324e7adb18f8aecfa870e86dec1153046a9f782

```bash
cd /workspace/runtime-flow-ack-review
/workspace/runtime-repair-review-evidence/node-setup/node-v24.16.0-linux-x64/bin/node tools/frontend/check-frontend-style.mjs --file src/frontend/src/composables/useImageUploadRuntime.ts --file src/frontend/src/composables/useImageUploadFlow.ts --file src/frontend/src/api/upload.ts
```

new-range: actual exit0; source 0324e7adb18f8aecfa870e86dec1153046a9f782

```bash
cd /workspace/runtime-flow-ack-review
/workspace/runtime-repair-review-evidence/node-setup/node-v24.16.0-linux-x64/bin/node tools/governance/check-change-contract.mjs --range 22813e9b81db72a0d01b1a0752551a1f96ab9c89..HEAD
```

before-preflight: actual exit0; source 22813e9b81db72a0d01b1a0752551a1f96ab9c89

```bash
cd /workspace/runtime-flow-ack-before
/workspace/runtime-repair-review-evidence/node-setup/node-v24.16.0-linux-x64/bin/node tools/run-test-matrix.mjs preflight
```

before-discovery: actual exit0; source 22813e9b81db72a0d01b1a0752551a1f96ab9c89

```bash
cd /workspace/runtime-flow-ack-before/src/frontend
/workspace/runtime-repair-review-evidence/node-setup/node-v24.16.0-linux-x64/bin/node node_modules/vitest/vitest.mjs list --config vitest.config.ts ../../tests/frontend/unit/composables/useImageUploadRuntime.test.ts ../../tests/frontend/unit/api/upload.test.ts --json=/workspace/runtime-flow-ack-review-evidence/before-discovery-tests.json
```

nine-before: actual exit1; source 22813e9b81db72a0d01b1a0752551a1f96ab9c89

```bash
cd /workspace/runtime-flow-ack-before/src/frontend
/workspace/runtime-repair-review-evidence/node-setup/node-v24.16.0-linux-x64/bin/node node_modules/vitest/vitest.mjs run --config vitest.config.ts ../../tests/frontend/unit/composables/useImageUploadRuntime.test.ts --testNamePattern 'Flow consumer recovery' --reporter=json --outputFile=/workspace/runtime-flow-ack-review-evidence/nine-before-report.json
```

five-before: actual exit1; source 22813e9b81db72a0d01b1a0752551a1f96ab9c89

```bash
cd /workspace/runtime-flow-ack-before/src/frontend
/workspace/runtime-repair-review-evidence/node-setup/node-v24.16.0-linux-x64/bin/node node_modules/vitest/vitest.mjs run --config vitest.config.ts ../../tests/frontend/unit/composables/useImageUploadRuntime.test.ts --testNamePattern 'Flow ACK handoff' --reporter=json --outputFile=/workspace/runtime-flow-ack-review-evidence/five-before-report.json
```

probe-preflight: actual exit0; source 0324e7adb18f8aecfa870e86dec1153046a9f782

```bash
cd /workspace/runtime-flow-ack-public-state-probe
/workspace/runtime-repair-review-evidence/node-setup/node-v24.16.0-linux-x64/bin/node tools/run-test-matrix.mjs preflight
```

probe-discovery: actual exit0; source 0324e7adb18f8aecfa870e86dec1153046a9f782

```bash
cd /workspace/runtime-flow-ack-public-state-probe/src/frontend
/workspace/runtime-repair-review-evidence/node-setup/node-v24.16.0-linux-x64/bin/node node_modules/vitest/vitest.mjs list --config vitest.config.ts ../../tests/frontend/unit/composables/useImageUploadRuntime.test.ts ../../tests/frontend/unit/api/upload.test.ts --json=/workspace/runtime-flow-ack-review-evidence/probe-discovery-tests.json
```

public-state-probe: actual exit0; source 0324e7adb18f8aecfa870e86dec1153046a9f782

```bash
cd /workspace/runtime-flow-ack-public-state-probe/src/frontend
/workspace/runtime-repair-review-evidence/node-setup/node-v24.16.0-linux-x64/bin/node node_modules/vitest/vitest.mjs run --config vitest.config.ts ../../tests/frontend/unit/composables/useImageUploadRuntime.test.ts --testNamePattern '^Independent Flow recovery public flag reset must not clear or replace original File context$' --reporter=json --outputFile=/workspace/runtime-flow-ack-review-evidence/public-state-probe-report.json
```

complete-new-range: actual exit0; source 0324e7adb18f8aecfa870e86dec1153046a9f782

```bash
cd /workspace/runtime-flow-ack-review
/workspace/runtime-repair-review-evidence/node-setup/node-v24.16.0-linux-x64/bin/node tools/governance/check-change-contract.mjs --range 0c1576c37d75e69e2b6425e245fd3f47eee25367..HEAD
```
