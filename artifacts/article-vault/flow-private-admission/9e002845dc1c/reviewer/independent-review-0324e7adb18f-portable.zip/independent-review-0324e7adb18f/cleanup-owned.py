import json
import os
import pathlib
import subprocess

e=pathlib.Path('/workspace/runtime-flow-ack-review-evidence')
current=pathlib.Path('/workspace/runtime-flow-ack-review')
ui=pathlib.Path('/workspace/runtime-borrow-ui')
fixtures={pathlib.Path('/workspace/runtime-flow-ack-before'):'22813e9b81db72a0d01b1a0752551a1f96ab9c89',
          pathlib.Path('/workspace/runtime-flow-ack-public-state-probe'):'0324e7adb18f8aecfa870e86dec1153046a9f782'}
test='tests/frontend/unit/composables/useImageUploadRuntime.test.ts'
restored=[]
for root,ref in fixtures.items():
    assert subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines()==[test]
    (root/test).write_bytes(subprocess.check_output(['git','show',ref+':'+test],cwd=root))
    restored.append({'path':str(root/test),'restoredSource':ref})
prefix=str(current/'src/frontend/node_modules')+'/'
ui_modules=ui/'vue/packages/node_modules'
links=[path for path in ui_modules.rglob('*') if path.is_symlink() and os.readlink(path).startswith(prefix)]
assert len(links)==24
for root in [current,*fixtures]:
    path=root/'src/frontend/node_modules'
    assert path.is_symlink() and os.readlink(path)=='/workspace/runtime-borrow-install/node_modules'
    links.append(path)
removed=[]
for path in links:
    removed.append({'path':str(path),'target':os.readlink(path)})
    path.unlink()
empty_owned=[]
for parent in sorted({pathlib.Path(item['path']).parent for item in removed if '/runtime-borrow-ui/' in item['path']},key=lambda path:len(path.parts),reverse=True):
    if parent!=ui_modules and parent.exists() and not list(parent.iterdir()):
        parent.rmdir()
        empty_owned.append(str(parent))
if not list(ui_modules.iterdir()):
    ui_modules.rmdir()
    empty_owned.append(str(ui_modules))
statuses=[]
for root in [current,*fixtures,ui]:
    status=subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True)
    assert status=='', (str(root),status)
    statuses.append({'checkout':str(root),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'status':status})
processes=subprocess.check_output(['ps','-eo','pid,ppid,state,args'],text=True)
active=[line for line in processes.splitlines() if ('node_modules/vitest' in line or 'vitest/dist/chunks' in line or 'node tools/run-test-matrix.mjs' in line)]
assert active==[],active
result={'ownedLinksRemoved':len(removed),'removedLinks':removed,'emptyOwnedDependencyParentsRemoved':empty_owned,
        'restoredTestFiles':restored,'sourceStatuses':statuses,'activeReviewNodeWorkers':active,
        'productOrForeignFilesChanged':False,'originalLockedCachesPreserved':True}
(e/'cleanup.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'ownedLinksRemoved':len(removed),'originalTestFilesRestored':len(restored),'sourcesClean':True,'activeReviewNodeWorkers':0}))
