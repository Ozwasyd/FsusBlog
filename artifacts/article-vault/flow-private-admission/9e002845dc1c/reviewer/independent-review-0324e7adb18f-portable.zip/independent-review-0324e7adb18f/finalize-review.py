import collections
import hashlib
import json
import pathlib
import shutil
import subprocess

r=pathlib.Path('/workspace/runtime-flow-ack-review')
e=pathlib.Path('/workspace/runtime-flow-ack-review-evidence')
source='0324e7adb18f8aecfa870e86dec1153046a9f782'
tree='168b91f10b5713fdc11d723b4b058b4630e07eb8'
published='d8d0e93f913ceecf9c4946df3ad9b0c0283ab8d7'
labels=['preflight','discovery','focused','positive','nine-after','prerequisites','source-style','new-range',
        'before-preflight','before-discovery','nine-before','five-before','probe-preflight','probe-discovery','public-state-probe']
runs=[json.loads((e/(label+'.json')).read_text()) for label in labels]
for run in runs:
    assert run['exitCode']==(1 if run['label'] in ['nine-before','five-before'] else 0)
probe_report=json.loads((e/'public-state-probe-report.json').read_text())
assertions=[a for f in probe_report['testResults'] for a in f['assertionResults']]
assert len(assertions)==139 and all(a['status']=='skipped' for a in assertions)
assert not (e/'public-state-probe/topology.jsonl').exists()
probe_failure={'status':'FAIL','boundary':'actual original runner selection','source':source,
    'preflight':'PASS0','discovery':'PASS155 exact original154 plus one probe',
    'preRunLeafOnlySelectionClaim':'INADMISSIBLE: ignored original runner full-name matching',
    'actualSelected':0,'actualOutsideSelector':139,'actualExitCode':0,'actualHookPairs':0,
    'behaviorResult':'UNRUN','initialPattern':'^Independent Flow recovery public flag reset must not clear or replace original File context$',
    'cause':'Original Vitest4.1.11 getTaskFullName recursively includes suite/file names; ^leaf$ matches none.',
    'originalRunnerSource':'@vitest/runner/dist/chunk-artifact.js:964,1006',
    'affectedExecutionStopped':True,'rerunOrFallback':False,
    'portableFuturePatternNotExecuted':'Independent Flow recovery public flag reset must not clear or replace original File context$',
    'noProductAssertionsChanged':True}
(e/'probe-selector-failure.json').write_text(json.dumps(probe_failure,indent=2)+'\n')
state={
    'source':source,'independentReadOnlyReview':True,
    'approvedInterface':'Only original onSessionReady(borrow, completionUrl) second readonly string argument; original one-argument consumers remain valid.',
    'ackBinding':'Runtime copies and freezes the strictly correlated real original complete response before publishing the URL. Callback/return/diagnostic history use that copy. Original attempt binding is retained with ACK/snapshot/generation/uploadId and first callback error.',
    'flowAwait':'Original Flow now awaits observer then consumer in the original runtime completion callback and existing withSession. Consumer failure reaches original runtime catch before final Flow loan release. No additional loan or business ledger.',
    'cleanup':'Post-ACK consumer failure/cancel/intent cancel/disposal/abandon/deadline/late result preserves original recovery obligation. No post-ACK abort/reinit/recomplete in original controlled paths. Public transport reset, fulfilled void, loan release and flags do not acknowledge business release.',
    'finiteAccess':'Private nonenumerable frozen getter scopes and loan deadline remain unchanged; current ownership checked before getters/after awaits, scopes individually revoked, actual borrowed signal propagates. Pending noncooperative callbacks remain physically pending while access expires.',
    'pendingGuard':'Private activeRun prevents reentrant start/resume/clearPending while the original execution remains awaited, including logical cancellation. Original controls cover normal flags. Once activeRun clears after failure, recovery blocking reads the mutable public cleanupRequired; see F1.',
    'normalSuccess':'Original slow same-name batch, fulfilled void, single-argument runtime callback and original safety/negative cases passed in complete154; success is not canonical business receipt.',
    'owners':'Writer2246, SharedDI/4170 and all original owner/registry/transport/ABI/runner/locked dependency sources outside four product paths unchanged.',
    'receiver':'Canonical recovery receiver/business release remains absent and unapproved. Local retained obligation does not establish full-chain acceptance.',
}
(e/'state-review.json').write_text(json.dumps(state,indent=2)+'\n')
finding={
    'id':'F1','severity':'P2 — MUST_FIX source contract discrepancy','status':'OPEN',
    'basis':'Independent deterministic static source trace; extra dynamic probe UNRUN due actual selector FAIL, no dynamic failure claimed.',
    'path':'src/frontend/src/composables/useImageUploadFlow.ts','lines':[107,108,110,220,228,303,307,372,378],
    'title':'Writable public cleanup flag can unlock clearing/replacing the retained original Flow context',
    'trigger':'A genuine original onFileUploaded throws; startUpload settles, runtime private ACK recovery remains required and original Flow File/context remains pending. Set the already-writable public runtime.cleanupRequired=false, as the preserved original public-state control does. Then call flow.clearPending or startUpload with another original attachment input.',
    'sourceTrace':'startUpload finally clears activeRun. admissionError then tests only options.runtime.cleanupRequired. A false public flag yields no blocker; clearPending sets pendingContext=null. New start overwrites pendingContext before its try, and capture/commitCreated run before runtime.uploadFile reaches private acknowledgedCompletion.recoveryRequired refusal.',
    'impact':'Original File/context can be lost and a new pending intent/source mutation can be captured before the private runtime refuses replacement. This contradicts retention until real recovery and the documented statement that public cleanup flags are not release acknowledgements.',
    'limits':'Private original runtime recovery check still blocks new init/complete and no abort permission is granted. No credential leak, live server action, Writer behavior or product effect was demonstrated. Direct external writes to pendingContext itself are a separate trust boundary, not this method-admission finding.',
    'actionForOriginal1975':'Keep controlled Flow method admission/context retention tied to its original private recovery obligation rather than allowing a mutable display flag to retire it. Preserve active-run guard, original binding and normal fulfilled void/batch. Do not add a canonical receiver, receipt, token persistence, loan or second ledger as a workaround; any needed contract decision remains with original owners.',
    'portableReproduction':'public-state-probe.ts and public-state-probe-binding.json; exact original helper/config/owner/registry. Initial actual selector failure is in probe-selector-failure.json. Corrected future suffix pattern is documented but explicitly NOT RUN.',
    'reviewOracle':'Original new public-state test only calls raw runtime after flag reset; it does not test Flow.clearPending or Flow.startUpload before private runtime admission.'
}
remaining=[
    'F1 local Flow context admission is unresolved; extra source probe behavior UNRUN after actual selector FAIL. No independent source acceptance granted.',
    'Canonical recovery receiver/current business receipt/release acknowledgement absent; original local retention does not accept terminal cutover, cleanup business or the full chain.',
    'Noncooperative callback remains physically pending after finite access revocation. No timeout is a physical termination ACK or release permission.',
    'Author full types remain FAIL244/244 with zero delta. Not independently rerun. Old9def missing independent Refs footer remains FAIL; current new-range PASS does not waive inherited history.',
    'Writer2246, SharedDI/4170 activation and all held server/backup/migration/native/browser/product/receipt/custody/security/cohort/race/ProjectXML/Git replacement scopes remain excluded PAUSED/UNRUN.',
]
review={'verdict':'MUST_FIX — F1 static source finding; extra probe selector FAIL / behavior UNRUN',
    'source':source,'tree':tree,'evidenceHead':published,'qualification':False,'sourceOrFullChainAccepted':False,
    'productSourceChanged':False,'findings':[finding],'remainingGates':remaining,
    'independentOrdinaryResults':{'preflight':'PASS0','exactDiscoverySelection':'PASS154 nonempty unique identities',
        'focused':json.loads((e/'focused-verification.json').read_text()),
        'positiveAndNineAfter':json.loads((e/'selected-current-verification.json').read_text()),
        'original37Prerequisites':'PASS37 zero failures/skips','style':'PASS0','new22813..0324Range':'PASS0',
        'nineBefore':'Actual exit1:9FAIL0PASS,129 runtime outside selector,9 real hook pairs',
        'fiveBefore':'Actual exit1:4FAIL1PASS,133 runtime outside selector,5 real hook pairs',
        'publicStateProbe':probe_failure},
    'testRetention':'Original139/140 whole complete calls/hooks/imports and original API file retained byte-identical; original9 block SHA692dffe3770e3998dfbc6a5bd52bc84a22f86d775a318dca09414afaa645d83e independently checked. All45 prior controls passed current154; old before results preserved, not rerun or upgraded.',
    'authorEvidence':'104 files including manifest;103 manifest entries independently byte/SHA checked. Author reports stay separate under author-published/.',
    'actualRuns':runs,'toolchain':{'Node':'24.16.0','binarySha256':'b2959781cc5a74c357ffa02367efa8a0330cbb1c9cb347732fdfaaaca381cbcd','Vitest':'4.1.11','TypeScript':'6.0.3','Vue':'3.5.33','FsusUI':'0e5c56050e8dd3e9ca3735078489d35a0bb6e3d2','originalReleaseWasm':'Original six prior independent Release build assets reused, no native qualification'},
    'failureHistory':'setup-initial-failure.json preserves original helper directory-exists FAIL twice and failed cleanup-reader assertion; no preflight/tests launched before setup repaired. Static inspector first binding assertion failed on extra delimiter newline; first static output was inadmissible, corrected exact-function binding then original inspector rerun read-only. Actual source-probe selector FAIL stops that affected execution; no rerun/fallback.',
    'previousIndependentReviews':'c93 bounded139 PASS remains historical, not inherited.734/8a incomplete selectorFAIL/focusedUNRUN and original missing@vue/shared/Node-preflight failures remain preserved.',
    'prohibitedOperationsExecuted':False,
}
(e/'review.json').write_text(json.dumps(review,indent=2)+'\n')
for label,root in [('current',r),('before',pathlib.Path('/workspace/runtime-flow-ack-before')),('probe',pathlib.Path('/workspace/runtime-flow-ack-public-state-probe'))]:
    out=e/'independent-original-preflight'/label
    out.mkdir(parents=True,exist_ok=True)
    for path in ['.tmp/gate-logs/preflight.json','.tmp/release-evidence/test-plan.json']:
        shutil.copy2(root/path,out/pathlib.Path(path).name)
bindings=[]
for path in ['docs/architecture/overview.md','src/frontend/src/composables/useImageUploadRuntime.ts','src/frontend/src/composables/useImageUploadFlow.ts','tests/frontend/unit/composables/useImageUploadRuntime.test.ts','tests/frontend/unit/api/upload.test.ts','src/frontend/src/api/upload.ts','src/frontend/src/composables/useAdminArticleWrite.ts','src/frontend/src/composables/useAbortableTask.ts','src/frontend/vitest.config.ts','src/frontend/vitest.shared.mjs','tests/frontend/support/unit/setup.ts','src/frontend/scripts/prepare-local-fsusui-install.mjs','src/frontend/package.json','src/frontend/package-lock.json']:
    data=subprocess.check_output(['git','show',source+':'+path],cwd=r)
    target=e/'frozen-source'/path
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(data)
    blob=subprocess.check_output(['git','rev-parse',source+':'+path],cwd=r,text=True).strip()
    assert data==subprocess.check_output(['git','show',published+':'+path],cwd=r)
    bindings.append({'path':path,'gitBlob':blob,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'matchesEvidenceHead':True})
assert next(x for x in bindings if x['path'].endswith('useAdminArticleWrite.ts'))['gitBlob']=='e18a5c976d7bcee4a116bfe9505a725d5b251f9d'
(e/'frozen-source-bindings.json').write_text(json.dumps(bindings,indent=2)+'\n')
(e/'static-inspector-initial-failure.json').write_text(json.dumps({'status':'FAIL','stage':'review-tool exact function-delimiter binding','reason':'Extra leading newline in newly appended driver changed compared trailing boundary whitespace; extraction/formatter implementation unchanged','firstStaticOutput':'INADMISSIBLE after failed binding; no runtime tests launched by this step','correction':'remove only added driver leading newline and assert exact original function before writing; exact rebound inspector passed','productOrNameOracleChanged':False},indent=2)+'\n')
print(json.dumps({'verdict':review['verdict'],'ordinaryFocused':154,'currentFindings':1,'probeBehavior':'UNRUN'}))
