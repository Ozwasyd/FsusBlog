const fs=require('fs'),cp=require('child_process'),crypto=require('crypto'),ts=require('/workspace/runtime-borrow-install/node_modules/typescript');
const root='/workspace/runtime-flow-ack-review',e='/workspace/runtime-flow-ack-review-evidence';
const git=(...a)=>cp.execFileSync('git',a,{cwd:root}); const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const inspectValue=require('util').inspect;
const runtime='tests/frontend/unit/composables/useImageUploadRuntime.test.ts', api='tests/frontend/unit/api/upload.test.ts';
function inspect(ref,file){let s=git('show',ref+':'+file).toString(),a=ts.createSourceFile(file,s,ts.ScriptTarget.Latest,true),calls=[],hooks=[],imports=[];
 const unwrap=n=>ts.isAsExpression(n)||ts.isParenthesizedExpression(n)||ts.isSatisfiesExpression(n)?unwrap(n.expression):n;
 function val(n){n=unwrap(n);if(ts.isIdentifier(n)&&n.text==='undefined')return undefined;if(ts.isPropertyAccessExpression(n)&&n.expression.getText(a)==='uploadIds'){let d=a.statements.find(st=>ts.isVariableStatement(st)&&st.declarationList.declarations.some(v=>v.name.getText(a)==='uploadIds'));let init=d.declarationList.declarations.find(v=>v.name.getText(a)==='uploadIds').initializer;return val(init)[n.name.text];}if(ts.isStringLiteral(n)||ts.isNumericLiteral(n))return n.text;if(n.kind===ts.SyntaxKind.TrueKeyword)return true;if(n.kind===ts.SyntaxKind.FalseKeyword)return false;if(ts.isArrayLiteralExpression(n))return n.elements.map(val);if(ts.isObjectLiteralExpression(n))return Object.fromEntries(n.properties.filter(ts.isPropertyAssignment).map(p=>[p.name.getText(a),val(p.initializer)]));return n.getText(a);}
 function walk(n){if(ts.isImportDeclaration(n))imports.push(n.getText(a));if(ts.isCallExpression(n)){let x=n.expression.getText(a);if(['beforeEach','afterEach','vi.mock'].includes(x))hooks.push({kind:x,text:n.getText(a),sha256:sha(n.getText(a))});if(x==='it'||ts.isCallExpression(n.expression)&&n.expression.expression.getText(a)==='it.each'){let name=n.arguments[0];if(!ts.isStringLiteral(name))throw Error('nonliteral name');let names=[name.text];if(x!=='it'){let rows=val(n.expression.arguments[0]);if(!Array.isArray(rows))throw Error('nonarray each');names=rows.map(row=>{if(row&&typeof row==='object'&&!Array.isArray(row))return name.text.replace(/\$(\w+)/g,(_,k)=>inspectValue(row[k]));let vals=Array.isArray(row)?row:[row],i=0;return name.text.replace(/%[sdifjo]/g,()=>String(vals[i++]));});}calls.push({name:name.text,names,text:n.getText(a),sha256:sha(n.getText(a))});}}ts.forEachChild(n,walk);}walk(a);return {calls,hooks,imports,names:calls.flatMap(c=>c.names),parseDiagnostics:a.parseDiagnostics.length};}
const refs=['c93c4c37a58dd66fde473aa885552ea4663d4af3','22813e9b81db72a0d01b1a0752551a1f96ab9c89','0324e7adb18f8aecfa870e86dec1153046a9f782'];
let frames=Object.fromEntries(refs.map(ref=>[ref,Object.fromEntries([runtime,api].map(f=>[f,inspect(ref,f)]))]));
for(const [ref,files] of Object.entries(frames))for(const[f,v]of Object.entries(files)){
 if(v.parseDiagnostics||v.names.some(x=>!x)||new Set(v.names).size!==v.names.length)throw Error('AST boundary fail');
 fs.writeFileSync(e+'/'+ref.slice(0,12)+'-'+(f===runtime?'runtime':'api')+'-calls.json',JSON.stringify(v,null,2));
}
let retention=[];
for(const old of refs.slice(0,2))for(const file of [runtime,api]){
 let a=frames[old][file],b=frames[refs[2]][file];
 for(const c of a.calls){let matches=b.calls.filter(x=>x.name===c.name);if(matches.length!==1||matches[0].text!==c.text)throw Error('original complete call changed: '+c.name);}
 if(JSON.stringify(a.hooks)!==JSON.stringify(b.hooks)||JSON.stringify(a.imports)!==JSON.stringify(b.imports))throw Error('original hooks/imports changed');
 retention.push({old,current:refs[2],file,completeDeclarations:a.calls.length,expandedNames:a.names.length,allCompleteCallsHooksImportsByteIdentical:true});
}
const interfaceNames=['ImageUploadAttemptBinding','ImageUploadSessionAccess','ImageUploadSessionBorrow','ImageUploadRuntimeOptions'];
function interfaces(ref){let f='src/frontend/src/composables/useImageUploadRuntime.ts',a=ts.createSourceFile(f,git('show',ref+':'+f).toString(),ts.ScriptTarget.Latest,true);return Object.fromEntries(a.statements.filter(ts.isInterfaceDeclaration).filter(n=>interfaceNames.includes(n.name.text)).map(n=>[n.name.text,n.getText(a)]));}
let a=interfaces(refs[0]),b=interfaces(refs[2]);
for(const key of interfaceNames){let expected=key==='ImageUploadRuntimeOptions'?a[key].replace('onSessionReady?: (borrow: ImageUploadSessionBorrow) => void | Promise<void>;','onSessionReady?: (borrow: ImageUploadSessionBorrow, completionUrl: string) => void | Promise<void>;'):a[key];if(expected!==b[key])throw Error('unapproved interface change '+key);}
let prior=JSON.parse(fs.readFileSync('/workspace/runtime-init-boundary-review-evidence/retention-and-dependencies.json'));
let inputs=prior.originalBoundaryInputs.map(x=>({path:x.path,blob:git('rev-parse',refs[2]+':'+x.path).toString().trim(),originalBlob:x.blob}));
for(const x of inputs)if(!x.path.endsWith('useImageUploadFlow.ts')&&x.blob!==x.originalBlob)throw Error('original dependency boundary changed '+x.path);
for(const x of prior.remaining20Dependencies)if(git('rev-parse',refs[2]+':'+x.path).toString().trim()!==x.currentBlob)throw Error('original20 dependency changed '+x.path);
let author=e+'/author-published';
let nine=require('zlib').gunzipSync(fs.readFileSync(author+'/controls/original-nine.txt.gz'));
let now=git('show',refs[2]+':'+runtime);
if(sha(nine)!=='692dffe3770e3998dfbc6a5bd52bc84a22f86d775a318dca09414afaa645d83e'||now.toString().split(nine.toString()).length!==2)throw Error('original nine block binding');
let five=require('zlib').gunzipSync(fs.readFileSync(author+'/controls/added-five.txt.gz'));
if(now.toString().split(five.toString()).length!==2)throw Error('five block binding');
let removed=now.toString().replace(nine.toString(),'').replace(five.toString(),'');
if(removed!==git('show',refs[1]+':'+runtime).toString())throw Error('original140 full file not retained after only insertion removal');
let history=JSON.parse(fs.readFileSync(author+'/records/preserved-history-binding.json'));
for(const x of history.receipts){let original=git('show',x.originalCommit+':'+x.originalPath),copy=fs.readFileSync(author+'/'+x.copiedTo);if(!copy.equals(original)||sha(copy)!==x.sha256)throw Error('immutable author history changed');}
let summary={source:refs[2],parser:ts.version,readOnly:true,frames:Object.entries(frames).map(([ref,files])=>({ref,files:Object.entries(files).map(([file,v])=>({file,literalCalls:v.calls.length,expandedCount:v.names.length,names:v.names,imports:v.imports}))})),retention,interfaces:{onlyApprovedSecondReadonlyUrlArgument:true,pre:a,post:b},originalBoundaryInputs:inputs,remaining20Dependencies:prior.remaining20Dependencies,originalOwnerComparisons:prior.originalOwnerComparisons,originalNineBlockSha256:sha(nine),originalNineBlockBytes:nine.length,original140WholeFileRetained:true,immutableAuthorBeforeHistoryChecked:true,fullSourceOrHeldAdmission:false};
fs.writeFileSync(e+'/static-inspection.json',JSON.stringify(summary,null,2)+'\n');
console.log(JSON.stringify(summary.frames.map(x=>({ref:x.ref,counts:x.files.map(y=>y.expandedCount)}))));
