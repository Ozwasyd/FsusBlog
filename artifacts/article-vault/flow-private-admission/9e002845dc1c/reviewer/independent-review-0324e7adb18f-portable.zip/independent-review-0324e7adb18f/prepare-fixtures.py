import hashlib
import json
import pathlib
import shutil
import subprocess

r=pathlib.Path('/workspace/runtime-flow-ack-review')
e=pathlib.Path('/workspace/runtime-flow-ack-review-evidence')
source='0324e7adb18f8aecfa870e86dec1153046a9f782'
test='tests/frontend/unit/composables/useImageUploadRuntime.test.ts'
cases=[('before','/workspace/runtime-flow-ack-before','22813e9b81db72a0d01b1a0752551a1f96ab9c89')]
result=[]
for label,folder,ref in cases:
    subprocess.run(['git','worktree','add','--detach',folder,ref],cwd=r,check=True,capture_output=True)
    root=pathlib.Path(folder)
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
    data=subprocess.check_output(['git','show',source+':'+test],cwd=r)
    (root/test).write_bytes(data)
    changed=subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines()
    assert changed==[test]
    production=[]
    for path in ['src/frontend/src/composables/useImageUploadRuntime.ts','src/frontend/src/composables/useImageUploadFlow.ts','src/frontend/src/api/upload.ts','src/frontend/src/composables/useAdminArticleWrite.ts']:
        original=subprocess.check_output(['git','show',ref+':'+path],cwd=r)
        assert (root/path).read_bytes()==original
        production.append({'path':path,'baselineBlob':subprocess.check_output(['git','rev-parse',ref+':'+path],cwd=r,text=True).strip(),'sha256':hashlib.sha256(original).hexdigest(),'unchanged':True})
    for path in ['src/frontend/vitest.config.ts','src/frontend/vitest.shared.mjs','tests/frontend/support/unit/setup.ts','src/frontend/package.json','src/frontend/package-lock.json','tests/frontend/unit/api/upload.test.ts']:
        assert (root/path).read_bytes()==(r/path).read_bytes()
    (root/'src/frontend/node_modules').symlink_to('/workspace/runtime-borrow-install/node_modules',target_is_directory=True)
    shutil.copytree(r/'tools/test-matrix/schema-validator/node_modules',root/'tools/test-matrix/schema-validator/node_modules',symlinks=True)
    result.append({'label':label,'cwd':folder,'baselineHead':ref,'production':production,'testOverlay':{'path':test,'source':source,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()},'modifiedPaths':changed,'configHooksApiTestsPackagesByteIdentical':True,'qualification':False,'independentExactCurrentTestOverlay':'Whole154 test input retained; selecting same original9 gives129 runtime cases outside selector rather than author earlier124. Same original9 complete blocks/names, no test replacements.'})
(e/'fixture-binding.json').write_text(json.dumps(result,indent=2)+'\n')
print('Original before-control fixture prepared; production unchanged')
