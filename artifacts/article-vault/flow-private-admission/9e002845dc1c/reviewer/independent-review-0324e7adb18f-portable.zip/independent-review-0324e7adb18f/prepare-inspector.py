import hashlib
import pathlib

previous = pathlib.Path('/workspace/runtime-init-boundary-review-evidence/inspect-current.cjs').read_text()
header = previous.split('const refs=')[0]
header = header.replace("root='/workspace/runtime-init-boundary-review',e='/workspace/runtime-init-boundary-review-evidence'", "root='/workspace/runtime-flow-ack-review',e='/workspace/runtime-flow-ack-review-evidence'")
tail = r'''
const refs=['c93c4c37a58dd66fde473aa885552ea4663d4af3','22813e9b81db72a0d01b1a0752551a1f96ab9c89','0324e7adb18f8aecfa870e86dec1153046a9f782'];
let frames=Object.fromEntries(refs.map(ref=>[ref,Object.fromEntries([runtime,api].map(f=>[f,inspect(ref,f)]))]));
for(const [ref,files] of Object.entries(frames))for(const[f,v]of Object.entries(files)){
 if(v.parseDiagnostics||v.names.some(x=>!x)||new Set(v.names).size!==v.names.length)throw Error('AST boundary fail');
 fs.writeFileSync(e+'/'+ref.slice(0,12)+'-'+(f===runtime?'runtime':'api')+'-calls.json',JSON.stringify(v,null,2));
}
let retention=[];
for(const old of refs.slice(0,2))for(const file of [runtime,api]){
 let a=frames[old][file],b=frames[refs[2]][file];
 for(const c of a.calls){let matches=b.calls.filter(x=>x.name===c.name);if(matches.length!==1||matches[0].text!==c.text)throw Error('original complete call changed: '+c.name);}
 if(JSON.stringify(a.hooks)!==JSON.stringify(b.hooks)||JSON.stringify(a.imports)!==JSON.stringify(b.imports))throw Error('original hooks/imports changed');
 retention.push({old,current:refs[2],file,completeDeclarations:a.calls.length,expandedNames:a.names.length,allCompleteCallsHooksImportsByteIdentical:true});
}
const interfaceNames=['ImageUploadAttemptBinding','ImageUploadSessionAccess','ImageUploadSessionBorrow','ImageUploadRuntimeOptions'];
function interfaces(ref){let f='src/frontend/src/composables/useImageUploadRuntime.ts',a=ts.createSourceFile(f,git('show',ref+':'+f).toString(),ts.ScriptTarget.Latest,true);return Object.fromEntries(a.statements.filter(ts.isInterfaceDeclaration).filter(n=>interfaceNames.includes(n.name.text)).map(n=>[n.name.text,n.getText(a)]));}
let a=interfaces(refs[0]),b=interfaces(refs[2]);
for(const key of interfaceNames){let expected=key==='ImageUploadRuntimeOptions'?a[key].replace('onSessionReady?: (borrow: ImageUploadSessionBorrow) => void | Promise<void>;','onSessionReady?: (borrow: ImageUploadSessionBorrow, completionUrl: string) => void | Promise<void>;'):a[key];if(expected!==b[key])throw Error('unapproved interface change '+key);}
let prior=JSON.parse(fs.readFileSync('/workspace/runtime-init-boundary-review-evidence/retention-and-dependencies.json'));
let inputs=prior.originalBoundaryInputs.map(x=>({path:x.path,blob:git('rev-parse',refs[2]+':'+x.path).toString().trim(),originalBlob:x.blob}));
for(const x of inputs)if(!x.path.endsWith('useImageUploadFlow.ts')&&x.blob!==x.originalBlob)throw Error('original dependency boundary changed '+x.path);
for(const x of prior.remaining20Dependencies)if(git('rev-parse',refs[2]+':'+x.path).toString().trim()!==x.currentBlob)throw Error('original20 dependency changed '+x.path);
let author=e+'/author-published';
let nine=require('zlib').gunzipSync(fs.readFileSync(author+'/controls/original-nine.txt.gz'));
let now=git('show',refs[2]+':'+runtime);
if(sha(nine)!=='692dffe3770e3998dfbc6a5bd52bc84a22f86d775a318dca09414afaa645d83e'||now.toString().split(nine.toString()).length!==2)throw Error('original nine block binding');
let five=require('zlib').gunzipSync(fs.readFileSync(author+'/controls/added-five.txt.gz'));
if(now.toString().split(five.toString()).length!==2)throw Error('five block binding');
let removed=now.toString().replace(nine.toString(),'').replace(five.toString(),'');
if(removed!==git('show',refs[1]+':'+runtime).toString())throw Error('original140 full file not retained after only insertion removal');
let history=JSON.parse(fs.readFileSync(author+'/records/preserved-history-binding.json'));
for(const x of history.receipts){let original=git('show',x.originalCommit+':'+x.originalPath),copy=fs.readFileSync(author+'/'+x.copiedTo);if(!copy.equals(original)||sha(copy)!==x.sha256)throw Error('immutable author history changed');}
let summary={source:refs[2],parser:ts.version,readOnly:true,frames:Object.entries(frames).map(([ref,files])=>({ref,files:Object.entries(files).map(([file,v])=>({file,literalCalls:v.calls.length,expandedCount:v.names.length,names:v.names,imports:v.imports}))})),retention,interfaces:{onlyApprovedSecondReadonlyUrlArgument:true,pre:a,post:b},originalBoundaryInputs:inputs,remaining20Dependencies:prior.remaining20Dependencies,originalOwnerComparisons:prior.originalOwnerComparisons,originalNineBlockSha256:sha(nine),originalNineBlockBytes:nine.length,original140WholeFileRetained:true,immutableAuthorBeforeHistoryChecked:true,fullSourceOrHeldAdmission:false};
fs.writeFileSync(e+'/static-inspection.json',JSON.stringify(summary,null,2)+'\n');
console.log(JSON.stringify(summary.frames.map(x=>({ref:x.ref,counts:x.files.map(y=>y.expandedCount)}))));
'''
output = pathlib.Path('/workspace/runtime-flow-ack-review-evidence/inspect-current.cjs')
tail = tail.lstrip('\n')
original_function = previous[previous.index('function inspect('):previous.index('const refs=')]
current_function = (header + tail)[(header + tail).index('function inspect('):(header + tail).index('const refs=')]
assert current_function == original_function
output.write_text(header + tail)
pathlib.Path('/workspace/runtime-flow-ack-review-evidence/inspector-binding.json').write_text(
    __import__('json').dumps({'exactPreviousValidatedExtractAndFormatFunctionRetained':True,
        'extractFunctionSha256':hashlib.sha256(original_function.encode()).hexdigest(),
        'currentInspectorSha256':hashlib.sha256(output.read_bytes()).hexdigest(),
        'bindingsChangedOnly':'fresh root/output/three reviewed sources; explicit sole approved interface expectation and current source dependency comparisons',
        'noNameNormalizationOrOracleChanges':True},indent=2)+'\n')
