import gzip
import hashlib
import json
import os
import pathlib
import shutil
import subprocess

r = pathlib.Path('/workspace/runtime-flow-ack-review')
e = pathlib.Path('/workspace/runtime-flow-ack-review-evidence')
node = '/workspace/runtime-repair-review-evidence/node-setup/node-v24.16.0-linux-x64/bin/node'
ui = pathlib.Path('/workspace/runtime-borrow-ui')
source = '0324e7adb18f8aecfa870e86dec1153046a9f782'
published = 'd8d0e93f913ceecf9c4946df3ad9b0c0283ab8d7'
prefix = 'artifacts/article-vault/flow-ack-recovery/0324e7adb18f'
git = lambda *args: subprocess.check_output(['git', *args], cwd=r)
assert not git('status','--porcelain')
assert git('rev-parse','HEAD').decode().strip() == source
assert git('rev-parse','HEAD^{tree}').decode().strip() == '168b91f10b5713fdc11d723b4b058b4630e07eb8'
assert hashlib.sha256(pathlib.Path(node).read_bytes()).hexdigest() == 'b2959781cc5a74c357ffa02367efa8a0330cbb1c9cb347732fdfaaaca381cbcd'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ui,text=True).strip() == '0e5c56050e8dd3e9ca3735078489d35a0bb6e3d2'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=ui)
for path in git('ls-tree','-r','--name-only',published,prefix).decode().splitlines():
    target=e/'author-published'/path.removeprefix(prefix+'/')
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(git('show',published+':'+path))
manifest=json.loads((e/'author-published/manifest.json').read_text())
for item in manifest['files']:
    data=(e/'author-published'/item['path']).read_bytes()
    assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256']
new_paths=git('diff','--name-only','22813e9b81db72a0d01b1a0752551a1f96ab9c89',source).decode().splitlines()
assert sorted(new_paths)==sorted(['docs/architecture/overview.md','src/frontend/src/composables/useImageUploadRuntime.ts','src/frontend/src/composables/useImageUploadFlow.ts','tests/frontend/unit/composables/useImageUploadRuntime.test.ts'])
for path in new_paths:
    for side,ref in [('pre','22813e9b81db72a0d01b1a0752551a1f96ab9c89'),('post',source)]:
        assert gzip.decompress((e/'author-published/source-images'/side/(path+'.gz')).read_bytes()) == git('show',ref+':'+path)
assert gzip.decompress((e/'author-published/source-images/four-path.patch.gz').read_bytes()) == git('diff','22813e9b81db72a0d01b1a0752551a1f96ab9c89',source,'--',*new_paths)
evidence_delta=git('diff','--name-only',source,published).decode().splitlines()
assert all(path.startswith(prefix+'/') for path in evidence_delta)
commands=[]
prepare=[node,'src/frontend/scripts/prepare-local-fsusui-install.mjs','prepare','--frontend-root',str(r/'src/frontend'),'--fsusui-root',str(ui),'--output','/workspace/runtime-flow-ack-install-input']
commands.append(prepare)
subprocess.run(prepare,cwd=r,check=True,stdout=(e/'official-helper-prepare.log').open('w'),stderr=subprocess.STDOUT)
for path in ['package.json','package-lock.json']:
    assert pathlib.Path('/workspace/runtime-flow-ack-install-input',path).read_bytes() == pathlib.Path('/workspace/runtime-borrow-install',path).read_bytes()
(r/'src/frontend/node_modules').symlink_to('/workspace/runtime-borrow-install/node_modules',target_is_directory=True)
for folder in ['tools/test-matrix/schema-validator','tools/frontend/style-toolchain']:
    old=pathlib.Path('/workspace/runtime-init-boundary-review')/folder
    current=r/folder
    for path in ['package.json','package-lock.json']:
        assert (old/path).read_bytes() == (current/path).read_bytes()
    shutil.copytree(old/'node_modules',current/'node_modules',symlinks=True)
verify=[node,'src/frontend/scripts/prepare-local-fsusui-install.mjs','verify','--frontend-root',str(r/'src/frontend'),'--fsusui-root',str(ui)]
commands.append(verify)
subprocess.run(verify,cwd=r,check=True,stdout=(e/'official-helper-verify.log').open('w'),stderr=subprocess.STDOUT)
links=[]
for name in ['runtime-dom','runtime-core','reactivity','shared']:
    path=ui/'vue/packages/node_modules/@vue'/name
    assert not path.exists() and not path.is_symlink()
    path.parent.mkdir(parents=True,exist_ok=True)
    target=r/'src/frontend/node_modules/@vue'/name
    path.symlink_to(target,target_is_directory=True)
    actual=target.resolve()
    assert json.loads((actual/'package.json').read_text())['version']=='3.5.33'
    links.append({'path':str(path),'target':str(target),'physicalPath':str(actual),'version':'3.5.33'})
logger=pathlib.Path('/workspace/runtime-init-boundary-review-evidence/run-record.py').read_text()
logger=logger.replace('/workspace/runtime-init-boundary-review-evidence',str(e))
logger=logger.replace("env['FSUSBLOG_USE_LOCAL_FSUSUI'] = '1'", "env['FSUSBLOG_USE_LOCAL_FSUSUI'] = '1'\nenv['FSUSBLOG_RUN_ID'] = 'independent-flow-ack-' + label + '-0324e7adb18f'")
(e/'run-record.py').write_text(logger)
setup={'source':source,'tree':git('rev-parse','HEAD^{tree}').decode().strip(),'publishedEvidence':published,'authorManifestEntriesChecked':len(manifest['files']),
       'evidenceOnlyDelta':True,'actualFourPathOffer':new_paths,'imagesAndPatchExact':True,'commands':commands,
       'node':node,'nodeSha256':hashlib.sha256(pathlib.Path(node).read_bytes()).hexdigest(),'originalUI':'0e5c56050e8dd3e9ca3735078489d35a0bb6e3d2','vueLinks':links,
       'originalLockedInputBytesIdentical':True,'physicalSchemaStyleOriginalGraph':True,'sourceClean':not bool(git('status','--porcelain')),'authorEvidenceOnly':True}
(e/'setup.json').write_text(json.dumps(setup,indent=2)+'\n')
print(json.dumps({'setup':'PASS','authorManifestEntries':len(manifest['files']),'sourceClean':setup['sourceClean']}))
