import collections
import json
import pathlib
import re

e=pathlib.Path('/workspace/runtime-flow-ack-review-evidence')
r=pathlib.Path('/workspace/runtime-flow-ack-review')
s=json.loads((e/'static-inspection.json').read_text())
current=s['frames'][-1]
actual=json.loads((e/'discovery-tests.json').read_text())
actual_names=collections.Counter((pathlib.Path(x['file']).relative_to(r).as_posix(),x['name'].rsplit(' > ',1)[-1]) for x in actual)
static_names=collections.Counter((x['file'],name) for x in current['files'] for name in x['names'])
assert len(actual)==len(actual_names)==154 and actual_names==static_names
assert all(name and count==1 for (file,name),count in actual_names.items())
patterns={
    'positive2': (r'(runs compression and hashing before init, uploads every required part, then completes once|borrows actual compressed facts and retains a bound handle after public session and original lease clear)$',2),
    'nine': ('Flow consumer recovery',9),
    'five': ('Flow ACK handoff',5),
    'guard': ('Flow execution guard',1),
    'old28': ('(rejects uncorrelated init|rejects uncorrelated part ACK|retains unknown completion on uncorrelated complete ACK|carries the original token through the real GET|retains original obligations through the actual)',28),
    'old17': ('refuses unrepresentable upload filename|accepts a lossless 256-byte upload filename|checks the actual compressed filename|cancels a lossless boundary filename|rejects a zero GUID|encodes the actual 256-byte',17),
}
verified={}
for label,(pattern,count) in patterns.items():
    selected=[{'file':file,'name':name} for file,name in actual_names if re.search(pattern,name)]
    assert len(selected)==count
    verified[label]={'pattern':pattern,'count':count,'selected':selected}
for old in s['frames'][:-1]:
    old_names=collections.Counter((x['file'],name) for x in old['files'] for name in x['names'])
    assert not old_names-actual_names
preflight=json.loads((e/'preflight.json').read_text())
assert preflight['exitCode']==0 and preflight['source']==current['ref']
result={'status':'PASS','source':current['ref'],'preflight':'PASS0','actualCount':154,'nonemptyUniqueExactMultisets':True,
        'actualOnly':[],'staticOnly':[],'patterns':verified,'old139And140NamesRetained':True,'originalHooksImportsRunnerUnchanged':True}
(e/'selection.json').write_text(json.dumps(result,indent=2)+'\n')
print('Strict selection PASS154; original2/9/5/28/17 counts exact')
