import hashlib
import json
import pathlib
import shutil
import subprocess

r=pathlib.Path('/workspace/runtime-flow-ack-review')
e=pathlib.Path('/workspace/runtime-flow-ack-review-evidence')
root=pathlib.Path('/workspace/runtime-flow-ack-public-state-probe')
source='0324e7adb18f8aecfa870e86dec1153046a9f782'
path='tests/frontend/unit/composables/useImageUploadRuntime.test.ts'
probe=r'''
  it('Independent Flow recovery public flag reset must not clear or replace original File context', async () => {
    const file = fileOf(73), host = attachmentHost(), runtime = useImageUploadRuntime()
    const failure = new Error('independent-original-consumer-refused'), capture = vi.spyOn(host.owner, 'capture')
    const rejected = vi.fn()
    const flow = useImageUploadFlow({ runtime, getOptions: () => options, getWasmOnly: () => false,
      taskRegistry: host.documentOwner, onFileUploaded: async () => { throw failure } })
    await flow.startUpload({ files: [file], attachmentInput: { ...host, origin: 'pick' }, notifyOnError: false })
    const context = flow.pendingContext.value, snapshot = storedSnapshot()
    expect(runtime.cleanupRequired).toBe(true)
    expect(context?.files[0]).toBe(file)
    expect(capture).toHaveBeenCalledOnce()
    // Same writable public-state reset as the original retained author control.
    // It is not a canonical receiver or release acknowledgement.
    runtime.cleanupRequired = false
    flow.clearPending()
    expect.soft(flow.pendingContext.value === context).toBe(true)
    await flow.startUpload({ files: [fileOf(64, 'independent-replacement.png')],
      attachmentInput: { ...host, origin: 'pick' }, onError: rejected, notifyOnError: false })
    expect.soft(capture.mock.calls.length).toBe(1)
    expect.soft(flow.pendingContext.value === context).toBe(true)
    expect.soft(flow.pendingContext.value?.files[0] === file).toBe(true)
    expect(rejected).toHaveBeenCalledOnce()
    expect(rejected.mock.calls[0]![1].message).toBe('upload_completion_recovery_required')
    expect(storedSnapshot().snapshot).toEqual(snapshot.snapshot)
    const recovery = await runtime.abandon().catch(error => error)
    expect(recovery.cause).toBe(failure)
    expect(api.initUploadSession).toHaveBeenCalledOnce()
    expect(api.completeUpload).toHaveBeenCalledOnce()
    expect(api.abortUpload).not.toHaveBeenCalled()
  })

'''
subprocess.run(['git','worktree','add','--detach',str(root),source],cwd=r,check=True,capture_output=True)
original=(root/path).read_text()
marker="  it.each([\n    ['reviewer-258-byte'"
assert original.count(marker)==1
updated=original.replace(marker,probe+marker)
(root/path).write_text(updated)
assert subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines()==[path]
(root/'src/frontend/node_modules').symlink_to('/workspace/runtime-borrow-install/node_modules',target_is_directory=True)
shutil.copytree(r/'tools/test-matrix/schema-validator/node_modules',root/'tools/test-matrix/schema-validator/node_modules',symlinks=True)
(e/'public-state-probe.ts').write_text(probe)
(e/'public-state-probe-binding.json').write_text(json.dumps({'productionSource':source,'checkout':str(root),
    'testOriginalSource':source,'testOriginalSha256':hashlib.sha256(original.encode()).hexdigest(),
    'testCompositeSha256':hashlib.sha256(updated.encode()).hexdigest(),'probeSha256':hashlib.sha256(probe.encode()).hexdigest(),
    'modifiedPaths':[path],'allOriginal154CompleteCallsRetained':True,'newFixturesOrMocks':False,
    'usesOriginalFileOwnerDocumentIntentRegistryAndConfig':True,'expectedCount':1,'name':'Independent Flow recovery public flag reset must not clear or replace original File context',
    'scope':'bounded source probe, not original154 or server/Writer/receiver qualification','productSourceChanged':False},indent=2)+'\n')
print('Single bounded public-state source probe prepared; production unchanged')
