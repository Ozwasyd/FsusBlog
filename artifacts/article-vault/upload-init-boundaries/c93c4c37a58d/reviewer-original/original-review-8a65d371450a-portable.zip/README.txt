Portable original independent review, frozen source8a65d371450a48ff344f4ec42462e6d602b66c66

MUST_FIX F1: file-name wire truncation versus pre-encoding request comparison can refuse both valid own init and cancellation. F2: all-zero GUID accepted by front-end predicate but rejected by original backend. Original review.json, probe source/output, exact command/cwd/environment/tool records, original122 collected roster, static extraction algorithm/roster, five-path offer/bindings, history and author evidence are preserved byte-for-byte in separate subdirectories.

Name comparison diagnosis:121 exact file/name matches and one display mismatch. The static extractor treats the AST identifier undefined as the string "undefined", then quotes it; Vitest formats the actual value undefined without quotes. This is a reviewer algorithm/display difference, not an actual missing test, rename or input mismatch. No original selector assertion was edited; its FAIL and positive/focused/negative UNRUN remain.

Portable reproduction: use the included run-pure-probe.py with an original Node24.16 binary and TypeScript6.0.3 module. It verifies all frozen source byte digests, remaps only original absolute paths in a temporary copy of the original probe, and runs exactly the already-published five pure original functions with original appError. No transport, server, registry, unit tests or application qualification executes. Example:
python3 run-pure-probe.py --node /absolute/node-v24.16.0/bin/node --typescript /absolute/original-locked-node_modules/typescript --output /absolute/task-local-probe-output

Original command records contain execution-time absolute paths. Remap checkout/evidence/officialNode/originalCache/UI roots only when reviewing portability; do not edit locks, tests, source, config, setup, original assertions, host or parser. This package does not authorize restarting stopped dynamic execution. Await a new original-owner source for renewed independent selection/execution.

No source modification, push, GitHub mutation, issue closure, server/native/browser/migration/held QA, Writer integration, release/custody/receipt/product acceptance. Author results are author-only.
