using System.Buffers;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;

using FsusBlog.Shared.Contracts.Primitives;

namespace FsusBlog.Core.Mapping.Codecs;

public static class PodUtf8Codec
{
    private static readonly UTF8Encoding s_utf8 = new(false, true);

    internal static int GetSliceByteCount(string? value)
        => s_utf8.GetByteCount(value ?? string.Empty);

    internal static Utf8SliceRef CreateSliceRef(int offset, int length)
    {
        if (offset < 0)
        {
            throw new ArgumentOutOfRangeException(nameof(offset));
        }

        if (length < 0)
        {
            throw new ArgumentOutOfRangeException(nameof(length));
        }

        _ = checked(offset + length);
        return CreateSlice(offset, length);
    }

    internal static void WriteSliceBytes(
        string? value,
        IBufferWriter<byte> destination,
        int expectedByteCount)
    {
        ArgumentNullException.ThrowIfNull(destination);
        if (expectedByteCount < 0)
        {
            throw new ArgumentOutOfRangeException(nameof(expectedByteCount));
        }

        string text = value ?? string.Empty;
        if (expectedByteCount == 0)
        {
            if (text.Length != 0)
            {
                int actual = s_utf8.GetByteCount(text);
                if (actual != 0)
                {
                    throw new InvalidOperationException(
                        $"UTF-8 slice length changed between planning and writing: expected 0, wrote {actual}.");
                }
            }

            return;
        }

        Span<byte> target = destination.GetSpan(expectedByteCount)[..expectedByteCount];
        int written = s_utf8.GetBytes(text.AsSpan(), target);
        if (written != expectedByteCount)
        {
            target.Clear();
            throw new InvalidOperationException(
                $"UTF-8 slice length changed between planning and writing: expected {expectedByteCount}, wrote {written}.");
        }

        destination.Advance(written);
    }

    public static Utf8Fixed32 ToFixed32(string? value) => EncodeFixed<Utf8Fixed32>(value);

    public static Utf8Fixed64 ToFixed64(string? value) => EncodeFixed<Utf8Fixed64>(value);

    public static Utf8Fixed128 ToFixed128(string? value) => EncodeFixed<Utf8Fixed128>(value);

    public static Utf8Fixed256 ToFixed256(string? value) => EncodeFixed<Utf8Fixed256>(value);

    public static Utf8Fixed512 ToFixed512(string? value) => EncodeFixed<Utf8Fixed512>(value);

    public static string FromFixed32(in Utf8Fixed32 value) => DecodeFixed(value);

    public static string FromFixed64(in Utf8Fixed64 value) => DecodeFixed(value);

    public static string FromFixed128(in Utf8Fixed128 value) => DecodeFixed(value);

    public static string FromFixed256(in Utf8Fixed256 value) => DecodeFixed(value);

    public static Utf8SliceRef AppendSlice(string? value, List<byte> payload)
    {
        string text = value ?? string.Empty;
        int offset = payload.Count;
        int byteCount = s_utf8.GetByteCount(text);
        if (byteCount > 0)
        {
            payload.EnsureCapacity(offset + byteCount);
            CollectionsMarshal.SetCount(payload, offset + byteCount);

            try
            {
                Span<byte> span = CollectionsMarshal.AsSpan(payload).Slice(offset, byteCount);
                int written = s_utf8.GetBytes(text.AsSpan(), span);
                if (written != byteCount)
                {
                    CollectionsMarshal.SetCount(payload, offset + written);
                    byteCount = written;
                }
            }
            catch
            {
                CollectionsMarshal.SetCount(payload, offset);
                throw;
            }
        }

        return CreateSlice(offset, byteCount);
    }

    public static Utf8SliceRef AppendSlice(string? value, ArrayBufferWriter<byte> payload)
    {
        string text = value ?? string.Empty;
        int offset = payload.WrittenCount;
        int byteCount = s_utf8.GetByteCount(text);
        if (byteCount > 0)
        {
            Span<byte> span = payload.GetSpan(byteCount);
            int written = s_utf8.GetBytes(text.AsSpan(), span);
            payload.Advance(written);
        }

        return CreateSlice(offset, byteCount);
    }

    public static string ReadSlice(in Utf8SliceRef slice, ReadOnlySpan<byte> payload)
    {
        if (slice.Length <= 0 || payload.Length == 0)
        {
            return string.Empty;
        }

        if (slice.Offset < 0 || slice.Offset + slice.Length > payload.Length)
        {
            return string.Empty;
        }

        return s_utf8.GetString(payload.Slice(slice.Offset, slice.Length));
    }

    public static string ReadSlice(in Utf8SliceRef slice, byte[] payload)
    {
        return ReadSlice(slice, payload.AsSpan());
    }

    private static T EncodeFixed<T>(string? value) where T : unmanaged
    {
        T pod = default;
        Span<T> one = stackalloc T[1];
        one[0] = pod;
        Span<byte> bytes = MemoryMarshal.AsBytes(one);
        bytes.Clear();

        if (!string.IsNullOrEmpty(value))
        {
            int byteCount = s_utf8.GetByteCount(value);
            if (byteCount > bytes.Length)
            {
                throw new ArgumentException(
                    $"Fixed UTF-8 POD field can hold at most {bytes.Length} bytes, but the value requires {byteCount} bytes.",
                    nameof(value));
            }

            _ = s_utf8.GetBytes(value.AsSpan(), bytes);
        }

        return one[0];
    }

    private static string DecodeFixed<T>(in T value) where T : unmanaged
    {
        ReadOnlySpan<T> one = MemoryMarshal.CreateReadOnlySpan(ref Unsafe.AsRef(in value), 1);
        ReadOnlySpan<byte> bytes = MemoryMarshal.AsBytes(one);
        int end = bytes.IndexOf((byte)0);
        int length = end >= 0 ? end : bytes.Length;
        return length == 0 ? string.Empty : s_utf8.GetString(bytes[..length]);
    }

    private static Utf8SliceRef CreateSlice(int offset, int length)
    {
        MutableSlice temp = new()
        {
            Offset = offset,
            Length = length
        };
        Span<MutableSlice> source = stackalloc MutableSlice[1];
        source[0] = temp;
        ReadOnlySpan<byte> bytes = MemoryMarshal.AsBytes(source);
        return MemoryMarshal.Read<Utf8SliceRef>(bytes);
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    private struct MutableSlice
    {
        public int Offset;
        public int Length;
    }
}
