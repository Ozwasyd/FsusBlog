import difflib, gzip, hashlib, json, pathlib, subprocess, tempfile

repo = pathlib.Path('/workspace/chain2258-upload-source-recovery')
scratch = pathlib.Path('/workspace/chain-1975-evidence/upload-source-recovery-20261011')
master = '9d72a1c93b297f719d8695a642cdfb1615cf1d51'
observation_source = '48f123c3e20e69caa5b63b07409056a419abf9ce'
preview = '66fa8b0e6c6bc8b7555275ca9fb8feb220d3fd1f'
facts = '4cfdbbf9542f14eab305642aabb968fb6b3179bd'
old_head = '61d686739fca17aa3f3fad3840de315c4d35eabe'
targets = {'master':master,'after-observation-48f123c3':observation_source,'writer-7b203a3f':'7b203a3f4fd8346f05b7aeb176eb653bdb4b2fc9','writer-5e324f1d':'5e324f1d582866242cc90cdb5a7e4d3f5631355a'}
out = repo/'artifacts/article-vault/upload-source-recovery/20261011'
assert not out.exists()
def git(*args): return subprocess.check_output(['git',*args],cwd=repo)
def show(ref,path):
    r=subprocess.run(['git','show',ref+':'+path],cwd=repo,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
    return r.stdout if r.returncode==0 else None
def sha(b): return hashlib.sha256(b).hexdigest()
def put(path,b):
    p=out/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
def js(path,value): put(path,(json.dumps(value,indent=2,ensure_ascii=False)+'\n').encode())
def gz(path,b): put(path,gzip.compress(b,mtime=0))
def change_once(text,needle,replacement):
    assert text.count(needle)==1,needle
    return text.replace(needle,replacement)
assert git('rev-parse','HEAD').decode().strip()==observation_source
assert not git('status','--porcelain').strip()

# Exact original producer files, without cleanup/input or unrelated implementation.
direct = {
 'src/backend/Interfaces/UploadAssetObservation.cs':preview,
 'src/backend/Interfaces/UploadAssetPreview.cs':preview,
 'src/backend/Services/FileService.AssetObservation.cs':preview,
 'src/backend/Modules/Endpoints/Binary/BinaryEndpoints.UploadAssetFacts.cs':facts,
 'src/shared/Contracts/Outputs/UploadAssetPreviewDto.cs':preview,
 'src/shared/Contracts/Outputs/UploadAssetFactsDto.cs':facts,
 'src/shared/Contracts/Models/UploadAssetPreviewPod.cs':preview,
 'src/core/Cache/PodBinaryCodec.UploadAssetPreview.cs':facts,
 'src/frontend/wasm/aeds/include/upload_asset_preview_pod.hpp':facts,
}
original = {p:show(ref,p) for p,ref in direct.items()}
assert all(original.values())
obs_path='src/backend/Services/FileService.AssetObservation.cs'
old=show(old_head,obs_path).decode()
start=old.index('    public Task<Result<UploadAssetPreview>> ReadCommittedUploadInputAsync(')
end=old.index('    private async Task<Result<UploadAssetPreview>> ReadCommittedUploadObservationAsync(',start)
assert (old[:start]+old[end:]).encode()==original[obs_path]
route_path='src/backend/Modules/Endpoints/Binary/BinaryEndpoints.Uploads.cs'
old_routes=show(preview,route_path).decode()
route_start=old_routes.index('        uploadGroup.MapPost("/{uploadId}/preview"')
route_end=old_routes.index('        uploadGroup.MapDelete(',route_start)
preview_route=old_routes[route_start:route_end]
handler_start=old_routes.index('    internal static async Task<BinaryFrameResult> HandleUploadAssetPreviewAsync(')
handler_end=old_routes.index('    internal static async Task<BinaryFrameResult> HandleUploadPartAsync(',handler_start)
preview_handler=old_routes[handler_start:handler_end]
native='src/frontend/wasm/aeds/src/aeds_decode.cpp'
old_native=show(facts,native).decode()
facts_size_start=old_native.index('    if (FrameType == static_cast<std::uint16_t>(FrameType::UploadAssetFacts)')
facts_size_end=old_native.index('    const std::uint8_t* payload',facts_size_start)
facts_size=old_native[facts_size_start:facts_size_end]
native_start=old_native.index('    if (FrameType == static_cast<std::uint16_t>(FrameType::UploadAssetFacts)',facts_size_end)
native_end=old_native.index('    DecodeResult ok{};',native_start)
native_parsers=old_native[native_start:native_end]
assert 'ParseFacts' in native_parsers and 'FrameType == 275' in native_parsers
symbols={
 'IFileService.ObserveCommittedUploadAsync':'src/backend/Interfaces/IFileService.cs',
 'IFileService.ReadCommittedUploadPreviewAsync':'src/backend/Interfaces/IFileService.cs',
 'UploadAssetObservation':'src/backend/Interfaces/UploadAssetObservation.cs',
 'UploadAssetPreview':'src/backend/Interfaces/UploadAssetPreview.cs',
 'HandleUploadAssetPreviewAsync':route_path,
 'MapBinaryUploadAssetFactsEndpoints':'src/backend/Modules/Endpoints/Binary/BinaryEndpoints.UploadAssetFacts.cs',
 'HandleUploadAssetFactsAsync':'src/backend/Modules/Endpoints/Binary/BinaryEndpoints.UploadAssetFacts.cs',
 'UploadAssetPreviewDto':'src/shared/Contracts/Outputs/UploadAssetPreviewDto.cs',
 'UploadAssetFactsDto':'src/shared/Contracts/Outputs/UploadAssetFactsDto.cs',
 'UploadAssetPreviewPod':'src/shared/Contracts/Models/UploadAssetPreviewPod.cs',
 'WriteUploadAssetPreview':'src/core/Cache/PodBinaryCodec.UploadAssetPreview.cs',
 'WriteUploadAssetFacts':'src/core/Cache/PodBinaryCodec.UploadAssetPreview.cs',
 'ParseFacts':'src/frontend/wasm/aeds/include/upload_asset_preview_pod.hpp',
}
all_bindings=[];static_checks=[];protocol=[];dependency_rows=[]
for target,ref in targets.items():
    post=dict(original)
    interface_path='src/backend/Interfaces/IFileService.cs'
    text=show(ref,interface_path).decode()
    extra=''
    if 'ObserveCommittedUploadAsync' not in text:
        extra+='        Task<Result<UploadAssetObservation>> ObserveCommittedUploadAsync(UploadSessionAccess access, string sha256, CancellationToken cancellationToken = default);\n'
    assert 'ReadCommittedUploadPreviewAsync' not in text
    extra+='        Task<Result<UploadAssetPreview>> ReadCommittedUploadPreviewAsync(UploadSessionAccess access, string sha256, CancellationToken cancellationToken = default);\n'
    needle='        Task<Result<bool>> AbortUploadAsync('
    at=text.index(needle);post[interface_path]=(text[:at]+extra+text[at:]).encode()
    text=show(ref,route_path).decode()
    assert 'HandleUploadAssetPreviewAsync' not in text and 'MapBinaryUploadAssetFactsEndpoints' not in text
    at=text.index('        uploadGroup.MapDelete(');text=text[:at]+preview_route+text[at:]
    at=text.index('    internal static async Task<BinaryFrameResult> HandleUploadPartAsync(');text=text[:at]+preview_handler+text[at:]
    needle='            .AddEndpointFilterWithMetadata<RequiresPowFilter>();\n'
    text=change_once(text,needle,needle+'\n        MapBinaryUploadAssetFactsEndpoints(uploadGroup);\n')
    post[route_path]=text.encode()
    validation='src/shared/Contracts/Validation/PodContractValidation.cs'
    text=show(ref,validation).decode();needle='            && IsReferenceFree<UploadCompletePod>()\n'
    post[validation]=change_once(text,needle,needle+'            && IsReferenceFree<UploadAssetPreviewPod>()\n').encode()
    catalog='src/shared/Contracts/Validation/PodSizeCatalog.cs'
    text=show(ref,catalog).decode();needle='    public static readonly int UploadCompletePod = PodContractValidation.SizeOf<UploadCompletePod>();\n'
    post[catalog]=change_once(text,needle,needle+'    public static readonly int UploadAssetPreviewPod = PodContractValidation.SizeOf<UploadAssetPreviewPod>();\n').encode()
    errors='src/frontend/wasm/aeds/include/aeds_decode.hpp'
    text=show(ref,errors).decode();needle='    FontThemePayloadInvalid = 10'
    post[errors]=change_once(text,needle,'    UploadAssetPreviewPayloadInvalid = 16,\n    UploadAssetFactsPayloadInvalid = 20,\n'+needle).encode()
    text=show(ref,native).decode();needle='#include "font_theme_admin_pods.hpp"\n'
    text=change_once(text,needle,'#include "upload_asset_preview_pod.hpp"\n'+needle)
    needle='        case ErrorCode::FontThemePayloadInvalid:'
    text=change_once(text,needle,'        case ErrorCode::UploadAssetPreviewPayloadInvalid:\n            return "upload_asset_preview_payload_invalid";\n        case ErrorCode::UploadAssetFactsPayloadInvalid:\n            return "upload_asset_facts_payload_invalid";\n'+needle)
    needle='    const std::uint8_t* payload = frame + kHeaderSize;'
    text=change_once(text,needle,facts_size+needle)
    needle='    DecodeResult ok{};'
    text=change_once(text,needle,native_parsers+needle)
    post[native]=text.encode()
    assert len(post)==15
    for symbol,path in symbols.items():assert symbol.split('.')[-1] in post[path].decode(),symbol
    assert 'ReadCommittedUploadInputAsync' not in post[interface_path].decode()
    assert b'RecordAttachmentCleanupAsync' not in post[obs_path]
    # Produce and apply exact Git source deltas only in a disposable text fixture.
    with tempfile.TemporaryDirectory(prefix='upload-source-text-',dir=scratch) as directory:
        fixture=pathlib.Path(directory)
        def local(*args,**kw):
            result=subprocess.run(['git',*args],cwd=fixture,stdout=subprocess.PIPE,stderr=subprocess.PIPE,**kw)
            if result.returncode:
                print(result.stderr.decode())
                raise subprocess.CalledProcessError(result.returncode,result.args,result.stdout,result.stderr)
            return result
        local('init','--quiet')
        before={path:show(ref,path) for path in post}
        for path,b in before.items():
            if b is not None:
                dest=fixture/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
        local('add','--all');tree=local('write-tree').stdout.decode().strip()
        for path,b in post.items():
            dest=fixture/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
        local('add','--all');patch=local('diff','--cached','--binary',tree).stdout
        gz('targets/'+target+'/source.patch.gz',patch)
        local('read-tree',tree)
        for path,b in before.items():
            dest=fixture/path
            if b is None:dest.unlink()
            else:dest.write_bytes(b)
        local('update-index','--refresh')
        local('apply','--check','--index','-',input=patch)
        local('apply','--index','-',input=patch)
        assert all((fixture/path).read_bytes()==b for path,b in post.items())
        check=local('diff','--cached','--name-only',tree).stdout.decode().splitlines()
        expected_changes={path for path in post if before[path]!=post[path]}
        assert set(check)==expected_changes
        local('apply','--reverse','--check','-',input=patch)
        static_checks.append({'target':target,'targetCommit':ref,'postimagePaths':15,'changedPaths':len(check),'patchSha256':sha(patch),'gitApplyCheckExit':0,'gitApplyExit':0,'allAppliedBytesEqualPostimages':True,'reverseCheckExit':0,'textFixtureRemoved':True,'productCodeExecuted':False})
    for path,b in sorted(post.items()):
        base=show(ref,path)
        origin=direct.get(path)
        all_bindings.append({'target':target,'targetCommit':ref,'path':path,'before':None if base is None else {'bytes':len(base),'sha256':sha(base),'blob':git('rev-parse',ref+':'+path).decode().strip()},'post':{'bytes':len(b),'sha256':sha(b)},'originalWholeFileCommit':origin,'exactWholeFileEqualOrigin':origin is not None and b==show(origin,path),'extraction':'whole exact original file' if origin else 'original owned hunks joined into target while preserving unrelated text','postimage':'targets/'+target+'/postimages/'+path+'.gz'})
        gz('targets/'+target+'/postimages/'+path+'.gz',b)
    m=json.loads(show(ref,'src/shared/Contracts/Validation/aeds-protocol.json'))
    frames=[f for f in m['frameTypes'] if f['name'] in ['UploadAssetPreview','UploadAssetFacts']]
    generated=[]
    for path in ['src/core/Algorithms/AedsFrameType.cs','src/shared/AedsFrameHeader.cs','src/frontend/wasm/aeds/include/aeds_frame.hpp','src/frontend/wasm/web/protocol/frame.ts']:
        b=show(ref,path);generated.append({'path':path,'sha256':sha(b),'previewPresent':b'UploadAssetPreview' in b,'factsPresent':b'UploadAssetFacts' in b})
    protocol.append({'target':target,'targetCommit':ref,'manifestBlob':git('rev-parse',ref+':src/shared/Contracts/Validation/aeds-protocol.json').decode().strip(),'manifestSha256':sha(show(ref,'src/shared/Contracts/Validation/aeds-protocol.json')),'frameCount':len(m['frameTypes']),'actualEntries':frames,'fourExistingGeneratedSources':generated,'offerModifiesProtocolOrGeneratedEnum':False,'status':'existing complete named source allocation; no runtime/golden qualification claimed' if len(frames)==2 else 'BLOCKED activation: canonical Shared owner must join Preview275/Facts285 into complete current target roster; source generator and frozen outputs untouched'})
    for path in ['src/backend/Services/FileService.cs','src/shared/Algorithms/IO/NativeRegularFileGuard.cs','src/backend/Contracts/Assets/ContentAssetMediaInspector.cs','src/backend/Contracts/Assets/AssetRecord.cs','src/backend/Contracts/Assets/AssetReference.cs','src/backend/Entities/ContentAsset.cs','src/backend/Entities/ContentAssetReference.cs','src/core/Cache/PodBinaryCodec.Upload.cs','src/backend/Modules/Endpoints/Binary/BinaryEndpoints.cs']:
        b=show(ref,path)
        if b is None: continue
        dependency_rows.append({'target':target,'path':path,'blob':git('rev-parse',ref+':'+path).decode().strip(),'sha256':sha(b),'unchanged':True})
    file_service=show(ref,'src/backend/Services/FileService.cs').decode()
    for required in ['sealed partial class FileService','_scopeFactory','_storagePaths','_publicAssetUrlCodec','AcquireSessionLockAsync','LoadAuthorizedSessionAsync','TryNormalizeUploadId','NormalizeExtension','MimeTypeForExtension','MaxUploadBytes']:
        assert required in file_service,(target,required)
    guard=show(ref,'src/shared/Algorithms/IO/NativeRegularFileGuard.cs').decode()
    for required in ['OpenOriginalRegularFile','CaptureOriginalRegularFileIdentity','ValidateOriginalRegularFileUnchanged']:
        assert required in guard

js('postimage-bindings.json',{'sourceRecoveryOnly':True,'appliedToProductWorktrees':False,'rows':all_bindings,'qualification':False})
js('source-apply-verification.json',{'kind':'Git text/source verification, not test execution or discovery','records':static_checks,'qualification':False})
js('protocol-target-state.json',{'records':protocol,'originalAllocations':[{'name':'UploadAssetPreview','value':275,'goldenOrder':266,'originalCommit':'77d5a0602692da09a37ead6f544b1f09322b597a'},{'name':'UploadAssetFacts','value':285,'goldenOrder':267,'originalCommit':facts}],'goldenOrderIsBoundToCompleteRoster':'original268 and Writer263 source graphs differ; no renumbering/overwriting or frozen-catalog generation in this task','canonicalSharedRequest':'exact parent-supplied current-master protocol closure and owner-approved complete roster required before master activation','qualification':False})
js('original-protocol-entries.json',{'historicalOriginalManifest':facts,'entries':[f for f in json.loads(show(facts,'src/shared/Contracts/Validation/aeds-protocol.json'))['frameTypes'] if f['name'] in ['UploadAssetPreview','UploadAssetFacts']],'notAnActiveManifest':True,'notApplied':True,'qualification':False})
js('unchanged-source-dependencies.json',{'rows':dependency_rows,'masterNativeGuardExactOldSource':show(master,'src/shared/Algorithms/IO/NativeRegularFileGuard.cs')==show(old_head,'src/shared/Algorithms/IO/NativeRegularFileGuard.cs'),'nativeExecution':'UNRUN/HELD','qualification':False})
orig_observe='982430c1c696e51715e1fb9587acbc2f61ec8902'
js('original-source-lineage.json',{'originalObservation':{'pr':3813,'implementationCommit':orig_observe,'serviceBlob':git('rev-parse',orig_observe+':'+obs_path).decode().strip(),'schema':'fsusblog.upload-asset-observation.v1','contract':'original owner/token/expiry session, completed status, AssetId1779 lock, original native bytes/media/digest and canonical asset/reference ledger; no article grant/Vault receipt'},'preview':{'pr':4068,'head':old_head,'transportCommit':preview,'allocationCommit':'77d5a0602692da09a37ead6f544b1f09322b597a','recordAndTransportBoundToSameObservation':True,'existingAt4170':'c6fb31f1cef6953cbe210ce23c8c281b9e0ff16f'},'facts':{'originalImplementationCommit':facts,'savedOwnBranch':'codex/chain-1975-provider-facts-only','savedHead':'de10f195911ec945da11537986911209f25b3fb6','endpoint':'POST /api/binary/upload/{uploadId}/facts','request':'UploadCompleteRequest:64 payload bytes','response':'UploadAssetFacts285/fsusblog.upload-asset-facts.v1:760 payload bytes, no image bytes','service':'original ObserveCommittedUploadAsync','encoder':'original WriteUploadAssetFacts','notNewlyInvented':True},'excluded':'ReadCommittedUploadInputAsync and cleanup business, commit/promotion integrity modifications, unrelated Canvas/workspace/writing-aid definitions and inherited branches','oldHistoricalTestReceipts':'not consumed, rerun, refreshed or promoted','qualification':False})
js('writer-symbol-offer.json',{'symbols':symbols,'targetMaster':master,'writerParentSupplied':targets['writer-7b203a3f'],'writerCurrentRead':targets['writer-5e324f1d'],'writerHeadDiscrepancy':'current read head5e differs from supplied7b; both exact target offers retained; neither branch merged or incorporated','ordinarySourceClosure':'15 target-specific files including actual endpoint join, IFileService/original observation reader, shared DTO/POD, C# encoder and native parser source','requiresBeforeAnyActivation':['canonical complete current-master frame allocation/source projections if using master','owner joins through existing real source; no fake OpenAPI/runtime observation','all held acceptance and original #2258 prerequisites remain necessary'], 'existingSourceCorrection':'Writer actual7b/5e manifests and four generated source enums already contain275/285; stale missing-manifest text is not current source evidence','consumerBoundary':'Writer/layout must retain their existing DTO/decoder/API callsite source via canonical owners; this offer does not overwrite frontend products or compose Writer','qualification':False})
js('held-gates.json',{'tests':'NOT RUN','testListOrDiscovery':'NOT RUN','buildTypeLintProductExecution':'NOT RUN','frozenAuthorityRefresh':'NOT RUN; OpenAPI, route generation, AEDS golden catalogs, matrix, receipt and current-run authorities unchanged','assets1975':'PAUSED; no asset switching/native/migration/backup/security/receipt qualification','issue1976':'waiting actual1975','issue2258':'source offer only; whole provider/rights/reference/cleanup/product acceptance OPEN','registryPackage':'held, no package installation/publication','allPriorHolds':'preserved including business receiver/canonical receipt, Writer/host, server/native/browser/security/custody/race and global merge barrier','qualification':False})
binding=json.loads((scratch/'observation-source-binding.json').read_text())
binding['recoveredSourceCommit']=observation_source
binding['noNewFrameOrTransport']=True
for row in binding['files']:
    data=show(observation_source,row['path']);assert sha(data)==row['sha256'];assert data==show(binding['original'],row['path'])
js('recovered-observation-source.json',binding)
gz('recovered-observation-source.patch.gz',(scratch/'original-observation-source.patch').read_bytes())
put('observation-remote-readback.txt',(scratch/'observation-remote-readback.txt').read_bytes())
js('preparation-history.json',{'firstAttempt':json.loads((scratch/'first-source-apply-failure.json').read_text()),'secondAttempt':{'phase':'writer7b text fixture source metadata aggregation','failure':'asserted15 changed paths, but original UploadAssetObservation record already exactly present so14 changed plus1 retained postimage','actualBeforeAssertion':'git apply --check and actual text apply succeeded, all15 applied bytes matched','effect':'TemporaryDirectory removed, no product source changes','correction':'assert exact set of genuinely changed target leaves, separately count15 postimages and14 Writer changes'},'currentAttempt':'all three full source apply/reverse/byte checks succeed; prior incomplete offers retained in task scratch','testsRun':False,'qualification':False})
put('README.md',('''# Historical #2258 ordinary upload source offer — UNAPPLIED

This narrow source offer is based on verified current origin/master
`9d72a1c93b297f719d8695a642cdfb1615cf1d51`. It preserves every existing worktree;
the offer commit changes only this artifact directory. Its preceding standalone
source commit **48f123c3e20e69caa5b63b07409056a419abf9ce** independently restores the
original observation service/record/IFileService declaration and its current
boundary document: all four complete files are byte-identical to original982430c1.
That source uses only existing master dependencies and adds no frame or transport.
No preview/facts offer was activated, frozen authority or test/discovery
configuration changed, or product code executed. All original holds remain.

There are **15 complete target-specific source postimages** and one exact Git patch
for each of master, recovered observation48f123c3, parent-supplied Writer `7b203a3f4fd8346f05b7aeb176eb653bdb4b2fc9`
and current read-only Writer `5e324f1d582866242cc90cdb5a7e4d3f5631355a`.
Each patch actually passed `git apply --check --index`, application, byte equality
against every offered postimage, and reverse-check in its own disposable text-only
fixture. These are source/Git checks, not repository tests, build, discovery or
native/server/product qualification. The patches remain UNAPPLIED to all product
worktrees. Postimages/patches use lossless gzip, preserving original bytes.
Master patch changes15 paths; observation48 and each Writer patch change14 and retain the already
exact original UploadAssetObservation record as the15th postimage. Source-fixture
preparation failures are preserved in preparation-history.json, not promoted.

## Existing implementation recovered, not reinvented

Original #3813/`982430c1c696e51715e1fb9587acbc2f61ec8902` owns
`ObserveCommittedUploadAsync`: original authenticated owner/token/expiry session,
completed status, actual AssetId1779 lock, native regular-file identity/bytes/media
and current sole asset/reference ledger. Observation grants no article rights,
verified intent, Vault plan/operation/revision or reference/cleanup receipt.

Preview already exists in #4068 `61d686739fca17aa3f3fad3840de315c4d35eabe` and #4170
`c6fb31f1cef6953cbe210ce23c8c281b9e0ff16f`. The minimal service postimage is **exact
`66fa8b0e6c6bc8b7555275ca9fb8feb220d3fd1f`**, byte-equal to61d after excluding its
unused server-only `ReadCommittedUploadInputAsync`; no new read authority was made.
The preview route/handler retain original ArticleWrite/PoW, request decoder,
owner/token grants, no-store response and frame275. Same-observation original bytes
are limited to8,387,832, keeping a760-byte POD plus16-byte frame below8MiB.

The saved own branch additionally contains **real facts source**, original
`4cfdbbf9542f14eab305642aabb968fb6b3179bd`, retained at
`de10f195911ec945da11537986911209f25b3fb6`. It contains actual
`MapBinaryUploadAssetFactsEndpoints`/`HandleUploadAssetFactsAsync`,
`UploadAssetFactsDto`, `WriteUploadAssetFacts` and original native facts parser.
The route is wired inside the original ArticleWrite/PoW upload group and calls
the same original `ObserveCommittedUploadAsync`. Facts285 has64-byte original
request payload and760-byte closed metadata response, no image bytes; its20MiB
limit does not bypass real original file/ledger observation. No test-only service,
second ledger/queue, URL-to-AssetId inference or new grant was introduced.

Nine postimage leaves are exact original whole-file bytes; six are narrowly
extracted original owned hunks joined into each target while preserving all other
target text. See [path/postimage/hash bindings](postimage-bindings.json),
[actual source apply checks](source-apply-verification.json),
[original provenance](original-source-lineage.json) and
[Writer required symbols](writer-symbol-offer.json). FileService.cs, native guard,
asset entities/contracts, original request codec and endpoint helpers are retained
dependencies; master native guard is byte-identical to the original donor.
Original commit/part integrity or cleanup-business changes are excluded.

## Protocol stage and exact blocker

Master has244 frames and lacks275/285. The original268-frame source gives golden
orders266/267. Writer7b/current5e instead has263 frames and actual275/285 entries
at261/262; **all four existing C#/TS/C++ generated frame sources also contain both**.
The old Writer document saying its formal facts manifest is missing is stale.
The actual missing files are endpoint/service/DTO/POD/codec joins, which this offer
supplies. The generator requires goldenOrder to completely cover the target roster;
therefore the original266/267 entries alone cannot be stamped onto244-frame master.

No protocol manifest/enums were overwritten, renumbered or generated. The original
two source entries are included only as **historical, inactive input**. A canonical
Shared owner must provide the parent-confirmed complete current-master protocol
join before the master offer can activate. Do not use unrelated inherited Canvas,
workspace or writing-aid frame definitions from an old branch to fill this gap.
Writer-target patches retain their already-existing manifest and frame enums;
that source presence is not golden/native/runtime qualification. See
[actual target protocol state](protocol-target-state.json).

OpenAPI, generated operation names, route products, golden catalogs, matrix and
receipts remain unchanged. Existing OpenAPI/generated route presence in a Writer
tree is not actual endpoint/runtime availability; this offer is source only.
Frontend DTO/decoder/API consumers remain with their original Writer/layout owners.

## Holds and next handoff

Tests, test-list/discovery, build/type/lint, native/server/browser/product execution
and frozen-authority refresh are NOT RUN. Old receipts are not refreshed/promoted.
#1975 asset switching/native/migration/backup/security/receipt holds, #1976 waiting
gate and all registry/package, canonical business receiver, current receipt and
product/custody/race holds remain intact. All assigned issues stay OPEN.

Next: parent coordinates the original Shared and Writer owners using the exact
target patches and symbol map, supplies the canonical master protocol closure,
then separately authorizes any later source application or held validation.
No whole branch cherry-pick/merge, issue closure, deploy, package publication,
production DB action or cross-chain conflict resolution was performed.
''').encode())
gz('author-source-offer-builder.py.gz',pathlib.Path(__file__).read_bytes())
entries=[]
for p in sorted(out.rglob('*')):
    if p.is_file():
        b=p.read_bytes();entries.append({'path':str(p.relative_to(out)),'bytes':len(b),'sha256':sha(b)})
js('manifest.json',{'targetMaster':master,'precedingSourceCommit':observation_source,'productSourceUnchangedByOfferGeneration':True,'sourceOnlyOffer':True,'qualification':False,'entries':entries})
print(json.dumps({'directory':str(out.relative_to(repo)),'targetPostimages':len(all_bindings),'pathsPerTarget':15,'sourceApplyChecks':static_checks,'manifestEntries':len(entries),'productSourceUnchanged':True}))
