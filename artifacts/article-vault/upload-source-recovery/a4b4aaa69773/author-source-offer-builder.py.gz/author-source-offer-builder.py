import gzip,hashlib,json,pathlib,subprocess,tempfile

repo=pathlib.Path('/workspace/chain2258-upload-source-recovery')
scratch=pathlib.Path('/workspace/chain-1975-evidence/caller-producer-offer-20261011')
caller='a4b4aaa69773e0039ce1acdb525bb7aef3d8b330'
writer='7b203a3f4fd8346f05b7aeb176eb653bdb4b2fc9'
writer_current='5e324f1d582866242cc90cdb5a7e4d3f5631355a'
shared='55afe2a483f1d34b1f9c4257c8af77b6358672ff'
models_source='c08ace9061492fbfab1dea8d57928a998938dcc8'
root='artifacts/article-vault/upload-source-recovery/a4b4aaa69773'
out=repo/root
assert not out.exists()
def git(*a):return subprocess.check_output(['git',*a],cwd=repo)
def show(ref,p):
 r=subprocess.run(['git','show',ref+':'+p],cwd=repo,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
 return r.stdout if r.returncode==0 else None
def sha(b):return hashlib.sha256(b).hexdigest()
def put(p,b):
 d=out/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b)
def gz(p,b):put(p,gzip.compress(b,mtime=0))
def js(p,v):put(p,(json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode())
def once(t,a,b):assert t.count(a)==1,a;return t.replace(a,b)
assert git('rev-parse','HEAD').decode().strip()==models_source and not git('status','--porcelain').strip()
old_offer=repo/'artifacts/article-vault/upload-source-recovery/20261011'
backend_patch=gzip.decompress((old_offer/'targets/master/source.patch.gz').read_bytes())
old_bindings=json.loads((old_offer/'postimage-bindings.json').read_text())
paths=[r['path'] for r in old_bindings['rows'] if r['target']=='master']
assert len(paths)==15
post={}
with tempfile.TemporaryDirectory(prefix='caller-source-text-',dir=scratch) as directory:
 fixture=pathlib.Path(directory)
 def local(*a,**kw):
  r=subprocess.run(['git',*a],cwd=fixture,stdout=subprocess.PIPE,stderr=subprocess.PIPE,**kw)
  if r.returncode:raise RuntimeError((a,r.returncode,r.stderr.decode()))
  return r.stdout
 local('init','--quiet')
 for p in paths:
  b=show(caller,p)
  if b is not None:
   d=fixture/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b)
 local('add','--all')
 local('apply','--check','--index','-',input=backend_patch)
 local('apply','--index','-',input=backend_patch)
 for p in paths:post[p]=(fixture/p).read_bytes()
models='src/frontend/src/contracts/binaryApi.ts'
base=show(caller,models)
block=(scratch/'original-view-model-block.ts').read_bytes()
assert base+ b'\n'+block==show(models_source,models)
post[models]=base+b'\n'+block
registry='src/frontend/src/composition/binaryDecoderRegistry.ts'
text=show(caller,registry).decode()
for f in ['mapUploadAssetPreviewFromPayload','mapUploadAssetFactsFromPayload']:assert f not in text
text=once(text,'import { mapUploadCompleteFromPayload,','import { mapUploadAssetFactsFromPayload, mapUploadAssetPreviewFromPayload, mapUploadCompleteFromPayload,')
text=once(text,'    FrameType.UploadComplete,','    FrameType.UploadComplete,\n    FrameType.UploadAssetPreview,\n    FrameType.UploadAssetFacts,')
text=once(text,'    [FrameType.UploadComplete, mapUploadCompleteFromPayload],','    [FrameType.UploadComplete, mapUploadCompleteFromPayload],\n    [FrameType.UploadAssetPreview, mapUploadAssetPreviewFromPayload],\n    [FrameType.UploadAssetFacts, mapUploadAssetFactsFromPayload],')
post[registry]=text.encode()
protocol='src/shared/Contracts/Validation/aeds-protocol.json'
manifest=json.loads(show(caller,protocol));writer_manifest=json.loads(show(writer,protocol));shared_manifest=json.loads(show(shared,protocol))
norm=[r for r in writer_manifest['frameTypes'] if r['name'] in ['UploadAssetPreview','UploadAssetFacts']]
assert len(norm)==2 and len(manifest['frameTypes'])==244 and manifest==shared_manifest
assert norm==[r for r in json.loads(show(writer_current,protocol))['frameTypes'] if r['name'] in ['UploadAssetPreview','UploadAssetFacts']]
assert all(r['value'] not in {f['value'] for f in manifest['frameTypes']} for r in norm)
assert all(r['value'] not in {f['value'] for f in manifest['retiredFrameValues']} for r in norm)
proposal=json.loads(show(caller,protocol))
for i,r in enumerate(norm):proposal['frameTypes'].append(dict(r,goldenOrder=len(manifest['frameTypes'])+i))
assert proposal['frameTypes'][:244]==manifest['frameTypes']
assert {r['goldenOrder'] for r in proposal['frameTypes']}==set(range(246))
assert [r['value'] for r in proposal['frameTypes'][-2:]]==[275,285]
post[protocol]=(json.dumps(proposal,indent=4,ensure_ascii=False)+'\n').encode()
assert len(post)==18
def patch_for(items,label):
 with tempfile.TemporaryDirectory(prefix='caller-offer-check-',dir=scratch) as directory:
  fixture=pathlib.Path(directory)
  def local(*a,**kw):
   r=subprocess.run(['git',*a],cwd=fixture,stdout=subprocess.PIPE,stderr=subprocess.PIPE,**kw)
   if r.returncode:raise RuntimeError((a,r.returncode,r.stderr.decode()))
   return r.stdout
  local('init','--quiet');before={p:show(caller,p) for p in items}
  for p,b in before.items():
   if b is not None:
    d=fixture/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b)
  local('add','--all');tree=local('write-tree').decode().strip()
  for p,b in items.items():
   d=fixture/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b)
  local('add','--all');patch=local('diff','--cached','--binary',tree)
  local('read-tree',tree)
  for p,b in before.items():
   d=fixture/p
   if b is None:d.unlink()
   else:d.write_bytes(b)
  local('update-index','--refresh');local('apply','--check','--index','-',input=patch);local('apply','--index','-',input=patch)
  assert all((fixture/p).read_bytes()==b for p,b in items.items())
  local('apply','--reverse','--check','-',input=patch)
  return patch,{'label':label,'target':caller,'postimages':len(items),'patchSha256':sha(patch),'applyCheckExit':0,'applyExit':0,'exactPostimages':True,'reverseCheckExit':0,'fixtureRemoved':True,'productExecuted':False}
records=[]
for label,items in [('view-model-only',{models:post[models]}),('handwritten-closure',{p:b for p,b in post.items() if p!=protocol}),('conditional-canonical-input',post)]:
 patch,proof=patch_for(items,label);gz(label+'.patch.gz',patch);records.append(proof)
rows=[]
for p,b in sorted(post.items()):
 before=show(caller,p);gz('postimages/'+p+'.gz',b);rows.append({'path':p,'before':None if before is None else {'sha256':sha(before),'bytes':len(before),'blob':git('rev-parse',caller+':'+p).decode().strip()},'post':{'sha256':sha(b),'bytes':len(b)},'inactiveCanonicalInput':p==protocol})
js('source-apply-verification.json',{'kind':'Git text/source checks only','records':records,'productWorktreesChangedByOffers':False,'qualification':False})
js('postimage-bindings.json',{'target':caller,'modelSourceCommit':models_source,'rows':rows,'qualification':False})
binding=json.loads((scratch/'view-model-source-binding.json').read_text());binding['restoredCommit']=models_source;js('view-model-source-binding.json',binding)
gz('original-view-model-block.ts.gz',block)
caller_paths=['src/frontend/src/adapters/binary/uploadAdapter.ts','src/frontend/src/api/upload.ts','src/frontend/src/api/uploadFacts.ts',registry,models,protocol,'src/frontend/wasm/web/protocol/frame.ts','src/frontend/src/generated/fsusBinaryRoutes.ts']
facts=[]
for p in caller_paths:
 b=show(caller,p);facts.append({'path':p,'blob':git('rev-parse',caller+':'+p).decode().strip(),'sha256':sha(b),'bytes':len(b),'readOnly':True})
diagnostics=[('src/frontend/src/adapters/binary/uploadAdapter.ts',4,'UploadAssetPreviewViewModel','original VM'),('src/frontend/src/adapters/binary/uploadAdapter.ts',5,'UploadAssetFactsViewModel','original VM'),('src/frontend/src/api/upload.ts',7,'UploadAssetPreviewViewModel','original VM'),('src/frontend/src/api/upload.ts',22,'UploadAssetPreviewViewModel','original VM'),('src/frontend/src/api/upload.ts',186,'binary_post_upload_uploadId_preview','generated route producer'),('src/frontend/src/api/upload.ts',187,'UploadAssetPreview','canonical frame producer'),('src/frontend/src/api/uploadFacts.ts',2,'UploadAssetFactsViewModel','original VM'),('src/frontend/src/api/uploadFacts.ts',20,'binary_post_upload_uploadId_facts','generated route producer'),('src/frontend/src/api/uploadFacts.ts',21,'UploadAssetFacts','canonical frame producer')]
js('exact-caller-audit.json',{'caller':caller,'uiIdentity':'cb115a prefix supplied by parent; not expanded or requalified here','sourceFacts':facts,'nineDiagnosticsFromParentNotRerun':[{'path':p,'line':line,'missingSymbol':symbol,'producer':owner,'state':'real original declaration restored in sourcec08 and one-file offer' if owner=='original VM' else 'BLOCKED canonical producer output, no shim'} for p,line,symbol,owner in diagnostics],'additionalJoin':'binaryDecoderRegistry lacks two existing mapper imports, supported-frame entries and actual decoder registrations; minimal original registration hunk offered, unapplied','sourceScope':'consumer files only read; no caller/UI branch incorporation','testsTypesLint':'NOT RUN','qualification':False})
old_refs=[p for p in paths if p not in ['src/backend/Interfaces/IFileService.cs','src/backend/Interfaces/UploadAssetObservation.cs']]
js('backend-offer-retarget.json',{'previousOfferCommit':'7e68bb47f1d11723b57b045649ca5fc510ed3ea5','oldTarget':'9d72a1c93b297f719d8695a642cdfb1615cf1d51','actualTarget':caller,'actualCheckAndApplyExit':0,'files':15,'originalObservation':'982430c1c696e51715e1fb9587acbc2f61ec8902','previewOrigin':'66fa8b0e6c6bc8b7555275ca9fb8feb220d3fd1f','factsOrigin':'4cfdbbf9542f14eab305642aabb968fb6b3179bd','endpointSourceNotActivated':True,'qualification':False})
route_contract=json.loads(show('4cfdbbf9542f14eab305642aabb968fb6b3179bd','src/shared/Contracts/Validation/aeds-endpoint-contracts.json'))
ops=[r for r in route_contract['operations'] if r.get('operationId') in ['binary_post_upload_uploadId_preview','binary_post_upload_uploadId_facts']];assert len(ops)==2
js('original-route-source-records.json',{'historicalProducer':'4cfdbbf9542f14eab305642aabb968fb6b3179bd','records':ops,'notCurrentObservation':True,'notAppliedToFrozenContracts':True,'qualification':False})
generated=['src/core/Algorithms/AedsFrameType.cs','src/shared/AedsFrameHeader.cs','src/frontend/wasm/aeds/include/aeds_frame.hpp','src/frontend/wasm/web/protocol/frame.ts']
writer_sources=[{'path':p,'blob':git('rev-parse',writer+':'+p).decode().strip(),'previewPresent':b'UploadAssetPreview' in show(writer,p),'factsPresent':b'UploadAssetFacts' in show(writer,p)} for p in generated]
js('canonical-source-owner-requests.json',{
 'shared':{'owner':'canonical Shared source owner, coordination PR4155','currentReadHead':shared,'branch':'codex/shared-package-prototype-reconciliation-20261009','manifestExactSameAsCaller':True,'rosterCount':244,'originalNormSource':writer,'writerCurrentSource':writer_current,'writerEntries':norm,'minimumRequest':'review/join only original UploadAssetPreview275 and UploadAssetFacts285 source entries into this exact current roster, retain all244 existing rows, then provide owner-generated four source projections with exact commit/postimages; requires separate generator authorization, not granted by this task','inactiveInputProposal':proposal['frameTypes'][-2:],'noOld266267OrWriter261262Transplant':True,'sourceProducer':'tools/frontend/generate-aeds-protocol.mjs','requiredSourceOutputs':generated,'frozenGoldenCatalog':'remain held; full CLI also writes tests/backend/Fixtures/aeds-golden-catalog.json, so do not silently run it','writerGeneratedSourceEvidence':writer_sources},
 'routes':{'owner':'original upload endpoint producer2258 plus canonical OpenAPI/Shared route producer','headOffer':models_source,'actualEndpointOffer':'handwritten-closure.patch.gz: real original preview/facts route/handler/service/encoder; no fake generated route availability','minimumRequest':'after owner-confirmed source join, obtain separately authorized real compiled endpoint observation and its generated frontend routes bound to exact joined source; preserve unrelated current operations; provide exact producer/source identity and postimages for the two operations','producerChain':['tools/contracts/export-openapi.sh','tools/contracts/check-openapi-sync.mjs','tools/contracts/FsusBlog.OpenApiObservation','tools/contracts/generate-frontend-routes.mjs'],'blockedOutputs':['src/shared/Contracts/Validation/fsusblog.openapi.json','src/shared/Contracts/Validation/aeds-endpoint-contracts.json','src/frontend/src/generated/fsusBinaryRoutes.ts'],'frozenAuthorityRefreshAndGeneratorRun':'NOT authorized/run here; original two records are historical source references only'},
 'result':'five named type references have real original declarations; four generated-symbol references and full producer coherence remain BLOCKED, not generic test failures or a claimed cleared typecheck','qualification':False})
js('held-gates.json',{'generators':'NOT RUN','frozenAuthorityRefresh':'NOT RUN','testsDiscoveryTypesLint':'NOT RUN','nativeSecurityReceiptBackendTests':'HELD/NOT RUN','original1975AssetMigrationBackup':'HELD','callerAndUi':'read-only/no execution/no incorporation','offers':'UNAPPLIED, including inactive source protocol proposal','allIssueAndProductAcceptance':'OPEN','qualification':False})
put('README.md',('''# Exact a4b4aaa upload producer source offer — UNAPPLIED

Target caller: a4b4aaa69773e0039ce1acdb525bb7aef3d8b330; parent UI identitycb115a
is a supplied prefix, not a newly qualified full UI identity. The actual upload
adapter and preview/facts consumers already exist and were read only. There are
five missing named-export references and four missing generated route/frame
references, plus absent decoder registration. These are concrete missing
canonical producer sources, not generic testing errors.

Ready source commit c08ace9061492fbfab1dea8d57928a998938dcc8 restores the original
UploadAssetPreviewViewModel/UploadAssetFactsViewModel declarations and documents
their data-only boundary. The interface file before this commit is byte-identical
to actual caller a4. The27? declaration block is exact original313c3403, preview
origin66fa; no ambient declaration, any-cast, fake operation or TS shim exists.
See view-model-source-binding.json for exact bytes/hashes. A one-file
view-model-only.patch.gz applies to a4 and addresses the five original named
references in source. No typecheck was rerun or diagnostic count promoted.

handwritten-closure.patch.gz contains17 postimages: the15 original backend/shared
DTO/POD/codec/native-parser source leaves from4226, retargeted and actually applied
to exact a4 in a disposable text fixture, plus original frontend types and the
three real decoder-registry joins (import, supported frames, registration).
Existing adapter and API implementations are retained; source references bind
their exact original blobs. All other target text remains unchanged.

conditional-canonical-input.patch.gz adds one **inactive source-input proposal**
to those17 leaves. It preserves all244 existing manifest rows and adopts Writer7b/
5e's actual275/285 name/value/family specification. Proposed appended golden orders
are244/245 for this244-row target, not historic266/267 or Writer263-row261/262.
The Shared owner must confirm the current roster and source allocation before
adoption. It is not an active manifest and no generated source was fabricated.
All three exact patches passed Git apply-check/application, postimage equality
and reverse-check. They remain UNAPPLIED to caller/product worktrees.

Canonical Shared owner current read PR4155/head55afe2a483f1d34b1f9c4257c8af77b6358672ff
has the exact same244-frame manifest as caller. Required next source output is its
owner-approved original275/285 join and the four existing C#/TS/C++ projections
from tools/frontend/generate-aeds-protocol.mjs, bound to the joined exact source.
This task is not authorized to run that generator, whose full CLI also writes
the held golden fixture. Writer7b/5e already have both generated source symbols;
their whole263-frame outputs must not overwrite this244-frame consumer.

Both operation names require the real endpoint/codec join and the canonical
compiled observation -> OpenAPI/endpoint projection -> frontend-route producer.
The original two route source records are supplied as historical references only,
not as current compiled observations. No snapshot/digest or generated operation
was manually written. Four generated-symbol references remain blocked pending
separate producer authorization and an exact owner commit/postimage handoff.
canonical-source-owner-requests.json gives the precise owner/head/files/request.

No generator, frozen-authority refresh, type/lint check, test/list/discovery,
native/security/receipt/backend/product execution ran.1975 asset/native/migration/
backup and every other hold remain. Source recovery and text apply checks do not
qualify endpoints, producer coherence, a typecheck or any issue/whole chain.
''').replace('The27? declaration block','The declaration block').encode())
gz('author-source-offer-builder.py.gz',pathlib.Path(__file__).read_bytes())
entries=[]
for p in sorted(out.rglob('*')):
 if p.is_file():
  b=p.read_bytes();entries.append({'path':str(p.relative_to(out)),'bytes':len(b),'sha256':sha(b)})
js('manifest.json',{'targetCaller':caller,'sourceCommit':models_source,'qualification':False,'entries':entries})
print(json.dumps({'postimagePaths':len(post),'records':records,'manifestEntries':len(entries),'generatorRun':False,'remainingGeneratedReferences':4}))
