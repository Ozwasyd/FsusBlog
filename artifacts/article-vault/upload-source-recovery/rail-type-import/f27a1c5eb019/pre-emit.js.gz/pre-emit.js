export const ArticlePublishStatus = {
    Draft: 0,
    Scheduled: 1,
    Published: 2,
    Archived: 3,
    Deleted: 4
};
export const SecurityChallengeKind = {
    Unknown: 0,
    Sha256PowV1: 1,
    Argon2IdPoSpaceV1: 2,
    HumanReadProofV1: 4,
    PasskeyStepUpV1: 5,
    AdminPasskeyStepUpV1: 6,
    RecoveryKeyProofV1: 7,
    AnonymousCredentialProofV1: 8,
    ZkAnonymousCommentProofV1: 9,
    PerceptionLocalizationV2: 11,
    PerceptionMicroInteractionV2: 12,
    PerceptionCharacterV3: 14
};
export const PerceptionCharacterV3Representation = {
    Visual: 1,
    Audio: 2
};
