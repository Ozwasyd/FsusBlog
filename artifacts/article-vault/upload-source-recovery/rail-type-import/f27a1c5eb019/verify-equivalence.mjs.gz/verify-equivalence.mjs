import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import ts from '/workspace/chain1975-intent-source-alias-verification/src/frontend/node_modules/typescript/lib/typescript.js';

const root='/workspace/chain2258-upload-source-recovery';
const out='/workspace/chain-1975-evidence/rail-type-import-20261011';
const file='src/frontend/src/contracts/binaryApi.ts';
const before=fs.readFileSync(path.join(out,'pre-binaryApi.ts'),'utf8');
const after=fs.readFileSync(path.join(root,file),'utf8');
const specifier='@/locales/localeCatalog';
const expression="import('@/locales/localeCatalog').SupportedLocale";
const importLine="import type { SupportedLocale } from '@/locales/localeCatalog';\n\n";
const hash=value=>crypto.createHash('sha256').update(value).digest('hex');
if(before.split(expression).length-1!==2 || after!==importLine+before.replaceAll(expression,'SupportedLocale'))
    throw new Error('delta exceeds one original import binding and exactly two type references');
const options={target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext,removeComments:true,sourceMap:false,verbatimModuleSyntax:true};
const emissions=[before,after].map(source=>ts.transpileModule(source,{compilerOptions:options,fileName:file,reportDiagnostics:true}));
if(emissions.some(value=>value.diagnostics.length!==0)||emissions[0].outputText!==emissions[1].outputText)
    throw new Error('official TypeScript runtime emit changed or produced a diagnostic');
fs.writeFileSync(path.join(out,'pre-emit.js'),emissions[0].outputText);
fs.writeFileSync(path.join(out,'post-emit.js'),emissions[1].outputText);
const trees=[before,after].map(source=>ts.createSourceFile(file,source,ts.ScriptTarget.Latest,true,ts.ScriptKind.TS));
const imports=trees[1].statements.filter(node=>ts.isImportDeclaration(node)&&node.moduleSpecifier.text===specifier);
if(imports.length!==1)throw new Error('new binding is not unique');
const clause=imports[0].importClause;
if(!clause.isTypeOnly||clause.name||!ts.isNamedImports(clause.namedBindings)
    ||clause.namedBindings.elements.length!==1||clause.namedBindings.elements[0].propertyName
    ||clause.namedBindings.elements[0].name.text!=='SupportedLocale')
    throw new Error('new binding differs from original actual exported type');
const resolved=ts.resolveModuleName(specifier,path.join(root,file),{
    moduleResolution:ts.ModuleResolutionKind.Bundler,
    baseUrl:path.join(root,'src/frontend'),paths:{'@/*':['src/*']}
},ts.sys).resolvedModule;
const localePath=path.join(root,'src/frontend/src/locales/localeCatalog.ts');
if(!resolved||path.resolve(resolved.resolvedFileName)!==localePath)throw new Error('original locale type does not resolve to actual source');
const localeBytes=fs.readFileSync(localePath);
const localeTree=ts.createSourceFile(localePath,localeBytes.toString(),ts.ScriptTarget.Latest,true);
const actualExport=localeTree.statements.find(node=>ts.isTypeAliasDeclaration(node)&&node.name.text==='SupportedLocale'
    &&node.modifiers?.some(modifier=>modifier.kind===ts.SyntaxKind.ExportKeyword));
if(!actualExport)throw new Error('actual SupportedLocale export missing');
let replaced=0,removed=0;
const normalized=trees.map((tree,index)=>{
    const result=ts.transform(tree,[context=>source=>{
        const visitor=node=>{
            if(index===0&&ts.isImportTypeNode(node))
            {
                if(!ts.isLiteralTypeNode(node.argument)||!ts.isStringLiteral(node.argument.literal)
                    ||node.argument.literal.text!==specifier||!ts.isIdentifier(node.qualifier)
                    ||node.qualifier.text!=='SupportedLocale'||node.isTypeOf||node.typeArguments)
                    throw new Error('unexpected original import type');
                replaced++;
                return ts.factory.createTypeReferenceNode('SupportedLocale',undefined);
            }
            if(index===1&&node===imports[0]){removed++;return undefined;}
            return ts.visitEachChild(node,visitor,context);
        };
        return ts.visitNode(source,visitor);
    }]);
    const output=ts.createPrinter({newLine:ts.NewLineKind.LineFeed,removeComments:false}).printFile(result.transformed[0]);
    const normalizedTree=ts.createSourceFile(file,output,ts.ScriptTarget.Latest,true);
    function semantic(node)
    {
        const children=[];ts.forEachChild(node,child=>{children.push(semantic(child));});
        return {kind:node.kind,
            ...(typeof node.text==='string'&&node.kind!==ts.SyntaxKind.SourceFile?{text:node.text}:{}),
            ...(typeof node.isTypeOnly==='boolean'?{isTypeOnly:node.isTypeOnly}:{}),
            ...(typeof node.isTypeOf==='boolean'?{isTypeOf:node.isTypeOf}:{}),
            flags:node.flags&~ts.NodeFlags.Synthesized,children};
    }
    const ast=JSON.stringify(semantic(normalizedTree));result.dispose();return {output,ast};
});
if(replaced!==2||removed!==1||normalized[0].output!==normalized[1].output||normalized[0].ast!==normalized[1].ast)
    throw new Error('AST differs beyond exact same type-binding normalization');
const beforeDeclarations=new Map(trees[0].statements.filter(node=>ts.isInterfaceDeclaration(node)||ts.isTypeAliasDeclaration(node)).map(node=>[node.name.text,node.getText(trees[0])]));
const dtoUnchanged=['UploadAssetPreviewViewModel','UploadAssetFactsViewModel'].every(name=>{
    const node=trees[1].statements.find(node=>node.name?.text===name);return node&&node.getText(trees[1])===beforeDeclarations.get(name);
});
if(!dtoUnchanged)throw new Error('real upload DTO declarations changed');
const record={typescript:ts.version,preSha256:hash(before),postSha256:hash(after),runtimeEmitIdentical:true,
    runtimeEmitSha256:hash(emissions[0].outputText),transpileDiagnostics:[0,0],
    exactTextDelta:true,originalTypeSites:2,newTypeOnlyBinding:1,
    normalizedAstIdentical:true,normalizedAstSha256:hash(normalized[0].ast),
    normalizedPrintedAstSha256:hash(normalized[0].output),normalization:'only exact original SupportedLocale import-type references -> same actual named type binding; remove that one new type-only import; all other AST nodes/comments preserved',
    actualLocaleModule:localePath,actualLocaleSourceSha256:hash(localeBytes),actualExport:actualExport.getText(localeTree),
    originalPreviewAndFactsDeclarationsByteIdentical:dtoUnchanged,
    fullTypecheck:false,runtimeOrProtocolExecution:false,qualification:false};
fs.writeFileSync(path.join(out,'equivalence.json'),JSON.stringify(record,null,2)+'\n');
console.log(JSON.stringify(record));
