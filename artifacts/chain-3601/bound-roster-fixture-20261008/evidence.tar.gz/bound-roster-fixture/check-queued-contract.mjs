import fs from 'node:fs';
import { pathToFileURL } from 'node:url';
const root = process.cwd();
const { changedFilesBetween, validatePrContract, validateRepositoryBlameIgnore, validateRepositorySources } = await import(pathToFileURL(`${root}/tools/governance/change-contract.mjs`));
const draft = JSON.parse(fs.readFileSync('/workspace/chain-3601-evidence/bound-roster-fixture/bound-roster-fixture-pr-request.json'));
const base = 'aaba7b8c84ecfb336c71443e30d9fd82d21fb16d';
const head = '562551892c9a0af87f1a9d2d77f8a2ddf4823362';
const errors = [
    ...validatePrContract({ title: draft.title, body: draft.body, labels: ['release-note:internal'], changedFiles: changedFilesBetween(root, base, head), root, base, head, authorityRoot: root }),
    ...validateRepositoryBlameIgnore(root),
    ...validateRepositorySources(root)
];
console.log(JSON.stringify({ preparedLocalDraft: true, actualGithubEvent: false, base, head, errors }, null, 2));
if (errors.length) process.exit(1);
