from pathlib import Path
import json
import re
import subprocess
import sys

out = Path('/tmp/fsusblog-chain-3601-bound-roster-fixture/publication-candidate')
root = Path('/workspace/chain-3601-bound-roster-fixture')
plan = json.loads((out / 'positive-test-allowlist.json').read_text())
group = sys.argv[1]
selected = plan['groups'][group]
titles = [t for names in selected.values() for t in names]
assert len(titles) == plan['expectedByGroup'][group]
escape = lambda s: re.sub(r'([.*+?^${}()|\[\]\\])', r'\\\1', s)
pattern = '^(?:' + '|'.join(map(escape, titles)) + ')$'
command = ['node', '--test', '--test-reporter=tap', '--test-name-pattern=' + pattern, *selected.keys()]
(out / (group + '.command.json')).write_text(json.dumps({'exactPositiveAllowlist': titles, 'expected': len(titles), 'command': command}, indent=2) + '\n')
subprocess.run(['python3', str(out / 'run-check.py'), 'tests-' + group, *command], cwd=root, check=True)
log = (out / ('tests-' + group + '.log')).read_text()
counts = {key: int(re.findall(r'^# ' + key + r' (\d+)\s*$', log, re.M)[-1]) for key in ['tests', 'pass', 'fail', 'skipped', 'cancelled']}
executed = re.findall(r'^(?:ok|not ok) \d+ - (.*?)\s*$', log, re.M)
executed = [re.sub(r' # SKIP.*$', '', t) for t in executed]
unexpected = [t for t in executed if t not in titles]
missing = [t for t in titles if t not in executed]
result = {'group': group, 'sha': json.loads((out / ('tests-' + group + '.run.json')).read_text())['sha'],
          'expected': len(titles), 'counts': counts, 'unexpected': unexpected, 'missing': missing,
          'exactAllowlistSatisfied': not unexpected and not missing and counts['tests'] == len(titles)}
(out / (group + '.selected-results.json')).write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
if not result['exactAllowlistSatisfied']:
    sys.exit(2)
