import fs from 'node:fs';
import { pathToFileURL } from 'node:url';
const root=process.cwd();
const { changedFilesBetween,validatePrContract,validateRepositoryBlameIgnore,validateRepositorySources } = await import(pathToFileURL(`${root}/tools/governance/change-contract.mjs`));
const draft=JSON.parse(fs.readFileSync('/tmp/chain-3601-master-integration-20261009/final-pr-request.json'));
const base=draft.actualBaseSha,head=draft.candidateSha;
const errors=[...validatePrContract({title:draft.title,body:draft.body,labels:['release-note:internal'],changedFiles:changedFilesBetween(root,base,head),root,base,head,authorityRoot:root}),...validateRepositoryBlameIgnore(root),...validateRepositorySources(root)];
console.log(JSON.stringify({preparedLocalDraft:true,actualGithubEvent:false,base,head,errors},null,2));
if(errors.length)process.exit(1);
