import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { pathToFileURL } from 'node:url';
const root = process.cwd();
const frozen = '562551892c9a0af87f1a9d2d77f8a2ddf4823362';
const out = '/tmp/chain-3601-master-integration-20261009';
const git = (...args) => execFileSync('git', args, { cwd: root, maxBuffer: 16 * 1024 * 1024 });
const bytes = (p, old) => old ? git('show', frozen + ':' + p) : fs.readFileSync(path.join(root, p));
const digest = (b) => createHash('sha256').update(b).digest('hex');
const parserPath = 'tests/tools/support/esm-fixture-materializer.mjs';
assert.deepEqual(bytes(parserPath, true), bytes(parserPath, false));
const { parseStaticRelativeEsmSpecifiers } = await import(pathToFileURL(path.join(root, parserPath)));
function closure(entries, old) {
    const rows = new Map();
    const pending = [...entries];
    while (pending.length) {
        const p = pending.pop();
        if (rows.has(p)) continue;
        assert.ok(!p.startsWith('../') && !path.isAbsolute(p));
        const b = bytes(p, old);
        rows.set(p, digest(b));
        if (/\.(mjs|js|cjs)$/u.test(p)) {
            for (const specifier of parseStaticRelativeEsmSpecifiers(b, p)) {
                pending.push(path.posix.normalize(path.posix.join(path.posix.dirname(p), specifier)));
            }
        }
    }
    return [...rows].sort(([a], [b]) => a.localeCompare(b));
}
const rosterEntries = ['tests/tools/correctness-attempt-migration.test.mjs',
    'tests/tools/correctness-attempt-test-producers.test.mjs',
    'tests/tools/correctness-attempt-build-release.test.mjs'];
const roster = closure(rosterEntries, false);
assert.deepEqual(roster, closure(rosterEntries, true));
const catalog = JSON.parse(bytes('config/testing/correctness-attempt-producers.json', false));
const dataFiles = ['config/testing/correctness-attempt-producers.json', ...Object.keys(catalog.sourceDigests),
    'config/testing/release-final-execution-authority-index.json'];
const data = dataFiles.map((p) => {
    const current = bytes(p, false); const old = bytes(p, true);
    assert.deepEqual(current, old, p);
    return { path: p, sha256: digest(current), wholeFileEqual: true };
});
assert.equal(catalog.entries.length, 226);
for (const p of new Set(catalog.entries.map((row) => row.executionOwner))) {
    assert.ok(fs.existsSync(path.join(root,p)));
    git('cat-file','-e',frozen+':'+p);
}
const finalizer = ['tests/tools/scheduler-finalizer-boundary.test.mjs', 'tools/test-matrix/scheduler.mjs']
    .map((p) => { const b=bytes(p,false);assert.deepEqual(b,bytes(p,true),p);return {path:p,sha256:digest(b),wholeFileEqual:true}; });
const index=JSON.parse(bytes('config/testing/release-final-execution-authority-index.json', false));
const oldAuthority=JSON.parse(bytes('tests/fixtures/test-matrix/release-final-execution-target-authority.json', true));
assert.deepEqual(index.nodeParserIdentity, oldAuthority.nodeParserIdentity);
assert.equal(process.version,index.nodeParserIdentity.nodeVersion);
const changedRunner = git('diff','--name-only',frozen,'--','tools/run-test-matrix.mjs','tools/test-matrix','tests/fixtures/test-matrix').toString().split('\n').filter(Boolean);
const hooks = JSON.parse(fs.readFileSync(path.join(out,'positive-test-allowlist.json')));
const record = { frozenSource: frozen, currentHeadAtProbe:git('rev-parse','HEAD').toString().trim(),
    sourceDirtyAtProbe:!!git('status','--porcelain').toString().trim(), qualification:false,
    parserOwner:parserPath, nodeVersion:process.version, nodeExecutable:process.execPath,
    nodeExecutableSha256ObservedNow:digest(fs.readFileSync(process.execPath)),
    pinnedParserIdentityUnchanged:index.nodeParserIdentity,
    historicalNodeBinarySha256Claimed:false,
    roster:{callbacks:7,exactModuleClosure:roster,exactData:data,all226RowsByteEqual:true,
        executionOwnerExistenceChecksUnchanged:true, externalNodePackages:[]},
    finalizer:{callbacks:8,exactReadInputs:finalizer, vmPorts:'unchanged deterministic source-defined dependency ports; no physical scheduler execution'},
    changedRunnerInputs:changedRunner,
    rerunGroups:['materializer','assets','caller','cli'],rerunExpected:36,
    reuseGroups:['roster','finalizer'],reuseExpected:15,
    oldEvidenceRunId:'chain3601-publication-20261008T152350Z-d219565f47',
    oldEvidenceIdentityPreserved:true,
    selectedFrameworkHooks:'node:test definitions; t.after task-owned temporary cleanup; no file-level before/beforeEach hook added; unlisted callbacks excluded',
    freshCiResumeHeld:true, heldReceiptGitCohortNativeAuditRun:false };
fs.writeFileSync(path.join(out,'input-proof.json'),JSON.stringify(record,null,2)+'\n');
const selected = {...hooks,groups:{}};
for (const group of record.rerunGroups) selected.groups[group]=hooks.groups[group];
selected.expectedByGroup=Object.fromEntries(record.rerunGroups.map(g=>[g,hooks.expectedByGroup[g]]));
selected.expectedSelectedTotal=36;
selected.stage='current-master changed runner fixture inputs only; 15 unchanged ordinary controls retained at their original tested identity with exact source/data proof';
selected.reusedEvidence={callbacks:15,sha:frozen,runId:record.oldEvidenceRunId,proof:'input-proof.json',notNewCandidateRuns:true};
assert.equal(Object.values(selected.expectedByGroup).reduce((a,b)=>a+b,0),36);
fs.writeFileSync(path.join(out,'positive-test-allowlist.json'),JSON.stringify(selected,null,2)+'\n');
console.log(JSON.stringify({rosterModuleFiles:roster.length,rosterDataFiles:data.length,finalizerInputFiles:finalizer.length,rerunExpected:36,reusedOldIdentity:15,runnerChanges:changedRunner}));
