import pathlib,json,hashlib,subprocess,datetime,copy
ROOT=pathlib.Path('/workspace/chain-3601-master-integration'); P=pathlib.Path('/tmp/chain-3601-master-integration-20261009'); L=P/'latest-537'
O=pathlib.Path('/workspace/chain-3601-evidence/master-integration-final-20261009'); O.mkdir(exist_ok=True)
HEAD='73ffeaed8bf7833a67259aa89e278ec1cd7a2048'; BASE='537bb3fa2f9ef54e0a2e93a925a4ce6fa335ceea'; FROZEN='562551892c9a0af87f1a9d2d77f8a2ddf4823362'; FIRST='b5035927b6e9a06dc6f269c73c2d7e29bade68c5'; PREV='4ba4f9d28fb1511d6869a3a51a7ec72b6ef43bb5'
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT)
def b(ref,p):return git('show',ref+':'+p)
def sha(v):return hashlib.sha256(v).hexdigest()
def save(p,j):p.write_text(json.dumps(j,indent=2)+'\n')
assert git('rev-parse','HEAD').decode().strip()==HEAD
assert not git('status','--porcelain').strip()
assert git('merge-base',HEAD,BASE).decode().strip()==BASE
prev=json.loads((P/'final-integration-identity.json').read_text())
paths=git('diff','--name-only',BASE+'..'+HEAD).decode().splitlines();assert paths==[x['path'] for x in prev['paths']]
records=[]
for p in paths:
 v=b(HEAD,p);assert v==(ROOT/p).read_bytes();assert v==b(PREV,p)
 records.append({'path':p,'headBlob':git('rev-parse',HEAD+':'+p).decode().strip(),'headSha256':sha(v),'wholeFileEqualFrozen562':v==b(FROZEN,p),'wholeFileEqualPreviousIntegration4ba':True})
assert sum(x['wholeFileEqualFrozen562'] for x in records)==8
producer='tools/test-matrix/generate-release-final-execution-authority.mjs';assert b(HEAD,producer)==b(FROZEN,producer)
out='tests/fixtures/test-matrix/release-final-execution-target-authority.json';digest=sha((ROOT/out).read_bytes());assert digest=='080805d5871b845e8b62ad416dceaabcf2ce4ea8c2e0712f2f69f3d1c88181a5'
for p in ['artifacts/change-contract/chain-3601-runtime-asset-generated-binding.json','artifacts/change-contract/correctness-current-migration-execution-binding.json']:
 assert json.loads((ROOT/p).read_text())['outputs']==[{'path':out,'sha256':digest}]
authority=json.loads((ROOT/out).read_text());assert len(authority['closureFiles'])==1129 and len(authority['targets'])==102
catalogpath='config/testing/correctness-attempt-producers.json';catalog=json.loads(b(HEAD,catalogpath));assert b(HEAD,catalogpath)==b(FROZEN,catalogpath);assert len(catalog['entries'])==226 and len(catalog['sourceDigests'])==8
for p,d in catalog['sourceDigests'].items():assert 'sha256:'+sha(b(HEAD,p))==d
before='tests/test-retention-before.json';assert b(HEAD,before)==b(FROZEN,before);assert git('rev-parse',HEAD+':'+before).decode().strip()=='65890e4bcfb2e524f4c8eebe90247055c0eb268f'
ledger='tests/test-retention-replacements.json';assert b(HEAD,ledger)==b(BASE,ledger)
oldledger=json.loads(b(FROZEN,ledger));newledger=json.loads(b(HEAD,ledger))
for row in prev['qpsRows']:
 old=next(x for x in oldledger['deletedTests'] if x['id']==row['id']);new=next(x for x in newledger['deletedTests'] if x['id']==row['id']);assert old==new
proof=json.loads((L/'latest-input-proof.json').read_text());assert proof['sourceHead']==HEAD
assert len(proof['exactInputFiles'])==1132 and all(x['wholeFileEqual'] for x in proof['exactInputFiles'])
# Actual source clean/current command receipts, without changing any earlier run identity.
checks={}
for f in L.glob('*.run.json'):
 j=json.loads(f.read_text());assert j['sha']==HEAD and j['exit']==0 and j['sourceDirtyAtStart'] is False;checks[j['name']]={'exit':j['exit'],'runId':j['runId'],'record':'latest-537/'+f.name,'log':'latest-537/'+j['log']}
assert set(checks)=={'producer','static-boundary','pr-contract','commit-contract','layout','catalog','declarations','docs','authoritative-docs','preservation','source-style','markdownlint'}
identity={**prev,'head':HEAD,'base':BASE,'actualMergeBase':BASE,'parents':git('show','-s','--format=%P',HEAD).decode().split(),'paths':records,'diffStat':git('diff','--stat',BASE+'..'+HEAD).decode().splitlines()[-1].strip(),'latest13UpstreamPaths':git('diff','--name-only','5dcd62096f97ccb2297781f2fcebf04fa8dbedd6..'+BASE).decode().splitlines(),'sourceWorktreeClean':True,'actualChecks':checks,'fixedPoint':{'sha256':digest,'committedEqualsWorktree':True,'originalProducerBytesEqualFrozen':True,'bothOwnBindingsMatch':True,'closureFiles':1129,'targets':102,'qualification':False}}
assert len(identity['latest13UpstreamPaths'])==13 and not set(paths).intersection(identity['latest13UpstreamPaths'])
save(L/'final-source-identity.json',identity)
remote=subprocess.check_output(['git','ls-remote','origin','refs/heads/master','refs/heads/codex/chain-3601-master-integration-20261009','refs/heads/codex/chain-3601-bound-roster-fixture','refs/heads/codex/chain-3601-source-review','refs/heads/codex/chain-3601-source-review-doc'],cwd=ROOT).decode()
refs=dict((line.split()[1],line.split()[0]) for line in remote.splitlines());assert refs['refs/heads/master']==BASE and refs['refs/heads/codex/chain-3601-master-integration-20261009']==HEAD and refs['refs/heads/codex/chain-3601-bound-roster-fixture']==FROZEN
assert refs['refs/heads/codex/chain-3601-source-review']=='f50ad57f8e4e70c035e01661615daf61fbe333ec' and refs['refs/heads/codex/chain-3601-source-review-doc']=='1d276775e43f0d3f3f1cea79b524e3ddba63286d'
save(L/'source-publication-readback.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'refs':refs,'sourcePublished':True,'frozenHeadsPreserved':True})
h=json.loads(pathlib.Path('/workspace/chain-3601-evidence/master-integration-20261009/handoff-master-integration.json').read_text())
h.update({'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceHead':HEAD,'actualMasterBase':BASE,'mergeBase':BASE,'finalParents':identity['parents'],'paths':records,'evidenceBranch':'codex/chain-3601-master-integration-final-evidence-20261009','previousPublishedIntegration':{'head':PREV,'base':'5dcd62096f97ccb2297781f2fcebf04fa8dbedd6','evidenceCommit':'0b0dea25957510d2bb0d62a92de31c78bff92526','archiveSha256':'4463462986ab8e41434b7e2fbc2d16ed158edc975508239214ea2411e2969e2b'},'sourcePublicationReadback':'latest-537/source-publication-readback.json'})
h['sourceIntegrationSemantics']['latestThirteenFrontendBootstrapPaths']='current master baseline only; zero owned11 or actual1132 runner input overlap; no acceptance asserted for those upstream changes'
h['verification']['newFinalTestCallbacks'].update({'sha':HEAD,'allowlist':'latest-537/positive-test-allowlist.json','reason':'actual13frontendbaseline advance outside all1132 runner inputs; retain historical test identities; no repeated callbacks'})
h['verification']['retained36AtFirstIntegrationIdentity']['finalReuseProof']='latest-537/latest-input-proof.json'
h['verification']['actualFinalChecks']={'sha':HEAD,'runId':(L/'run-id.txt').read_text().strip(),'commands':checks,'staticBoundaryErrors':[],'declarationsTiers':146,'qualification':False,'sourceDirtyDuringChecks':False}
h['realRemainingGates'][0]['need']='complete final11-path review of head73ffeaed8bf7833a67259aa89e278ec1cd7a2048 against actualmaster537bb3fa2f9ef54e0a2e93a925a4ce6fa335ceea; original562 review remains distinct'
save(O/'handoff-master-integration.json',h)
r=json.loads(pathlib.Path('/workspace/chain-3601-evidence/master-integration-20261009/same-reviewer-final-combination-request.json').read_text());r.update({'head':HEAD,'base':BASE,'evidenceBranch':h['evidenceBranch'],'evidencePath':'artifacts/chain-3601/master-integration-final-20261009','inputProofs':['input-proof.json','latest-537/latest-input-proof.json','retained-evidence-identity.json'],'finalActualCheckRunId':h['verification']['actualFinalChecks']['runId']});save(O/'same-reviewer-final-combination-request.json',r)
(O/'final-pr-request.json').write_bytes((L/'final-pr-request.json').read_bytes())
(O/'README.md').write_text(f'''# Chain3601 final source integration

Source `{HEAD}` on `codex/chain-3601-master-integration-20261009` has actual master `{BASE}` as its second parent and ancestor. The previous source `{PREV}` is its first parent. The initial real merge `b5035927` contains frozen `56255189` and requested master `720d9948`. Frozen 562/f50/1d remote heads remain unchanged. The final source and live master were read back exactly; see the timestamped record.

The aggregate diff against master is exactly 11 assigned paths, 426 insertions and 16 deletions. All 11 are byte-identical to the previously published 4ba integration. The later 13 frontend bootstrap paths are baseline changes, outside both assigned paths and all 1,132 actual runner inputs. The unchanged original producer executed on the final clean commit and reproduced committed output SHA256 `{digest}` (1,129 closure files, 102 targets); both own binding digests match. Canonical 226 records, all eight source digests, original BEFORE and both QPS replacement rows are preserved.

Test executions retain their actual identities: 36 passed on `b5035927` (18 materializer, 7 assets, 10 caller, 1 sealed CLI), and 15 retained at frozen `56255189` (7 roster, 8 finalizer VM models). These are not executions on final 73. The final positive allowlist expects and executes zero new callbacks, supported by whole-file equality for all 1,132 runner inputs and the same observed Node binary. The original roster/finalizer input proofs and published archive/log digest verification remain available.

On final `{HEAD}`, the original producer, original static boundary (errors=[]), prepared local PR contract, commit contract against actual master, layout, catalog check, declarations (146 tiers, no qualification), document lifecycle, authoritative docs, narrow preservation, four-file source style and focused Markdownlint all exited zero. Final run identity is `{h['verification']['actualFinalChecks']['runId']}`. Commands, timestamps, exit codes, commit identities, dirty-state checks and logs are in latest-537. Earlier successful, failed and blocked records keep their original identities.

#3601 remains OPEN/WIP. SAME reviewer `01a11b5c-e4f5-7766-8857-424457fa7008` must review the complete final 11-path combination; the coordinator must forward the included request. Current-epoch catalog admission, two historical QPS BEFORE refusals requiring the original history owner, real cgroup/native/runtime and interrupted-flow qualification, and the separate global review/merge barrier remain outstanding. Known cgroup lane failure is retained without rerunning it. No held scheduler, receipt, Git replacement, cohort, lease or native audit was run; no content API, new PR, remote PR merge, master push, issue closure, deployment or package publication occurred.

This separate evidence tree is not an execution candidate or qualification receipt. See handoff-master-integration.json and same-reviewer-final-combination-request.json. The previous published source/evidence identities remain recorded independently.
''')
print(json.dumps({'head':HEAD,'base':BASE,'paths':len(paths),'fixedPoint':digest,'checksPassed':len(checks),'remoteRefs':refs,'evidenceLocal':str(O)},indent=2))
