from pathlib import Path
import datetime
import json
import os
import subprocess
import sys
import uuid

root = Path('/workspace/chain-3601-master-integration')
out = Path('/tmp/chain-3601-master-integration-20261009/latest-537')
env = os.environ.copy()
env['PATH'] = '/workspace/chain-3601-toolchain/node-v24.16.0-linux-x64/bin:/workspace/chain-3601-toolchain/markdownlint/node_modules/.bin:/workspace/chain-3601-toolchain/dotnet:' + env['PATH']
env['npm_config_cache'] = '/tmp/fsusblog-chain-3601-npm-cache'
env['npm_execpath'] = '/workspace/chain-3601-toolchain/npm/node_modules/npm/bin/npm-cli.js'
name, command = sys.argv[1], sys.argv[2:]
sha = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
start = datetime.datetime.now(datetime.timezone.utc).isoformat()
status = subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True)
diff_bytes = subprocess.check_output(['git','diff','--binary','HEAD'],cwd=root)
import hashlib
input_diff_digest = hashlib.sha256(diff_bytes).hexdigest()
run_id_path = out / 'run-id.txt'
if not run_id_path.exists():
    run_id_path.write_text('chain3601-master-integration-' + datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '-' + uuid.uuid4().hex[:10] + '\n')
with (out / (name + '.log')).open('w') as log:
    result = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
record = {'name': name, 'sha': sha, 'runId': run_id_path.read_text().strip(),
          'command': command, 'exit': result.returncode,
          'startedAt': start, 'endedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'log': name + '.log', 'qualification': False, 'supplierReceiptReused': False, 'sourceDirtyAtStart': bool(status.strip()), 'inputDiffSha256': input_diff_digest}
(out / (name + '.run.json')).write_text(json.dumps(record, indent=2) + '\n')
(out / (name + '.exit')).write_text(str(result.returncode) + '\n')
print(json.dumps(record))
print('\n'.join((out / (name + '.log')).read_text().splitlines()[-18:]))
