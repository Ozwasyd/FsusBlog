using System.Reflection;
using System.Runtime.Loader;
using System.Text.Json;
string directory = "/workspace/FsusBlog/tests/backend/bin/Debug/net10.0";
AssemblyLoadContext.Default.Resolving += (_, name) => { string p=Path.Combine(directory,name.Name+".dll"); return File.Exists(p)?AssemblyLoadContext.Default.LoadFromAssemblyPath(p):null; };
Assembly assembly=AssemblyLoadContext.Default.LoadFromAssemblyPath(Path.Combine(directory,"FsusBlog.Server.Tests.dll"));
Type type=assembly.GetType("FsusBlog.Server.Tests.AuthoringExtensionRpcTests",true)!;
MethodInfo method=type.GetMethod("MutationPreview_ExactFramedMaterialMatchesIndependentLiteralVectors")!;
string intended="a\n\0é𝄞\ud800";
string expected="89f57d854aa2b871834c31342c1451edd26c031936a43cfd444f24187424f008";
string actual=method.GetCustomAttributesData().Where(a=>a.AttributeType.Name=="InlineDataAttribute").Select(a=>(IList<CustomAttributeTypedArgument>)a.ConstructorArguments[0].Value!).Select(a=>(string)a[0].Value!).Single(s=>s.StartsWith("a\n"));
var rows=new List<object>();
foreach ((string label,string text) in new[]{("intended-direct-original-method",intended),("compiled-InlineData-original-method",actual)}) {
 try { await (Task)method.Invoke(Activator.CreateInstance(type),new object[]{text,expected})!; rows.Add(new {label,utf16=text.Select(c=>(int)c).ToArray(),passed=true}); }
 catch(Exception e){rows.Add(new {label,utf16=text.Select(c=>(int)c).ToArray(),passed=false,error=e.ToString()});}
}
Console.WriteLine(JsonSerializer.Serialize(rows,new JsonSerializerOptions{WriteIndented=true}));
