import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
import {reproduceRuntimeRoleAssembly} from '../tools/docs/behavior-doc-minimal-contract-build.mjs';
import {sealSourceIdentity} from '../tools/fact-extractors/identity.mjs';
const root=process.cwd();
const out=path.resolve(root,'../audit-handoff');
const source=sealSourceIdentity(root);
const sdk=fs.readFileSync(path.join(out,'sdk-version.log'),'utf8').trim();
const node=process.version;
const buildKey=crypto.createHash('sha256').update(JSON.stringify({kind:'ordinary-audit-project-output-key',source,sdk,node,configuration:'Release',audit:true,locked:true,CI:process.env.CI,configDigest:crypto.createHash('sha256').update(fs.readFileSync(process.env.RestoreConfigFile)).digest('hex')})).digest('hex');
const record={kind:'actual ordinary audit-on build execution; not canonical v3 admission receipt',source,sdk,node,buildKey,configuration:'Release',nuGetAudit:true,restoreLockedMode:process.env.RestoreLockedMode,CI:process.env.CI,GITHUB_ACTIONS:process.env.GITHUB_ACTIONS??null,startedAt:new Date().toISOString(),processes:[]};
const names=['CI','GITHUB_ACTIONS','RestoreLockedMode','RestoreConfigFile','NuGetAudit','NuGetAuditMode','NuGetAuditLevel','DOTNET_CLI_HOME','NUGET_PACKAGES','NUGET_HTTP_CACHE_PATH','TMPDIR','MSBUILDDISABLENODEREUSE'];
const captureActualSpawn=(command,args,options)=>{
 const start=Date.now();
 const result=spawnSync(command,args,options);
 fs.writeFileSync(path.join(out,'runtime-role-build.log'),String(result.stdout??'')+String(result.stderr??''));
 record.processes.push({command,args,cwd:options.cwd,stdio:options.stdio,timeout:options.timeout,selectedEnvironment:Object.fromEntries(names.map(n=>[n,options.env[n]??null])),status:result.status,signal:result.signal,errorCode:result.error?.code??null,durationMs:Date.now()-start});
 return result;
};
try{
 record.originalApiResult=reproduceRuntimeRoleAssembly({repositoryRoot:root,buildKey,nuGetAudit:true,spawn:captureActualSpawn});
 record.status='succeeded';
}catch(error){record.status='failed';record.failure=String(error.message);process.exitCode=1;}
record.finishedAt=new Date().toISOString();
fs.writeFileSync(path.join(out,'ordinary-build-execution.json'),JSON.stringify(record,null,2)+'\n');
console.log(JSON.stringify({status:record.status,source:source.commit,sdk,buildKey,rawLog:'runtime-role-build.log'}));
