import { writeFileSync } from 'node:fs';
import { inspectReleaseFinalCommandTarget } from '/tmp/issue-3534-2899-import-probe/tools/test-matrix/release-final-static-boundary.mjs';
const root = '/tmp/issue-3534-2899-import-probe';
const result = inspectReleaseFinalCommandTarget({ repositoryRoot: root, target: 'tools/test-matrix/scheduler.mjs' });
writeFileSync(process.argv[2], JSON.stringify(result, null, 4) + '\n');
console.log(JSON.stringify({ errors: result.errors, dependency: result.dependencyClosure?.find((entry) => entry.path === 'tools/test/evidence-location-contract.mjs'), dependencyCount: result.dependencyClosure?.length }));
