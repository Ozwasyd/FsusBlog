import assert from 'node:assert/strict';
import fs from 'node:fs';
import { inspectReleaseFinalCommandTarget } from '/tmp/issue-3534-2899-import-probe/tools/test-matrix/release-final-static-boundary.mjs';
const root = '/tmp/issue-3534-2899-import-probe';
const target = 'tools/test-matrix/scheduler.mjs';
const relative = 'tools/test/evidence-location-contract.mjs';
const file = root + '/' + relative;
const original = fs.readFileSync(file);
const rows = [];
try {
    fs.writeFileSync(file, Buffer.concat([original, Buffer.from('\n// isolated canonical-byte mutation control\n')]));
    const altered = inspectReleaseFinalCommandTarget({ repositoryRoot: root, target });
    assert.ok(altered.errors.some((message) => message.includes(relative + ' working-tree bytes differ from the repository index')));
    rows.push({ variant: 'canonical-owner-byte-mutation', originalCheckerRefused: true, errors: altered.errors });
    fs.writeFileSync(file, original);
    fs.renameSync(file, file + '.diagnostic-missing');
    const absent = inspectReleaseFinalCommandTarget({ repositoryRoot: root, target });
    assert.ok(absent.errors.some((message) => message.includes(relative) || message.includes('evidence-location-contract')));
    rows.push({ variant: 'canonical-owner-file-missing', originalCheckerRefused: true, errors: absent.errors });
} finally {
    if (fs.existsSync(file + '.diagnostic-missing')) fs.renameSync(file + '.diagnostic-missing', file);
    fs.writeFileSync(file, original);
    assert.ok(fs.readFileSync(file).equals(original));
}
const result = { diagnosticOnly: true, originalSourceBytesRestored: true, controls: rows };
fs.writeFileSync('/workspace/FsusBlog/.tmp/issue-3534-2899-import-review/negative-dependency-controls.json', JSON.stringify(result, null, 4) + '\n');
console.log(JSON.stringify(result));
