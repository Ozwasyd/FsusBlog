import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const repositoryRoot = process.cwd();
const scannerPath = 'tools/docs/behavior-document-consistency-final.mjs';
const helperPath = 'tests/tools/support/zero-legacy-scanner-fixture.mjs';
const probePath = 'tests/tools/behavior-rejection-probe.mjs';
const scannerModule = await import(pathToFileURL(path.join(repositoryRoot, scannerPath)));
const { ESLint } = await import(pathToFileURL(path.join(repositoryRoot, 'tools/frontend/style-toolchain/node_modules/eslint/lib/api.js')));
const eslint = new ESLint({ cwd: repositoryRoot, overrideConfigFile: path.join(repositoryRoot, 'eslint.config.mjs') });
const source = fs.readFileSync(path.join(repositoryRoot, 'tests/tools/behavior-document-consistency-final.test.mjs'), 'utf8');
const start = source.indexOf("test('zero-legacy machine-field mutation corpus");
const callback = source.slice(start, source.indexOf('\ntest(', start + 1));
const staticImports = [
    "import assert from 'node:assert/strict';",
    "import test from 'node:test';",
    '',
    "import { scanZeroLegacyGovernance } from '../../tools/docs/behavior-document-consistency-final.mjs';",
    '',
    "import { createZeroLegacyScannerFixture } from './support/zero-legacy-scanner-fixture.mjs';"
].join('\n');
const dynamicImports = [
    "import assert from 'node:assert/strict';",
    "import test from 'node:test';",
    '',
    "import { createZeroLegacyScannerFixture } from './support/zero-legacy-scanner-fixture.mjs';",
    "const { scanZeroLegacyGovernance } = await import(new URL('../../tools/docs/behavior-document-consistency-final.mjs', import.meta.url));"
].join('\n');
const parserPaths = [
    'src/frontend/package.json', 'src/frontend/package-lock.json',
    'src/frontend/node_modules/playwright-core/package.json',
    'src/frontend/node_modules/playwright-core/lib/utilsBundleImpl/index.js',
    'src/frontend/node_modules/typescript/package.json',
    'src/frontend/node_modules/typescript/lib/typescript.js'
];
const cases = [
    ['canonical-static-import-two-space-lock', staticImports, callback, 2, null],
    ['equivalent-explicit-url-import-two-space-lock', dynamicImports, callback, 2, null],
    ['fake-static-import-two-space-lock', staticImports.replace('../../tools/docs/behavior-document-consistency-final.mjs', './fake-scanner.mjs'), callback, 2, null],
    ['missing-assertion-two-space-lock', staticImports, callback.replace(/ {4}assert\.ok\(rules\.includes\('forbidden-self-certification:reviewed'\)\);?\n/u, ''), 2, null],
    ['changed-helper-two-space-lock', staticImports, callback, 2, 'clear-input'],
    ['canonical-static-import-actual-four-space-lock', staticImports, callback, 4, null]
];
const results = [];
for (const [name, imports, body, lockIndent, helperMutation] of cases)
{
    const fixtureRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'issue-3534-import-lock-probe-'));
    try
    {
        const fixtureSource = `${imports}\n\n${body}`;
        const files = new Map(parserPaths.map((relative) => [relative, fs.readFileSync(path.join(repositoryRoot, relative))]));
        const actualLock = files.get('src/frontend/package-lock.json');
        if (lockIndent === 2)
        {
            files.set('src/frontend/package-lock.json', Buffer.from(`${JSON.stringify(JSON.parse(actualLock), null, 2)}\n`));
        }
        let helper = fs.readFileSync(path.join(repositoryRoot, helperPath), 'utf8');
        if (helperMutation)
        {
            helper = helper.replace('    const inputEntries', '    files = {}\n    const inputEntries');
        }
        files.set(scannerPath, fs.readFileSync(path.join(repositoryRoot, scannerPath)));
        files.set(helperPath, Buffer.from(helper));
        files.set(probePath, Buffer.from(fixtureSource));
        for (const [relative, bytes] of files)
        {
            const absolute = path.join(fixtureRoot, relative);
            fs.mkdirSync(path.dirname(absolute), { recursive: true });
            fs.writeFileSync(absolute, bytes, { flag: 'wx' });
            fs.chmodSync(absolute, 0o644);
        }
        const [lint] = await eslint.lintText(fixtureSource, { filePath: path.join(repositoryRoot, probePath) });
        let rules = null;
        let error = null;
        try
        {
            rules = scannerModule.scanZeroLegacyGovernance(fixtureRoot).findings
                .filter((finding) => finding.file === probePath).map((finding) => finding.rule);
        }
        catch (failure)
        {
            error = failure.message;
        }
        results.push({ name, lockIndent, syntheticLockReserialization: lockIndent === 2,
            lintRules: lint.messages.map((message) => message.ruleId), scannerRules: rules, error });
    }
    finally
    {
        fs.rmSync(fixtureRoot, { recursive: true, force: true });
    }
}
assert.deepEqual(results[0].scannerRules, []);
assert.deepEqual(results[1].lintRules, []);
assert.ok(results[1].scannerRules.includes('forbidden-machine-field:lastVerifiedCommit'));
for (const result of results.slice(2, 5))
{
    assert.ok(result.scannerRules.includes('forbidden-machine-field:lastVerifiedCommit'));
}
assert.match(results[5].error, /JSONC parser package lock must be canonical duplicate-free JSON/u);
const nativeModuleAgain = await import(new URL(scannerPath, pathToFileURL(`${repositoryRoot}/`)));
const result = { status: 'diagnostic-only', qualificationEligible: false,
    productionScannerAndPoliciesModified: false,
    syntheticInputsDoNotReplaceCurrentLockOrReceipts: true,
    nativeExplicitUrlImportResolvesIdenticalScannerFunction: nativeModuleAgain.scanZeroLegacyGovernance === scannerModule.scanZeroLegacyGovernance,
    results };
fs.mkdirSync('.tmp/issue-3534-continuation', { recursive: true });
fs.writeFileSync('.tmp/issue-3534-continuation/import-lock-probe.json', `${JSON.stringify(result, null, 4)}\n`);
console.log(JSON.stringify(result, null, 4));
