import json,subprocess,sys,pathlib,datetime
out=pathlib.Path('/workspace/issue-3534-handoffs/cpp-lookup-correction')
node='/workspace/.task-tools/issue-3534-node24/node-v24.16.0-linux-x64/bin/node'
base='720d9948087cf176eccf7bdd5cc0be85f8cab606'
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
name=sys.argv[1]
selection=json.loads((out/'test-selection.json').read_text())
commands={
 'candidate-controls':[node,'--test','--test-name-pattern='+selection['pattern'],selection['file']],
 'candidate-matrix':[node,str(out/'verify.mjs')],
 'candidate-source-diff':[node,'tools/frontend/check-frontend-style.mjs','--mode','source-diff','--base',base,'--file','tools/style/check-native-tooling-style.mjs','--file','tests/tools/native-tooling-style.test.mjs'],
 'candidate-range-contract':[node,'tools/governance/check-change-contract.mjs','--range',base+'..HEAD'],
 'candidate-checker-syntax':[node,'--check','tools/style/check-native-tooling-style.mjs'],
 'candidate-test-syntax':[node,'--check',selection['file']],
 'candidate-whitespace':['git','diff','--check',base+'..HEAD']
}
argv=commands[name]
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
r=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
(out/(name+'.log')).write_text(r.stdout)
(out/(name+'-command.json')).write_text(json.dumps({'name':name,'base':base,'candidate':head,'argv':argv,'exitCode':r.returncode,'expectedExitCode':0,'startedAtUtc':started,'completedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
print(name+' exit='+str(r.returncode)+' candidate='+head)
print(r.stdout[-3500:])
raise SystemExit(r.returncode)
