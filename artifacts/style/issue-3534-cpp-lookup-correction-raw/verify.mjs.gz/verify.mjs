import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawnSync, execFileSync } from 'node:child_process';
import * as espree from '/workspace/issue-3534-cpp-lookup-correction/tools/frontend/style-toolchain/node_modules/espree/espree.js';
const root = '/workspace/issue-3534-cpp-lookup-correction';
const out = '/workspace/issue-3534-handoffs/cpp-lookup-correction';
const base = '720d9948087cf176eccf7bdd5cc0be85f8cab606';
const old = '6fe5eb07b93743ac32585eb69899356f96715482';
const file = 'tests/tools/native-tooling-style.test.mjs';
const ast = espree.parse(fs.readFileSync(path.join(root, file), 'utf8'), {ecmaVersion: 'latest', sourceType: 'module'});
const oldSelection = JSON.parse(fs.readFileSync('/workspace/issue-3534-handoffs/cpp-object-correction/test-selection.json', 'utf8'));
const added = ['ignores spliced logical comments before admitting values', 'sees later class type declarations inside inline methods'].map(n => 'native tooling style governance '+n);
const names = [...oldSelection.exactPositiveAllowlist, ...added];
const tests = ast.body.filter(n => n.type === 'ExpressionStatement' && n.expression.callee?.name === 'test');
const pattern = '^(?:'+names.map(n => n.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|')+')$';
const selected = tests.filter(n => new RegExp(pattern).test(n.expression.arguments[0]?.value));
assert.equal(selected.length, 13);
assert.equal(new Set(selected.map(n=>n.expression.arguments[0].value)).size, 13);
assert.equal(tests.length-selected.length,29);
fs.writeFileSync(path.join(out, 'test-selection.json'), JSON.stringify({base,file,expectedTopLevelTests:13,exactPositiveAllowlist:names,pattern,inspectedBeforeExecution:true,unselectedTopLevelTests:29,excluded:oldSelection.excluded},null,2)+'\n');
console.log('Inspected exact positive allowlist: 13 selected, 29 unselected; no whole-suite invocation.');
const cases=[];
for (const test of selected.filter(n=>names.slice(7).includes(n.expression.arguments[0].value))) {
 const queue=[test.expression.arguments[1]], found=[];
 while(queue.length) {const node=queue.pop();if(!node||typeof node!=='object')continue;if(node.type==='VariableDeclarator'&&node.id?.name==='fixtures')found.push(node.init);for(const child of Object.values(node)){if(Array.isArray(child))queue.push(...child);else if(child&&typeof child==='object')queue.push(child);}}
 assert.equal(found.length,1);assert.equal(found[0].type,'ArrayExpression');
 for(const element of found[0].elements){const props=Object.fromEntries(element.properties.map(p=>[p.key.name,p.value.value]));assert.equal(typeof props.source,'string');assert.equal(typeof props.accepted,'boolean');for(const extension of ['hpp','cpp'])cases.push({test:test.expression.arguments[0].value,extension,...props});}
}
assert.equal(cases.length,34);
const selection=JSON.parse(fs.readFileSync(path.join(out,'test-selection.json'),'utf8'));selection.expectedCppFixtureRows=34;selection.exactFixtureAllowlist=cases.map(c=>({test:c.test,extension:c.extension,accepted:c.accepted,sourceSha256:crypto.createHash('sha256').update(c.source).digest('hex')}));fs.writeFileSync(path.join(out,'test-selection.json'),JSON.stringify(selection,null,2)+'\n');console.log('Inspected exact fixture allowlist: 34 C++23 rows across both extensions.');
if (process.argv.includes('--selection-only')) process.exit(0);
const rows=[];
for (const p of ['tools/style/check-native-tooling-style.mjs','tests/tools/native-tooling-style.test.mjs']) assert.equal(fs.readFileSync('/workspace/issue-3534-cpp-object-correction/'+p,'utf8'),execFileSync('git',['-C',root,'show',old+':'+p],{encoding:'utf8'}));
for(const c of cases){
 const fixtureRoot=fs.mkdtempSync(path.join(os.tmpdir(),'issue-3534-cpp-correction-'));
 try {
  for(const f of ['.clang-format','.clang-tidy','.cmake-format.yaml','.editorconfig','.markdownlint-cli2.jsonc','.shellcheckrc','.yamllint.yml','config/development/native-tooling-style-policy.json','config/development/native-tooling-style-exceptions.json','config/development/authoritative-development-docs.json']){fs.mkdirSync(path.dirname(path.join(fixtureRoot,f)),{recursive:true});fs.copyFileSync(path.join(root,f),path.join(fixtureRoot,f));}
  const sourceFile='sample/Classification.'+c.extension;fs.mkdirSync(path.join(fixtureRoot,'sample'));fs.writeFileSync(path.join(fixtureRoot,sourceFile),c.source);
  const argv=['-std=c++23','-fsyntax-only','-x','c++',path.join(fixtureRoot,sourceFile)];
  const compiler=spawnSync('g++',argv,{encoding:'utf8'});
  const oldArgv=['/workspace/issue-3534-cpp-object-correction/tools/style/check-native-tooling-style.mjs','--root',fixtureRoot,'--policy','config/development/native-tooling-style-policy.json','--mode','changed','--file',sourceFile];
  const before=spawnSync(process.execPath,oldArgv,{cwd:fixtureRoot,encoding:'utf8',env:{...process.env,FSUSBLOG_STYLE_DISABLE_EXTERNAL_TOOLS:'1'}});
  const newArgv=[path.join(root,'tools/style/check-native-tooling-style.mjs'),...oldArgv.slice(1)];
  const after=spawnSync(process.execPath,newArgv,{cwd:fixtureRoot,encoding:'utf8',env:{...process.env,FSUSBLOG_STYLE_DISABLE_EXTERNAL_TOOLS:'1'}});
  rows.push({...c,sourceSha256:crypto.createHash('sha256').update(c.source).digest('hex'),compiler:{argv:['g++',...argv],exitCode:compiler.status,output:compiler.stdout+compiler.stderr},old:{candidate:old,argv:[process.execPath,...oldArgv],exitCode:before.status,output:before.stdout+before.stderr},corrected:{argv:[process.execPath,...newArgv],exitCode:after.status,output:after.stdout+after.stderr}});
 } finally {fs.rmSync(fixtureRoot,{recursive:true,force:true});}
}
const report={base,candidate:execFileSync('git',['-C',root,'rev-parse','HEAD'],{encoding:'utf8'}).trim(),workingTree:execFileSync('git',['-C',root,'status','--short'],{encoding:'utf8'}),checkedOwnerSha256:Object.fromEntries(['tools/style/check-native-tooling-style.mjs','tests/tools/native-tooling-style.test.mjs'].map(p=>[p,crypto.createHash('sha256').update(fs.readFileSync(path.join(root,p))).digest('hex')])),compiler:execFileSync('g++',['--version'],{encoding:'utf8'}).split('\n')[0],expectedRows:34,qualification:'Actual C++23 syntax only, no product or runtime qualification; portable classifier is tested explicitly, mandatory external-tool control remains selected separately.',cleanup:'Every task fixture removed in finally',rows};
fs.writeFileSync(path.join(out,'matrix.json'),JSON.stringify(report,null,2)+'\n');
assert.ok(rows.every(r=>r.compiler.exitCode===0),JSON.stringify(rows.filter(r=>r.compiler.exitCode!==0)));
assert.equal(rows.filter(r=>!r.accepted&&r.old.exitCode===0).length,6);
assert.equal(rows.filter(r=>r.accepted&&r.old.exitCode!==0).length,0);
assert.ok(rows.every(r=>r.accepted?r.corrected.exitCode===0:r.corrected.exitCode!==0&&/cpp-function-name: bad_name/.test(r.corrected.output)),JSON.stringify(rows.filter(r=>r.accepted?r.corrected.exitCode!==0:r.corrected.exitCode===0||!/cpp-function-name: bad_name/.test(r.corrected.output))));
console.log('34/34 C++23 syntax rows pass; preserved original 20 and requested 8 adjacent cases; reproduced 6fe5 four requested + two inherited-lookup false accepts; corrected 34/34 classifications; both .hpp and .cpp; task fixtures cleaned.');
