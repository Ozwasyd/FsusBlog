import json,subprocess,sys,pathlib
out=pathlib.Path('/workspace/issue-3534-handoffs/cpp-object-correction')
node='/tmp/node-v24.16.0-linux-x64/bin/node'
base='85aa75af8949401ef9997c5042d22b1071414e0a'
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
name=sys.argv[1]
selection=json.loads((out/'test-selection.json').read_text())
commands={
 'candidate-controls':[node,'--test','--test-name-pattern='+selection['pattern'],selection['file']],
 'candidate-matrix':[node,str(out/'verify.mjs')],
 'candidate-source-diff':[node,'tools/frontend/check-frontend-style.mjs','--mode','source-diff','--base',base,'--file','tools/style/check-native-tooling-style.mjs','--file','tests/tools/native-tooling-style.test.mjs'],
 'candidate-range-contract':[node,'tools/governance/check-change-contract.mjs','--range',base+'..HEAD'],
 'candidate-repository-contract':[node,'tools/governance/check-change-contract.mjs','--repository'],
 'candidate-checker-syntax':[node,'--check','tools/style/check-native-tooling-style.mjs'],
 'candidate-test-syntax':[node,'--check',selection['file']],
 'candidate-whitespace':['git','diff','--check',base+'..HEAD']
}
argv=commands[name]
r=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
(out/(name+'.log')).write_text(r.stdout)
(out/(name+'-command.json')).write_text(json.dumps({'name':name,'base':base,'candidate':head,'argv':argv,'exitCode':r.returncode,'expectedExitCode':0},indent=2)+'\n')
print(name+' exit='+str(r.returncode)+' candidate='+head)
print(r.stdout[-3500:])
raise SystemExit(r.returncode)
