import assert from 'node:assert/strict';
import fs from 'node:fs';
import { spawnSync, execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import * as espree from '/workspace/issue-3534-cpp-object/tools/frontend/style-toolchain/node_modules/espree/espree.js';
const root='/workspace/issue-3534-cpp-object';
const source=fs.readFileSync(root+'/tests/tools/native-tooling-style.test.mjs','utf8');
const ast=espree.parse(source,{ecmaVersion:'latest',sourceType:'module'});
const names=['native tooling style governance accepts header objects initialized from visible values','native tooling style governance rejects incorrectly named real C++ declarations','native tooling style governance keeps ambiguous C++ parameter syntax strict'];
const cases=[];
for(const name of names){
 const test=ast.body.find(n=>n.type==='ExpressionStatement'&&n.expression.callee?.name==='test'&&n.expression.arguments[0]?.value===name);
 assert.ok(test);
 const pending=[test.expression.arguments[1]];const declarations=[];
 while(pending.length){const n=pending.pop();if(!n||typeof n!=='object')continue;if(n.type==='VariableDeclarator'&&['source','declarations'].includes(n.id.name)&&n.init)declarations.push(n);for(const child of Object.values(n)){if(Array.isArray(child))pending.push(...child);else if(child&&typeof child==='object')pending.push(child);}}
 assert.equal(declarations.length,1);
 const init=declarations[0].init;
 if(init.type==='TemplateLiteral'){assert.equal(init.expressions.length,0);cases.push({test:name,source:init.quasis[0].value.cooked});}
 else{assert.equal(init.type,'ArrayExpression');for(const item of init.elements)cases.push({test:name,source:'struct Input;\nstruct Reader;\nstruct Unknown;\nusing input = int;\n'+item.value+'\n'});}
}
assert.equal(cases.length,20);
const rows=cases.map(c=>{const argv=['-std=c++23','-fsyntax-only','-x','c++','-'];const r=spawnSync('g++',argv,{input:c.source,encoding:'utf8'});return{test:c.test,source:c.source,sourceSha256:createHash('sha256').update(c.source).digest('hex'),argv:['g++',...argv],exitCode:r.status,output:r.stdout+r.stderr};});
fs.writeFileSync('/workspace/issue-3534-handoffs/cpp-object-classification/fixture-syntax.json',JSON.stringify({candidate:execFileSync('git',['-C',root,'rev-parse','HEAD'],{encoding:'utf8'}).trim(),expectedFixtureTranslationUnits:20,compiler:execFileSync('g++',['--version'],{encoding:'utf8'}).split('\n')[0],qualification:'Syntax-only positive object and genuine function/ambiguous declaration fixtures; no linking/execution or product qualification',rows},null,2)+'\n');
assert.ok(rows.every(r=>r.exitCode===0),JSON.stringify(rows.filter(r=>r.exitCode!==0)));
console.log('20/20 selected ordinary declaration fixtures compile under C++23; no native product executed');
