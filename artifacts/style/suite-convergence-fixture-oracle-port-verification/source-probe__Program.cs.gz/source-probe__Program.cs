using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using System.Text.Json;
using System.Security.Cryptography;
using System.Text;
var directory = "/tmp/fsusblog-3593/migration-fixture-ports";
CompilationUnitSyntax Parse(string file) {
 var tree=CSharpSyntaxTree.ParseText(File.ReadAllText(file),new CSharpParseOptions(LanguageVersion.Preview));
 if(tree.GetDiagnostics().Any(d=>d.Severity==DiagnosticSeverity.Error))throw new Exception("Parse refused "+file);
 return tree.GetCompilationUnitRoot();
}
Dictionary<string,string> Cases(SyntaxNode node) => node.DescendantNodes().OfType<MethodDeclarationSyntax>().Where(m=>m.AttributeLists.SelectMany(a=>a.Attributes).Any(a=>a.Name.ToString() is "Fact" or "Theory")).ToDictionary(m=>m.Ancestors().OfType<ClassDeclarationSyntax>().First().Identifier.Text+"."+m.Identifier.Text,m=>string.Join("|",m.AttributeLists.SelectMany(a=>a.DescendantTokens()).Select(t=>$"{t.RawKind}:{t.Text}:{t.ValueText}:{t.IsMissing}")));
bool IsProtected(SyntaxToken t) {if(!t.IsKind(SyntaxKind.StringLiteralToken))return false;var v=t.ValueText;return v.Contains('\0') || new[]{"CREATE ","INSERT ","UPDATE ","DELETE ","ALTER ","DROP ","PRAGMA "}.Any(prefix=>v.TrimStart().StartsWith(prefix,StringComparison.OrdinalIgnoreCase));}
var result=new List<object>();
foreach(var row in JsonDocument.Parse(File.ReadAllText(Path.Combine(directory,"source-map.json"))).RootElement.EnumerateArray()){
 var path=row.GetProperty("path").GetString()!;var before=Parse(row.GetProperty("before").GetString()!);var after=Parse(row.GetProperty("after").GetString()!);var b=Cases(before);var a=Cases(after);
 if(b.Count!=a.Count||b.Any(e=>!a.TryGetValue(e.Key,out var value)||e.Value!=value))throw new Exception("Original Fact/Theory identity or data attributes changed "+path);
 var oldProtected=before.DescendantTokens().Where(IsProtected).GroupBy(t=>t.Text).ToDictionary(g=>g.Key,g=>g.Count());var newProtected=after.DescendantTokens().Where(IsProtected).GroupBy(t=>t.Text).ToDictionary(g=>g.Key,g=>g.Count());
 if(oldProtected.Any(e=>!newProtected.TryGetValue(e.Key,out var count)||count<e.Value))throw new Exception("Original SQL/NUL literal input removed "+path);
 result.Add(new{path,originalTestMethods=b.Count,exactTestNamesAndAttributeTokensPreserved=true,protectedSqlAndNulLiteralOccurrences=oldProtected.Values.Sum(),protectedLiteralOccurrencesPreserved=true,originalAttributesSha256=Convert.ToHexStringLower(SHA256.HashData(Encoding.UTF8.GetBytes(string.Join('\n',b.OrderBy(e=>e.Key).Select(e=>e.Key+"="+e.Value)))))});
}
Console.WriteLine(JsonSerializer.Serialize(new{results=result,scope="Exact original Fact/Theory names and data attribute tokens; original SQL/NUL string input occurrences retained. Canonical assertion changes are authorized separately; this probe grants no runtime or native qualification."},new JsonSerializerOptions{WriteIndented=true}));
