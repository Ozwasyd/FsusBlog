import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { javascriptFormatFingerprint } from '/tmp/fsusblog-3593/trusted-base/tools/governance/javascript-format-equivalence.mjs';
const dir = '/tmp/fsusblog-3593/leaf-current-master';
const path = 'tests/tools/test-suite-convergence.test.mjs';
const before = JSON.parse(javascriptFormatFingerprint(readFileSync(`${dir}/mechanical-pass-2.mjs`, 'utf8'), path));
const after = JSON.parse(javascriptFormatFingerprint(readFileSync(`${dir}/canonical-final.mjs`, 'utf8'), path));
let wrappers = 0;
function normalize(node) {
    if (Array.isArray(node)) return node.map(normalize);
    if (!node || typeof node !== 'object') return node;
    const result = Object.fromEntries(Object.entries(node).map(([key, value]) => [key, normalize(value)]));
    if (result.type === 'ForOfStatement' && result.right.type === 'Identifier' && result.right.name === 'trustedPaths' && result.body.type === 'BlockStatement') {
        assert.equal(result.body.body.length, 1);
        const sole = result.body.body[0];
        assert.equal(sole.type, 'ExpressionStatement');
        assert.equal(sole.expression.callee.object.name, 'assert');
        assert.equal(sole.expression.callee.property.name, 'ok');
        result.body = sole;
        wrappers++;
    }
    if (result.type === 'Program') {
        const imports = result.body.filter(value => value.type === 'ImportDeclaration');
        assert.equal(result.body.slice(0, imports.length).every(value => value.type === 'ImportDeclaration'), true);
        result.body = [...imports.sort((a,b) => a.source.value.localeCompare(b.source.value)), ...result.body.slice(imports.length)];
    }
    return result;
}
assert.deepEqual(normalize(before.ast), normalize(after.ast));
assert.equal(wrappers, 1);
assert.deepEqual(before.comments.map(x=>({type:x.type,value:x.value})), after.comments.map(x=>({type:x.type,value:x.value})));
writeFileSync(`${dir}/canonical-equivalence.json`, `${JSON.stringify({ completeAstEqualAfterOnlyImportOrderAndExactTrustedPathsSingleStatementWrapperNormalization: true, exactBlockWrappers: wrappers, commentsPreserved: true, literalRawValuesAndAssertionExpressionsPreserved: true, stageIsFormatOnly: false, noOracleChanges: true }, null, 2)}\n`);
