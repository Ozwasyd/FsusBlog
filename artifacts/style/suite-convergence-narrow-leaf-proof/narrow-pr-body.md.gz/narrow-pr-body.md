## Linked Issue

Refs #3593

<!-- Choose exactly one primary line: Refs #1234 keeps unfinished issue work open; Closes #1234 is for the child issue fully accepted by this PR. Keep ordinary explanations and related issues as Markdown links; use Closes only when the complete issue is accepted. -->

## Scope Summary

- Format only the current-master suite-convergence JS test owner, then apply its canonical semicolon, import-order and single-statement brace syntax. Preserve all 17 exact canonical test IDs, assertions, raw literals and comments.
- Seal current source/policy/baseline identities, separate mechanical AST/raw-token/anchored-comment proof and formatter passes, and register the actual pure-format revision later in blame-ignore. Shared rules, ledger and frozen evidence are unchanged.

<!-- The gate requires a substantive summary and at least one checked Tests Run entry. -->

## Change Classification

- [ ] Behavior change
- [ ] Format-only
- [ ] Naming-only
- [ ] Generated output
- [ ] Public contract change
- [ ] External naming exception
- Contract impact: none

`Behavior change`, `Format-only`, and `Naming-only` are mutually exclusive. `Generated output`, `Public contract change`, and `External naming exception` are supplementary.

The gate reads fields only from their named section, rejects duplicate fields or headings hidden in fenced examples, and requires contract checkboxes to be checked. Record a not-applicable reason in `Notes For Reviewers` before checking that review item.

## Tests Run

- [ ] `./tools/test.sh fast`
- [ ] Targeted backend tests:
- [x] Targeted frontend checks: original strict-full owner style passes with zero diagnostics.
- [x] Other: exact retention check-diff passes (governedChanges=0), original replacement controls pass 23/23, and history controls pass 14/14. Original focused leaf is 16/17 because current-master ledger contains 8 conflicting exact declarations. Generated producer --check and convergence matrix member remain red with identical base/candidate errors. See artifacts/style/suite-convergence-narrow-leaf-verification.json.

## UI Evidence

- [ ] Screenshots or video attached for UI changes
- [ ] Mobile layout checked
- [ ] Dark mode checked
- [ ] Accessibility and reduced-motion impact considered

## Coding Convention

- [x] C# mother-style mapping checked
- [x] Formatter/linter run
- [x] No tool default overrides repository style
- [x] Mechanical formatting separated from logic
- [x] `.git-blame-ignore-revs` updated when applicable

For a `Format-only` change, complete every field. The idempotence evidence must be one repository-relative `.json` path changed by this PR and conform to `fsusblog.format-idempotence-evidence.v1`. Use `none` for other changes.

- Formatter identity: none
- Formatter version: none
- Formatter command: none
- Formatter idempotence evidence: none
- Blame-ignore revision: none

## External Naming Exception

For a checked `External naming exception`, point to one changed repository-relative JSON manifest using `fsusblog.external-naming-exceptions.v1`. Each entry binds one registered exception ID to its own changed paths and substantive reason; the union must exactly cover every changed registered naming surface. A missing manifest already named by an authoritative merged PR may instead use `fsusblog.post-merge-external-naming-evidence-repair.v1`; that strict repair binds immutable merge history, unchanged source blob/revision identity, the registered surface, and the exact missing artifact without changing the source again. Use `none` otherwise.

- Exceptions manifest: none

## Documentation / Intent

- [x] Public API docs updated
- [x] Ownership/security/performance intent updated
- [x] Historical handoff archived or source-of-truth updated
- [x] TODO/FIXME references valid issues

## Compatibility And Risk

- [x] [Cross-language coding conventions](../docs/development/coding-conventions.md) reviewed
- [x] Document lifecycle updated: stable facts are current; issue handoffs are historical/proposed; generated docs identify their producer
- [x] External wire / ABI / database / third-party names preserved or explicitly adapted
- [x] Public API impact reviewed
- [x] AEDS frame / binary contract impact reviewed
- [x] Database migration impact reviewed
- [x] Security, auth, moderation, PoW, or privacy impact reviewed
- [x] Docs updated or a reason is recorded below
- [x] Known limitations updated if applicable

## Performance Claim

Use `none` and `Evidence path: none` unless the PR title type is `perf`. For S/M/R/C, the evidence path must be a changed repository-relative JSON manifest using `fsusblog.performance-claim-evidence.v1`; it binds the one perf commit SHA, claim level, `structural-only`/`measured` status, and each changed evidence file with its SHA-256 digest.

- Claim level: none
- Evidence path: none
- Non-goals: runtime, database, public API and performance changes.

## Release Note

The matching `release-note:*` label selects the generated release category. GitHub renders the merged PR title as the release entry, so every included category requires `Summary` to exactly equal the summary portion of the PR title after `type(scope):`; `Category: none` instead requires `Summary: none`. Pure formatting, internal renames, and CI rearrangement must use `Internal/Tooling` or `none`.

- Audience: internal
- Category: Internal/Tooling
- Summary: admit current suite convergence owner style

## Generated Output

For a checked `Generated output`, bind the output to its source through one repository-relative `.json` manifest path changed by this PR. Normal atomic source/output changes use `fsusblog.generated-output-binding.v1`. A generated-only repair for a source omission already merged into the PR base uses `fsusblog.post-merge-generated-output-repair.v1`; it must name one trusted producer and leave its source and generator unchanged. A trusted ordered multi-producer repair uses `fsusblog.post-merge-generated-output-repair-dag.v2` and its registry-owned canonical manifest path. An authenticated bot must identify itself exactly. Use `none` otherwise.

- Generator source: none
- Generated outputs: none
- Digest/evidence: none
- Automation identity: none

## Rollout / Rollback

- Rollout: WIP source candidate for independent review; no merge, deployment or prerequisite acceptance.
- Rollback: revert only the leaf syntax/layout and its later blame registration if original behavior or identity regresses. Preserve original rejection controls.
- Deferred work: canonical #3521 ledger/history closure, catalog-owner atomic current-source/output closure, independent review and actual current-candidate PR gates.
- Known limitations: focused, generated and matrix gates remain red. No green CI or full issue acceptance is claimed.

## Notes For Reviewers

CODEOWNERS may request the configured maintainer for touched paths, but it does not replace this contract. Name the child issue actually closed and keep API, UI, database, security, generated, and mechanical changes separated unless the linked issue explicitly requires one atomic boundary.

The executable change-contract policy files are evaluated from the trusted base and cannot be replaced by the candidate PR that they judge. Until branch protection is available, their bootstrap update is an owner-controlled direct push followed by the post-push audit; do not describe that audit as preventive protection.

The executable source change is confined to tests/tools/test-suite-convergence.test.mjs. C# convention mapping and public API, wire/ABI, database, security and UI reviews are not applicable because those surfaces are unchanged. The aggregate is not format-only: canonical syntax is a separate commit from the pure mechanical migration. Formatter fields therefore use none; the pure mechanical commit has its own declared formatter and idempotence evidence. Current issue/run evidence is historical verification, not a parallel policy authority. No new TODO/FIXME is introduced.

Base: cb6f4e4a174ac65735707c7e44286352803e742b. Tested source receipt: 945a25a6cdf9b225e2acca705b2a3e6eddf8667b. Live GitHub PR creation is paused by the parent API-write restriction; this file is a local draft only, with intended release-note:internal label. Existing broad draft PR #3814 remains untouched. Related parent: [#3543](https://github.com/Ozwasyd/FsusBlog/issues/3543).
