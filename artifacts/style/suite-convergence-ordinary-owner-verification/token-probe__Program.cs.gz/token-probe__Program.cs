using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using System.Text.Json;
using System.Security.Cryptography;
using System.Text;
var directory = "/tmp/fsusblog-3593/ordinary-owner-rosters";
CompilationUnitSyntax Parse(string file)
{
    var tree = CSharpSyntaxTree.ParseText(File.ReadAllText(file), new CSharpParseOptions(LanguageVersion.Preview));
    if (tree.GetDiagnostics().Any(x => x.Severity == DiagnosticSeverity.Error)) throw new Exception("Parse failure " + file);
    return tree.GetCompilationUnitRoot();
}
string[] Tokens(SyntaxNode node) => node.DescendantTokens().Select(t => $"{t.RawKind}|{t.Text}|{t.ValueText}|{t.IsMissing}").ToArray();
string[] Comments(SyntaxNode node) => node.DescendantTrivia().Where(t => t.IsKind(SyntaxKind.SingleLineCommentTrivia) || t.IsKind(SyntaxKind.MultiLineCommentTrivia) || t.IsKind(SyntaxKind.SingleLineDocumentationCommentTrivia) || t.IsKind(SyntaxKind.MultiLineDocumentationCommentTrivia)).Select(t => t.ToFullString()).ToArray();
int Tests(SyntaxNode node) => node.DescendantNodes().OfType<MethodDeclarationSyntax>().Count(m => m.AttributeLists.SelectMany(x => x.Attributes).Any(x => x.Name.ToString() is "Fact" or "Theory"));
int Asserts(SyntaxNode node) => node.DescendantNodes().OfType<InvocationExpressionSyntax>().Count(x => x.Expression.ToString().StartsWith("Assert.", StringComparison.Ordinal));
string[] Shapes(SyntaxNode node) => node.DescendantNodesAndTokens().Select(x => $"{x.RawKind}|{(x.IsNode ? x.AsNode()!.ChildNodesAndTokens().Count : 0)}|{(x.IsNode ? x.AsNode()!.IsMissing : x.AsToken().IsMissing)}").ToArray();
string[] AnchoredTrivia(SyntaxNode node) => node.DescendantTokens().SelectMany((token,index) => token.LeadingTrivia.Select(t => (t,Side:"leading")).Concat(token.TrailingTrivia.Select(t => (t,Side:"trailing"))).Where(x => !x.t.IsKind(SyntaxKind.WhitespaceTrivia) && !x.t.IsKind(SyntaxKind.EndOfLineTrivia)).Select(x => $"{index}|{x.Side}|{x.t.RawKind}|{x.t.ToFullString()}")).ToArray();
bool FullEquivalence(SyntaxNode before,SyntaxNode after) => Shapes(before).SequenceEqual(Shapes(after)) && Tokens(before).SequenceEqual(Tokens(after)) && AnchoredTrivia(before).SequenceEqual(AnchoredTrivia(after)) && SyntaxFactory.AreEquivalent(before.NormalizeWhitespace(),after.NormalizeWhitespace(),topLevel:false);
var negativeControlBefore = CSharpSyntaxTree.ParseText("class C { int Value() => 1; }").GetRoot();
var negativeControlAfter = CSharpSyntaxTree.ParseText("class C { int Value() => 2; }").GetRoot();
if (FullEquivalence(negativeControlBefore,negativeControlAfter)) throw new Exception("Body mutation negative control falsely accepted");
var formats = new List<object>();
foreach (string name in new[] {"rpc", "resolver-production"})
{
    var before = Parse(Path.Combine(directory, name + ".before-format.cs"));
    var after = Parse(Path.Combine(directory, name + ".after-format.cs"));
    if (!FullEquivalence(before,after)) throw new Exception("Format structure/token/anchored-trivia mismatch " + name);
    formats.Add(new { name, completeSyntaxShapesAndAritiesEquivalent = true, normalizedFullSyntaxEquivalent = true, rawUnnormalizedSyntaxApiResult = before.IsEquivalentTo(after,topLevel:false), rawTokensAndValuesEquivalent = true, anchoredNonWhitespaceTriviaEquivalent = true, tokenCount = Tokens(before).Length, tests = Tests(after), assertions = Asserts(after), tokenSha256 = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(string.Join('\n',Tokens(after))))).ToLowerInvariant() });
}
var rosters = new List<object>();
foreach (var item in new[] {
    (Name:"rpc", Path:"/workspace/FsusBlog/tests/backend/Unit/AuthoringExtensionRpcTests.cs", Method:"RpcSource_DoesNotExposeLiveEditorOrDirectMutationAuthority", Expected: new[] {"AuthoringCanonicalDocumentRead","AuthoringDocumentReadReceipt","AuthoringDocumentReadResult","AuthoringNetworkBrokerProposal","AuthoringFileBrokerProposal","IAuthoringCapabilityGrantReadScope","IAuthoringCapabilityGrantReadScopeStore","IAuthoringCapabilityBrokerGrantReadScope","IAuthoringCapabilityBrokerGrantReadScopeStore","IAuthoringCanonicalDocumentReadTransaction"}),
    (Name:"resolver-test", Path:"/workspace/FsusBlog/tests/backend/Unit/AuthoringExtensionExecutionResolverTests.cs", Method:"ResolverSource_HasNoDynamicOrPrivateHostLoadingSurface", Expected: new[] {"IAuthoringInstalledPackageReadScope","IAuthoringInstalledPackageAsyncReadScope","IAuthoringPackageReadScopeStore","IAuthoringInstalledPackageReadScopeAuthority","AuthoringTerminalReadScopes"})})
{
    var before = Parse(Path.Combine(directory, item.Name + ".before-roster.cs"));
    var after = Parse(item.Path);
    var oldMethod = before.DescendantNodes().OfType<MethodDeclarationSyntax>().Single(x => x.Identifier.Text == item.Method);
    var newMethod = after.DescendantNodes().OfType<MethodDeclarationSyntax>().Single(x => x.Identifier.Text == item.Method);
    var oldCollection = oldMethod.DescendantNodes().OfType<CollectionExpressionSyntax>().Single();
    var newCollection = newMethod.DescendantNodes().OfType<CollectionExpressionSyntax>().Single();
    string TypeName(CollectionElementSyntax x) => ((TypeOfExpressionSyntax)((ExpressionElementSyntax)x).Expression).Type.ToString();
    var added = newCollection.Elements.Select(TypeName).Except(oldCollection.Elements.Select(TypeName)).Order().ToArray();
    if (!added.SequenceEqual(item.Expected.Order())) throw new Exception("Unexpected roster additions " + item.Name);
    var kept = newCollection.Elements.Where(x => !item.Expected.Contains(TypeName(x))).ToArray();
    var normalized = after.ReplaceNode(newCollection, newCollection.WithElements(SyntaxFactory.SeparatedList(kept)));
    if (!SyntaxFactory.AreEquivalent(before.NormalizeWhitespace(), normalized.NormalizeWhitespace(), topLevel:false) || !Tokens(before).SequenceEqual(Tokens(normalized)) || !Comments(before).SequenceEqual(Comments(after)) || Tests(before) != Tests(after) || Asserts(before) != Asserts(after)) throw new Exception("Unrelated semantic/token/assertion change " + item.Name);
    rosters.Add(new { item.Name, added, beforeOwners = oldCollection.Elements.Count, afterOwners = newCollection.Elements.Count, exactOldOwnersRetained = true, strictGuardTokensUnchanged = true, otherTokensUnchanged = true, tests = Tests(after), assertions = Asserts(after) });
}
Console.WriteLine(JsonSerializer.Serialize(new { formats, rosters, comparison = "Complete Roslyn syntax shapes/arities and raw token values; anchored non-whitespace trivia; full AST NormalizeWhitespace comparison with topLevel:false", methodBodyMutationNegativeControlRefused = true, runtimeAcceptance = false }, new JsonSerializerOptions { WriteIndented = true }));
