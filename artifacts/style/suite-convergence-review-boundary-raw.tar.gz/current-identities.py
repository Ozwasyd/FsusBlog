from pathlib import Path
import subprocess,json,hashlib,os
root=Path('/workspace/FsusBlog-3593-review');r=Path('/tmp/fsusblog-3593/review-boundary');node='/tmp/fsusblog-3593/node24.16/node-v24.16.0-linux-x64/bin/node';env=dict(os.environ,PATH=str(Path(node).parent)+':'+os.environ['PATH']);binding=json.loads((r/'current-binding.json').read_text());base=binding['base'];head=binding['sourceCandidate'];rows=[]
def git(args):return subprocess.check_output(['git',*args],cwd=root)
def extract(label,rev,owner):
 folder=r/('ast-'+label);(folder/Path(owner).parent).mkdir(parents=True,exist_ok=True);(folder/owner).write_bytes(git(['show',rev+':'+owner]));request=r/(folder.name+'-request.json');request.write_text(json.dumps(dict(root=str(folder),files=[dict(path=owner,adapter='node-test')]))+'\n');cmd=[node,str(root/'tools/test-inventory/ts-ast-adapter/index.mjs'),str(request)];p=subprocess.run(cmd,cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE);(r/(folder.name+'.json')).write_bytes(p.stdout);(r/(folder.name+'.stderr')).write_bytes(p.stderr);assert p.returncode==0;a=json.loads(p.stdout);assert not a['diagnostics'];return sorted(x['id'] for x in a['testCases'])
for i,path in enumerate(['tests/tools/test-suite-convergence.test.mjs','tests/tools/correctness-attempt-migration.test.mjs']):
 before=extract(str(i)+'-base',base,path);after=extract(str(i)+'-candidate',head,path);assert before==after and len(before)==len(set(before));rows.append(dict(path=path,beforeIds=before,afterIds=after,exactEquality=True,countOnlyComparison=False))
assert len(rows[0]['afterIds'])==17 and len(rows[1]['afterIds'])==2
frozen='tests/test-retention-before.json';assert git(['show',base+':'+frozen])==git(['show',head+':'+frozen]);catalog='config/testing/correctness-attempt-producers.json';old=json.loads(git(['show',base+':'+catalog]));new=json.loads(git(['show',head+':'+catalog]));assert old['entries']==new['entries'] and len(new['entries'])==226
cmd=[node,'tools/test/generate-correctness-attempt-producers.mjs'];generated=[]
for i in range(2):
 p=subprocess.run(cmd,cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE);(r/('catalog-canonical-'+str(i)+'.json')).write_bytes(p.stdout);(r/('catalog-canonical-'+str(i)+'.stderr')).write_bytes(p.stderr);assert p.returncode==0;generated.append(p.stdout)
assert generated[0]==generated[1]==git(['show',head+':'+catalog])
result=dict(**binding,exactCaseOwners=rows,all226EntryRecordsUnchanged=True,canonicalProducerCommand=cmd,canonicalProducerExitCodes=[0,0],canonicalProducerOutputBytesExactAndIdempotent=True,frozenBeforeUnchanged=True,frozenBeforeSha256=hashlib.sha256(git(['show',head+':'+frozen])).hexdigest(),frozenBeforeBlob=git(['rev-parse',head+':'+frozen]).decode().strip());(r/'current-identities-proof.json').write_text(json.dumps(result,indent=2)+'\n');print('current original AST identities 17+2 and actual complete 226-entry producer double replay passed')
