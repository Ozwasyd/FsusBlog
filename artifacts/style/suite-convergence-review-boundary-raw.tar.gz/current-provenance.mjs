import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { javascriptFormatFingerprint, validateFormatOnlyDiff } from '/tmp/fsusblog-3593/roster-base-authority/tools/governance/change-contract.mjs';
const root='/workspace/FsusBlog-3593-review';
const owner='tests/tools/test-suite-convergence.test.mjs';
const base='6e287562b3f861d3eb81dcb23f93e6243205abd8';
const head=execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim();
const format='e8def31887dab241d74ad712226290f715ace23d';
const blame='27a09aa6223ca61922c08e96fb1d1760e912c163';
const syntax='f1291150a5b2ff6a7c327fe1bc3b4355bca7f12c';
const git=(args)=>execFileSync('git',args,{cwd:root,encoding:'utf8'});
const source=(rev)=>git(['show',`${rev}:${owner}`]);
for(const rev of [base,format,blame,syntax])git(['merge-base','--is-ancestor',rev,head]);
assert.equal(source(base),source(`${format}^`));
assert.equal(source(head),source(syntax));
assert.ok(git(['show',`${blame}:.git-blame-ignore-revs`]).split('\n').includes(format));
assert.ok(git(['show',`${head}:.git-blame-ignore-revs`]).split('\n').includes(format));
const original=javascriptFormatFingerprint(source(base),owner);
const mechanical=javascriptFormatFingerprint(source(format),owner);
assert.equal(original,mechanical);
assert.notEqual(mechanical,javascriptFormatFingerprint(source(format).replace("'tests/backend/Unit/BackendAuthStateMachineTests.cs'","'tests/backend/Unit/Mutated.ts'"),owner));
const errors=validateFormatOnlyDiff(root,`${format}^`,format);assert.deepEqual(errors,[]);
let wrappers=0;
function normalize(node){
 if(Array.isArray(node))return node.map(normalize);
 if(!node||typeof node!=='object')return node;
 const result=Object.fromEntries(Object.entries(node).map(([k,v])=>[k,normalize(v)]));
 if(result.type==='ForOfStatement'&&result.right.type==='Identifier'&&result.right.name==='trustedPaths'&&result.body.type==='BlockStatement'){
  assert.equal(result.body.body.length,1);const sole=result.body.body[0];assert.equal(sole.type,'ExpressionStatement');assert.equal(sole.expression.callee.object.name,'assert');assert.equal(sole.expression.callee.property.name,'ok');result.body=sole;wrappers++;
 }
 if(result.type==='Program'){
  const imports=result.body.filter(x=>x.type==='ImportDeclaration');assert.ok(result.body.slice(0,imports.length).every(x=>x.type==='ImportDeclaration'));result.body=[...imports.sort((a,b)=>a.source.value.localeCompare(b.source.value)),...result.body.slice(imports.length)];
 }
 return result;
}
const m=JSON.parse(mechanical),c=JSON.parse(javascriptFormatFingerprint(source(head),owner));assert.deepEqual(normalize(m.ast),normalize(c.ast));assert.equal(wrappers,1);assert.deepEqual(m.comments.map(x=>({type:x.type,value:x.value})),c.comments.map(x=>({type:x.type,value:x.value})));
writeFileSync('/tmp/fsusblog-3593/review-boundary/current-migration-provenance.json',JSON.stringify({base,head,formatOnlyCommit:format,laterBlameRegistration:blame,canonicalSyntaxCommit:syntax,originalCommitObjectsPreserved:true,currentMasterOriginalOwnerBytesEqualFormatParent:true,currentHeadBytesEqualCanonicalSyntax:true,mechanicalAstRawTokensAnchoredCommentsEquivalent:true,literalMutationNegativeControlRefused:true,trustedFormatOnlyErrors:errors,fingerprintSha256:createHash('sha256').update(original).digest('hex'),canonicalCompleteAstEqualAfterOnlyImportOrderAndOneTrustedPathsStatementWrapperNormalization:true,canonicalSyntaxNotFormatOnly:true,commentsAndLiteralRawValuesAndAssertionsPreserved:true},null,2)+'\n');
console.log('Current trusted AST/raw-token/anchored-comment proof and canonical syntax equivalence pass; provenance retained');
