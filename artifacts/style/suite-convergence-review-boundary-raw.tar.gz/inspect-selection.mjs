import { execFileSync } from 'node:child_process';
import { selectSourceRegressionTargets } from '/tmp/fsusblog-3593/roster-base-authority/tools/test-matrix/pr-impact-plan.mjs';
const files=execFileSync('git',['diff','--name-only','6e287562b3f861d3eb81dcb23f93e6243205abd8','HEAD'],{cwd:'/workspace/FsusBlog-3593-review',encoding:'utf8'}).trim().split('\n');
console.log(JSON.stringify({files,sourceRegressionTargets:selectSourceRegressionTargets(files)},null,2));
