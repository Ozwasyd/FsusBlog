import {readFileSync,writeFileSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {validatePrContract} from '/tmp/fsusblog-3593/roster-base-authority/tools/governance/change-contract.mjs';
const root='/workspace/FsusBlog-3593-review',scratch='/tmp/fsusblog-3593/review-boundary';
const base='6e287562b3f861d3eb81dcb23f93e6243205abd8',head=execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim();
const changedFiles=execFileSync('git',['diff','--name-only',base,head],{cwd:root,encoding:'utf8'}).trim().split('\n');
const errors=validatePrContract({title:'build(style): prepare exact suite convergence review boundary',body:readFileSync(scratch+'/prepared-narrow-review-body.md','utf8'),labels:['release-note:none'],changedFiles,root,base,head,authorityRoot:'/tmp/fsusblog-3593/roster-base-authority'});
writeFileSync(scratch+'/prepared-metadata-original-gate.json',JSON.stringify({base,head,originalChecker:'/tmp/fsusblog-3593/roster-base-authority/tools/governance/change-contract.mjs',preparedMetadataOnly:true,actualPullRequest:false,errors,exitCode:errors.length?1:0,qualification:false},null,2)+'\n');console.log(JSON.stringify(errors,null,2));if(errors.length)process.exitCode=1;
