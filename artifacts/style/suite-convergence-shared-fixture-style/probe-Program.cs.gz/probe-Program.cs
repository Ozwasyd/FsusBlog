using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using System.Text.Json;
var dir = "/tmp/fsusblog-3593/support-3916";
var results = new List<object>();
foreach (var name in new[] {"AuthoringExtensionRpcBrokerTests", "SecurityAdminPolicyDefaultsTests", "TaxonomyExactMetadataTests", "LifecycleHostedBootstrapServiceTests"})
{
    CompilationUnitSyntax Parse(string suffix)
    {
        var tree = CSharpSyntaxTree.ParseText(File.ReadAllText(Path.Combine(dir, name + suffix)), new CSharpParseOptions(LanguageVersion.Preview));
        if (tree.GetDiagnostics().Any(x => x.Severity == DiagnosticSeverity.Error)) throw new Exception("Parse failed " + name);
        return tree.GetCompilationUnitRoot();
    }
    var before = Parse(".before.cs"); var after = Parse(".after.cs");
    string[] Tokens(CompilationUnitSyntax x) => x.Members.SelectMany(m => m.DescendantTokens()).Select(t => $"{t.RawKind}|{t.Text}|{t.IsMissing}").ToArray();
    string[] Usings(CompilationUnitSyntax x) => x.Usings.Select(u => string.Join("|", u.DescendantTokens().Select(t => t.Text))).Order().ToArray();
    string[] Comments(CompilationUnitSyntax x) => x.DescendantTrivia().Where(t => t.IsKind(SyntaxKind.SingleLineCommentTrivia) || t.IsKind(SyntaxKind.MultiLineCommentTrivia) || t.IsKind(SyntaxKind.SingleLineDocumentationCommentTrivia) || t.IsKind(SyntaxKind.MultiLineDocumentationCommentTrivia)).Select(t => t.ToFullString()).ToArray();
    if (!Tokens(before).SequenceEqual(Tokens(after)) || !Usings(before).SequenceEqual(Usings(after)) || !Comments(before).SequenceEqual(Comments(after))) throw new Exception("Token/using/comment mismatch " + name);
    results.Add(new { name, bodyTokens = Tokens(before).Length, usingSetEqual = true, bodyTokensEqual = true, commentsEqual = true, assertionsAndExpectedLiteralsPreserved = true });
}
Console.WriteLine(JsonSerializer.Serialize(results, new JsonSerializerOptions { WriteIndented = true }));
