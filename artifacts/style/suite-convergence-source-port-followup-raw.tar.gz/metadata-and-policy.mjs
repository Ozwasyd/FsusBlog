import {readFileSync,writeFileSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {validatePrContract,validateRepositoryBlameIgnore} from '/tmp/fsusblog-3593/source-port-base-authority/tools/governance/change-contract.mjs';
import {unsupportedSourceStageFiles} from '/workspace/FsusBlog-3593-source-port/tools/test-matrix/pr-impact-plan.mjs';
const root='/workspace/FsusBlog-3593-source-port',r='/tmp/fsusblog-3593/source-port-followup',base='85aa75af8949401ef9997c5042d22b1071414e0a';
const head=execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim(),files=execFileSync('git',['diff','--name-only',base,head],{cwd:root,encoding:'utf8'}).trim().split('\n');
const errors=validatePrContract({title:'build(style): prepare exact suite convergence review boundary',body:readFileSync(r+'/prepared-independent-followup-review.md','utf8'),labels:['release-note:none'],changedFiles:files,root,base,head,authorityRoot:'/tmp/fsusblog-3593/source-port-base-authority'});
const blameErrors=validateRepositoryBlameIgnore(root);
writeFileSync(r+'/actual-current-original-metadata-and-policy.json',JSON.stringify({base,head,changedFiles:files,originalCheckerAuthority:'/tmp/fsusblog-3593/source-port-base-authority',preparedLocalMetadataOnly:true,actualPullRequest:false,errors,blameErrors,exitCode:errors.length||blameErrors.length?1:0,originalUnsupported:unsupportedSourceStageFiles(files),portConsumed:false,qualification:false},null,2)+'\n');console.log(JSON.stringify({errors,blameErrors,unsupported:unsupportedSourceStageFiles(files)},null,2));if(errors.length||blameErrors.length)process.exitCode=1;
