from pathlib import Path
import subprocess,os,json,hashlib,concurrent.futures,datetime
root=Path('/workspace/FsusBlog-3593-source-port');r=Path('/tmp/fsusblog-3593/source-port-followup');node='/tmp/fsusblog-3593/node24.16/node-v24.16.0-linux-x64/bin/node';env=dict(os.environ,PATH=str(Path(node).parent)+':'+os.environ['PATH'],npm_config_cache='/tmp/fsusblog-3593/npm-cache');base='85aa75af8949401ef9997c5042d22b1071414e0a';head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();results=[]
def install(prefix):
 cmd=['npm','ci','--ignore-scripts','--prefix',prefix];p=subprocess.run(cmd,cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);name='install-'+prefix.replace('/','__');(r/(name+'.log')).write_bytes(p.stdout);row=dict(command=cmd,cwd=str(root),exitCode=p.returncode,log=name+'.log');print(name,p.returncode,flush=True);return row
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool: installs=list(pool.map(install,['tests/tools','tools/frontend/style-toolchain','tools/governance/javascript-format-parser','tools/test-inventory/ts-ast-adapter','tools/test-matrix/schema-validator']))
(r/'official-locked-install-results.json').write_text(json.dumps(installs,indent=2)+'\n');assert all(x['exitCode']==0 for x in installs)
path='tests/fixtures/test-matrix/release-final-execution-target-authority.json';(r/'authority-before-independent-parser.json').write_bytes((root/path).read_bytes());outputs=[]
for i in range(2):
 cmd=[node,'tools/test-matrix/generate-release-final-execution-authority.mjs'];p=subprocess.run(cmd,cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);name='original-authority-pass-'+str(i);(r/(name+'.log')).write_bytes(p.stdout);row=dict(command=cmd,cwd=str(root),sourceInputHead=head,base=base,exitCode=p.returncode,log=name+'.log');results.append(row);(r/'actual-canonical-producer-results.json').write_text(json.dumps(results,indent=2)+'\n');print(name,p.returncode,flush=True)
 if p.returncode!=0:break
 outputs.append((root/path).read_bytes())
if len(outputs)==2:
 assert outputs[0]==outputs[1];(r/'authority-after-independent-parser.json').write_bytes(outputs[0]);(r/'canonical-independent-parser-output-proof.json').write_text(json.dumps(dict(sourceInputHead=head,base=base,twoFreshCanonicalPassesByteIdentical=True,outputSha256=hashlib.sha256(outputs[0]).hexdigest(),portsUnresolvedAndNotPresent=True,oldReviewedBranchFrozen='cdc7b00932a448effdae08b9c9550b59e535a423',handEdited=False,qualification=False),indent=2)+'\n')
