import sys,os,subprocess,json,time
from pathlib import Path
label,cwd,check,*command=sys.argv[1:]
root=Path('/workspace/issue-1889-ui981-delivery/logs')
env=os.environ.copy()
env.update(FSUSBLOG_USE_LOCAL_FSUSUI='1',FSUSBLOG_LOCAL_FSUSUI_ROOT='/workspace/FsusUI-2e0e059')
started=time.time()
with (root/f'{label}-{check}.log').open('wb') as stream:
    result=subprocess.run(command,cwd=cwd,env=env,stdout=stream,stderr=subprocess.STDOUT)
metadata={'label':label,'cwd':cwd,'command':command,'aliasEnvironment':{k:env[k] for k in ['FSUSBLOG_USE_LOCAL_FSUSUI','FSUSBLOG_LOCAL_FSUSUI_ROOT']},'startedUnix':started,'finishedUnix':time.time(),'exitCode':result.returncode,'log':f'{label}-{check}.log'}
(root/f'{label}-{check}.command.json').write_text(json.dumps(metadata,indent=2)+'\n')
print(json.dumps({'label':label,'check':check,'exitCode':result.returncode,'log':metadata['log']}),flush=True)
