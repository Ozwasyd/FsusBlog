const fs=require('node:fs');
const cp=require('node:child_process');
const crypto=require('node:crypto');
const {parse,compileScript,compileTemplate,compileStyle}=require('/workspace/FsusBlog/src/frontend/node_modules/@vue/compiler-sfc');
const ts=require('/workspace/FsusBlog/src/frontend/node_modules/typescript');
const root='/workspace/FsusBlog-1889-ui981';
const ui='/workspace/FsusUI-2e0e059';
const file='src/frontend/src/components/article/ArticleCommentComposer.vue';
const logRoot='/workspace/issue-1889-ui981-delivery/logs';
const get=(rev)=>cp.execFileSync('git',['-C',root,'show',rev+':'+file],{encoding:'utf8'});
const sha256=s=>crypto.createHash('sha256').update(s).digest('hex');
const blob=s=>crypto.createHash('sha1').update(`blob ${Buffer.byteLength(s)}\0`).update(s).digest('hex');
const compile=[];
for(const [name,source] of [['base',get('b302f58a9aaee9f2399d9274157a478f3c2f78fb')],['candidate',fs.readFileSync(root+'/'+file,'utf8')],['upstream-input',fs.readFileSync(ui+'/vue/packages/components/input/src/input.vue','utf8')]]) {
  const {descriptor,errors}=parse(source,{filename:file});
  const script=compileScript(descriptor,{id:'static1889'});
  const template=compileTemplate({id:'static1889',filename:file,source:descriptor.template.content,compilerOptions:{bindingMetadata:script.bindings}});
  const styles=descriptor.styles.map(style=>compileStyle({id:'data-v-static1889',filename:file,source:style.content,scoped:style.scoped}));
  const allErrors=[...errors,...template.errors,...styles.flatMap(v=>v.errors)].map(String);
  const controls=[];
  function walk(n){if(n.type===1&&['ElTabs','ElInput','ElCheckbox','ElTabPane','input','textarea','button'].includes(n.tag))controls.push({tag:n.tag,props:n.props.map(p=>p.type===6?{name:p.name,value:p.value?.content}:{directive:p.name,arg:p.arg?.content,expression:p.exp?.content})});for(const c of n.children||[])walk(c)}
  walk(descriptor.template.ast);
  compile.push({name,blob:blob(source),sourceSha256:sha256(source),scriptSha256:sha256(descriptor.scriptSetup.content),errors:allErrors,controls});
  fs.writeFileSync(logRoot+'/'+name+'-compiled-template.js',template.code);
  if(allErrors.length)process.exitCode=1;
}
const jsx=[];
for(const name of ['tabs.tsx','tab-nav.tsx']) {
 const source=fs.readFileSync(ui+'/vue/packages/components/tabs/src/'+name,'utf8');
 const ast=ts.createSourceFile(name,source,ts.ScriptTarget.Latest,true,ts.ScriptKind.TSX);
 function walk(n){
   if(ts.isJsxSelfClosingElement(n)||ts.isJsxOpeningElement(n)) {
    const attrs=n.attributes.properties.map(p=>p.getText(ast));
    if(n.tagName.getText(ast)==='TabNav'||attrs.includes('role="tablist"'))jsx.push({file:name,tag:n.tagName.getText(ast),attributes:attrs});
   }
   ts.forEachChild(n,walk);
 }
 walk(ast);
 for(const d of ast.parseDiagnostics){console.error(ts.flattenDiagnosticMessageText(d.messageText,'\n'));process.exitCode=1;}
}
const report={mode:'source AST and static compilation only; generated product code is never evaluated',blogBase:'b302f58a9aaee9f2399d9274157a478f3c2f78fb',donor:'b3883458aaceefc3ba6b6fd2a291a38ce55042b7',ui:'2e0e059f193407170d8e23bcc40d59f1af3291f6',compile,tabsForwardingAst:jsx};
fs.writeFileSync(logRoot+'/sfc-ast-report.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({compilation:compile.map(v=>({name:v.name,blob:v.blob,scriptSha256:v.scriptSha256,errors:v.errors})),tabsForwardingAst:jsx},null,2));
