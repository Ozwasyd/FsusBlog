import { toDisplayString as _toDisplayString, createElementVNode as _createElementVNode, createTextVNode as _createTextVNode, resolveComponent as _resolveComponent, withCtx as _withCtx, createVNode as _createVNode, openBlock as _openBlock, createElementBlock as _createElementBlock, createCommentVNode as _createCommentVNode, vModelCheckbox as _vModelCheckbox, withDirectives as _withDirectives, normalizeClass as _normalizeClass, renderList as _renderList, Fragment as _Fragment, withModifiers as _withModifiers, withKeys as _withKeys, createBlock as _createBlock, vModelText as _vModelText } from "vue"

const _hoisted_1 = {
  key: 0,
  class: "mb-3 flex items-center justify-between border border-[var(--fsusblog-panel-border)] bg-[var(--fsusblog-panel-bg)] px-3 py-2 text-xs text-[var(--fsusblog-text-tertiary)]"
}
const _hoisted_2 = {
  key: 1,
  class: "comment-composer-feedback",
  "aria-live": "polite"
}
const _hoisted_3 = { class: "comment-identity-panel" }
const _hoisted_4 = { class: "comment-identity-summary" }
const _hoisted_5 = { class: "comment-identity-copy" }
const _hoisted_6 = { class: "comment-identity-heading" }
const _hoisted_7 = {
  key: 0,
  class: "comment-identity-badge comment-identity-badge--ready"
}
const _hoisted_8 = {
  key: 1,
  class: "comment-identity-badge comment-identity-badge--muted"
}
const _hoisted_9 = {
  key: 0,
  class: "comment-identity-hint"
}
const _hoisted_10 = {
  key: 1,
  class: "comment-identity-hint"
}
const _hoisted_11 = {
  key: 2,
  class: "comment-identity-hint"
}
const _hoisted_12 = ["disabled"]
const _hoisted_13 = {
  key: 2,
  class: "comment-composer-draft",
  "aria-live": "polite"
}
const _hoisted_14 = { key: 0 }
const _hoisted_15 = { key: 1 }
const _hoisted_16 = { class: "comment-composer-draft__actions" }
const _hoisted_17 = {
  key: 3,
  class: "comment-composer-feedback",
  "aria-live": "assertive"
}
const _hoisted_18 = { class: "comment-composer-editor" }
const _hoisted_19 = { class: "comment-composer-toolbar" }
const _hoisted_20 = {
  class: "comment-composer-mode",
  role: "tablist",
  "aria-label": "评论编辑模式"
}
const _hoisted_21 = ["aria-selected", "onClick"]
const _hoisted_22 = { key: 1 }
const _hoisted_23 = {
  key: 2,
  class: "comment-composer-feedback",
  "aria-live": "polite"
}
const _hoisted_24 = { class: "comment-composer-focus__body" }
const _hoisted_25 = { class: "comment-composer-toolbar" }
const _hoisted_26 = {
  class: "comment-composer-mode",
  role: "tablist",
  "aria-label": "扩展编辑模式"
}
const _hoisted_27 = ["aria-selected", "onClick"]
const _hoisted_28 = ["placeholder", "disabled", "onKeydown"]
const _hoisted_29 = { key: 1 }
const _hoisted_30 = { class: "comment-composer-focus__footer" }
const _hoisted_31 = { class: "comment-composer-focus__actions" }

export function render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_ElButton = _resolveComponent("ElButton")
  const _component_ElInput = _resolveComponent("ElInput")
  const _component_RouterLink = _resolveComponent("RouterLink")

  return ($props.isLoggedIn)
    ? (_openBlock(), _createElementBlock("div", {
        key: 0,
        ref: "composerShell",
        class: _normalizeClass($setup.commentDetailTokens.composer.loggedInShell),
        "data-fsus-surface": "reading"
      }, [
        ($props.replyTarget)
          ? (_openBlock(), _createElementBlock("div", _hoisted_1, [
              _createElementVNode("span", null, "正在回复 @" + _toDisplayString($props.replyTarget.author.displayName), 1 /* TEXT */),
              _createVNode(_component_ElButton, {
                link: "",
                onClick: _cache[0] || (_cache[0] = $event => (_ctx.$emit('cancel-reply')))
              }, {
                default: _withCtx(() => [...(_cache[6] || (_cache[6] = [
                  _createTextVNode(" 取消 ", -1 /* CACHED */)
                ]))]),
                _: 1 /* STABLE */
              })
            ]))
          : _createCommentVNode("v-if", true),
        (!$props.publicCommentsEnabled && !$props.anonymousCommentsEnabled)
          ? (_openBlock(), _createElementBlock("p", _hoisted_2, " 当前文章或讨论串已暂停新评论，已有评论仍可阅读。 "))
          : _createCommentVNode("v-if", true),
        _createElementVNode("div", _hoisted_3, [
          _createElementVNode("div", _hoisted_4, [
            _createElementVNode("div", _hoisted_5, [
              _createElementVNode("div", _hoisted_6, [
                _cache[7] || (_cache[7] = _createElementVNode("span", { class: "comment-identity-label" }, "评论身份", -1 /* CACHED */)),
                ($setup.effectiveAnonymousCommentsEnabled)
                  ? (_openBlock(), _createElementBlock("span", _hoisted_7, _toDisplayString($setup.anonymousStatusText), 1 /* TEXT */))
                  : (_openBlock(), _createElementBlock("span", _hoisted_8, " 仅署名 "))
              ]),
              ($setup.anonymousUnavailableMessage)
                ? (_openBlock(), _createElementBlock("p", _hoisted_9, " 强匿名发布暂不可用，评论不会自动降级发送；你仍可明确选择公开署名。 "))
                : _createCommentVNode("v-if", true),
              ($setup.publicIdentityModel)
                ? (_openBlock(), _createElementBlock("p", _hoisted_10, " 公开发布后，其他人会看到你的公开名称。 "))
                : ($setup.effectiveAnonymousCommentsEnabled)
                  ? (_openBlock(), _createElementBlock("p", _hoisted_11, _toDisplayString($setup.anonymousQuotaHint) + "删除或审核拒绝不会返还额度；凭据更新后按新周期重新计算。 ", 1 /* TEXT */))
                  : _createCommentVNode("v-if", true)
            ]),
            _createElementVNode("label", {
              class: _normalizeClass(["comment-identity-toggle", { 'is-disabled': $setup.publicIdentityDisabled }])
            }, [
              _withDirectives(_createElementVNode("input", {
                "onUpdate:modelValue": _cache[1] || (_cache[1] = $event => (($setup.publicIdentityModel) = $event)),
                class: "comment-identity-toggle__input",
                type: "checkbox",
                disabled: $setup.publicIdentityDisabled
              }, null, 8 /* PROPS */, _hoisted_12), [
                [_vModelCheckbox, $setup.publicIdentityModel]
              ]),
              _cache[8] || (_cache[8] = _createElementVNode("span", {
                class: "comment-identity-toggle__box",
                "aria-hidden": "true"
              }, null, -1 /* CACHED */)),
              _cache[9] || (_cache[9] = _createElementVNode("span", { class: "comment-identity-toggle__label" }, "公开显示我的名称", -1 /* CACHED */))
            ], 2 /* CLASS */)
          ])
        ]),
        ($setup.restoredDraftVisible && $setup.localDraft)
          ? (_openBlock(), _createElementBlock("div", _hoisted_13, [
              ($setup.draftNeedsReview)
                ? (_openBlock(), _createElementBlock("span", _hoisted_14, " 评论策略已更新。请先审查草稿，发布身份不会自动恢复。 "))
                : (_openBlock(), _createElementBlock("span", _hoisted_15, "已恢复公开草稿" + _toDisplayString($setup.draftSavedAtText ? ` ${$setup.draftSavedAtText}` : ''), 1 /* TEXT */)),
              _createElementVNode("span", _hoisted_16, [
                ($setup.draftNeedsReview)
                  ? (_openBlock(), _createElementBlock("button", {
                      key: 0,
                      type: "button",
                      onClick: $setup.reviewCommentDraft
                    }, "审查草稿"))
                  : _createCommentVNode("v-if", true),
                _createElementVNode("button", {
                  type: "button",
                  onClick: $setup.discardCommentDraft
                }, "丢弃")
              ])
            ]))
          : _createCommentVNode("v-if", true),
        ($setup.draftPrivacyBlocked)
          ? (_openBlock(), _createElementBlock("p", _hoisted_17, " 无法确认旧草稿已从浏览器存储清除；强匿名发布已暂停。你可以继续公开发布，或先清理站点数据。 "))
          : _createCommentVNode("v-if", true),
        _createElementVNode("div", _hoisted_18, [
          _createElementVNode("div", _hoisted_19, [
            _createElementVNode("div", _hoisted_20, [
              (_openBlock(), _createElementBlock(_Fragment, null, _renderList($setup.commentComposerModeOptions, (option) => {
                return _createElementVNode("button", {
                  key: option.value,
                  type: "button",
                  class: _normalizeClass(["comment-composer-mode__item", { 'is-active': $setup.commentComposerMode === option.value }]),
                  role: "tab",
                  "aria-selected": $setup.commentComposerMode === option.value,
                  onClick: $event => ($setup.commentComposerMode = option.value)
                }, _toDisplayString(option.label), 11 /* TEXT, CLASS, PROPS */, _hoisted_21)
              }), 64 /* STABLE_FRAGMENT */))
            ]),
            _createVNode(_component_ElButton, {
              class: "comment-composer-focus",
              text: "",
              disabled: $setup.composerInputDisabled,
              onClick: $setup.openFocusMode
            }, {
              default: _withCtx(() => [...(_cache[10] || (_cache[10] = [
                _createTextVNode(" 扩展编辑 ", -1 /* CACHED */)
              ]))]),
              _: 1 /* STABLE */
            }, 8 /* PROPS */, ["disabled"])
          ]),
          ($setup.commentComposerMode === 'write')
            ? (_openBlock(), _createBlock(_component_ElInput, {
                key: 0,
                ref: "editorInputRef",
                modelValue: $setup.contentModel,
                "onUpdate:modelValue": _cache[2] || (_cache[2] = $event => (($setup.contentModel) = $event)),
                "csp-safe": true,
                type: "textarea",
                rows: 3,
                autosize: { minRows: 3, maxRows: 8 },
                resize: "none",
                "aria-label": "发表评论",
                placeholder: $setup.placeholderText,
                disabled: $setup.composerInputDisabled,
                onFocus: $setup.notifyPrivacyIntent,
                onKeydown: [
                  _withKeys(_withModifiers($setup.requestSubmit, ["ctrl"]), ["enter"]),
                  _withKeys(_withModifiers($setup.requestSubmit, ["meta"]), ["enter"])
                ]
              }, null, 8 /* PROPS */, ["modelValue", "placeholder", "disabled", "onKeydown"]))
            : (_openBlock(), _createElementBlock("div", {
                key: 1,
                class: _normalizeClass(["comment-composer-preview", { 'is-empty': !$setup.contentModel.trim() }])
              }, [
                ($setup.contentModel.trim())
                  ? (_openBlock(), _createBlock($setup["CommentMarkdownRenderer"], {
                      key: 0,
                      content: $setup.contentModel,
                      collapsible: false
                    }, null, 8 /* PROPS */, ["content"]))
                  : (_openBlock(), _createElementBlock("span", _hoisted_22, "暂无内容"))
              ], 2 /* CLASS */)),
          ($setup.markdownFeedbackText)
            ? (_openBlock(), _createElementBlock("p", _hoisted_23, _toDisplayString($setup.markdownFeedbackText), 1 /* TEXT */))
            : _createCommentVNode("v-if", true),
          _createElementVNode("div", {
            class: _normalizeClass(["comment-composer-metrics", { 'is-warning': $setup.commentLimitWarning }]),
            "aria-live": "polite"
          }, [
            _createElementVNode("span", null, _toDisplayString($setup.commentCharCount) + " / " + _toDisplayString($setup.commentPolicy.maxChars) + " 字", 1 /* TEXT */),
            _createElementVNode("span", null, _toDisplayString($setup.commentUtf8Bytes) + " / " + _toDisplayString($setup.commentPolicy.maxUtf8Bytes) + " bytes", 1 /* TEXT */)
          ], 2 /* CLASS */)
        ]),
        _createElementVNode("div", {
          class: _normalizeClass($setup.commentDetailTokens.composer.submitWrap)
        }, [
          _createVNode(_component_ElButton, {
            type: "primary",
            onClick: $setup.requestSubmit,
            disabled: $setup.submitDisabled,
            "aria-disabled": $setup.submitDisabled
          }, {
            default: _withCtx(() => [
              _createTextVNode(_toDisplayString($setup.composerUi.submitBusyText), 1 /* TEXT */)
            ]),
            _: 1 /* STABLE */
          }, 8 /* PROPS */, ["disabled", "aria-disabled"])
        ], 2 /* CLASS */),
        _createVNode($setup["FsusDialog"], {
          modelValue: $setup.focusModeVisible,
          "onUpdate:modelValue": _cache[5] || (_cache[5] = $event => (($setup.focusModeVisible) = $event)),
          class: "comment-composer-focus-dialog",
          title: "扩展编辑评论",
          width: "min(92vw, 48rem)",
          onClosed: $setup.closeFocusMode
        }, {
          footer: _withCtx(() => [
            _createElementVNode("div", _hoisted_30, [
              _createElementVNode("div", {
                class: _normalizeClass(["comment-composer-metrics", { 'is-warning': $setup.commentLimitWarning }])
              }, [
                _createElementVNode("span", null, _toDisplayString($setup.commentCharCount) + " / " + _toDisplayString($setup.commentPolicy.maxChars) + " 字", 1 /* TEXT */),
                _createElementVNode("span", null, _toDisplayString($setup.commentUtf8Bytes) + " / " + _toDisplayString($setup.commentPolicy.maxUtf8Bytes) + " bytes", 1 /* TEXT */)
              ], 2 /* CLASS */),
              _createElementVNode("div", _hoisted_31, [
                _createVNode(_component_ElButton, {
                  class: "comment-composer-focus__action",
                  onClick: _cache[4] || (_cache[4] = $event => ($setup.focusModeVisible = false))
                }, {
                  default: _withCtx(() => [...(_cache[11] || (_cache[11] = [
                    _createTextVNode("收起", -1 /* CACHED */)
                  ]))]),
                  _: 1 /* STABLE */
                }),
                _createVNode(_component_ElButton, {
                  class: "comment-composer-focus__action",
                  type: "primary",
                  disabled: $setup.submitDisabled,
                  onClick: $setup.requestSubmit
                }, {
                  default: _withCtx(() => [
                    _createTextVNode(_toDisplayString($setup.composerUi.submitBusyText), 1 /* TEXT */)
                  ]),
                  _: 1 /* STABLE */
                }, 8 /* PROPS */, ["disabled"])
              ])
            ])
          ]),
          default: _withCtx(() => [
            _createElementVNode("div", _hoisted_24, [
              _createElementVNode("div", _hoisted_25, [
                _createElementVNode("div", _hoisted_26, [
                  (_openBlock(), _createElementBlock(_Fragment, null, _renderList($setup.commentComposerModeOptions, (option) => {
                    return _createElementVNode("button", {
                      key: option.value,
                      type: "button",
                      class: _normalizeClass(["comment-composer-mode__item", { 'is-active': $setup.commentComposerMode === option.value }]),
                      role: "tab",
                      "aria-selected": $setup.commentComposerMode === option.value,
                      onClick: $event => ($setup.commentComposerMode = option.value)
                    }, _toDisplayString(option.label), 11 /* TEXT, CLASS, PROPS */, _hoisted_27)
                  }), 64 /* STABLE_FRAGMENT */))
                ])
              ]),
              ($setup.commentComposerMode === 'write')
                ? _withDirectives((_openBlock(), _createElementBlock("textarea", {
                    key: 0,
                    ref: "focusEditorInputRef",
                    "onUpdate:modelValue": _cache[3] || (_cache[3] = $event => (($setup.contentModel) = $event)),
                    class: "comment-composer-focus__textarea",
                    rows: "12",
                    "aria-label": "专注撰写评论",
                    placeholder: $setup.placeholderText,
                    disabled: $setup.composerInputDisabled,
                    onFocus: $setup.notifyPrivacyIntent,
                    onKeydown: [
                      _withKeys(_withModifiers($setup.requestSubmit, ["ctrl"]), ["enter"]),
                      _withKeys(_withModifiers($setup.requestSubmit, ["meta"]), ["enter"])
                    ]
                  }, null, 40 /* PROPS, NEED_HYDRATION */, _hoisted_28)), [
                    [_vModelText, $setup.contentModel]
                  ])
                : (_openBlock(), _createElementBlock("div", {
                    key: 1,
                    class: _normalizeClass(["comment-composer-preview comment-composer-focus__preview", { 'is-empty': !$setup.contentModel.trim() }])
                  }, [
                    ($setup.contentModel.trim())
                      ? (_openBlock(), _createBlock($setup["CommentMarkdownRenderer"], {
                          key: 0,
                          content: $setup.contentModel,
                          collapsible: false
                        }, null, 8 /* PROPS */, ["content"]))
                      : (_openBlock(), _createElementBlock("span", _hoisted_29, "暂无内容"))
                  ], 2 /* CLASS */))
            ])
          ]),
          _: 1 /* STABLE */
        }, 8 /* PROPS */, ["modelValue"])
      ], 2 /* CLASS */))
    : (_openBlock(), _createElementBlock("section", {
        key: 1,
        class: _normalizeClass($setup.commentDetailTokens.composer.guestShell),
        "data-fsus-surface": "reading",
        "aria-label": "评论登录提示"
      }, [
        _createElementVNode("span", {
          class: _normalizeClass($setup.commentDetailTokens.composer.guestText)
        }, _toDisplayString($setup.composerUi.guestText), 3 /* TEXT, CLASS */),
        _createVNode(_component_RouterLink, {
          to: $setup.composerUi.guestLoginRoute,
          class: _normalizeClass($setup.commentDetailTokens.composer.guestLink)
        }, {
          default: _withCtx(() => [
            _createTextVNode(_toDisplayString($setup.composerUi.guestActionText), 1 /* TEXT */)
          ]),
          _: 1 /* STABLE */
        }, 8 /* PROPS */, ["to", "class"])
      ], 2 /* CLASS */))
}