import { createCommentVNode as _createCommentVNode, renderSlot as _renderSlot, normalizeClass as _normalizeClass, openBlock as _openBlock, createElementBlock as _createElementBlock, resolveDynamicComponent as _resolveDynamicComponent, createBlock as _createBlock, withCtx as _withCtx, createElementVNode as _createElementVNode, mergeProps as _mergeProps, Fragment as _Fragment, createVNode as _createVNode, toHandlers as _toHandlers, toDisplayString as _toDisplayString } from "vue"

const _hoisted_1 = ["role"]
const _hoisted_2 = ["id", "type", "disabled", "readonly", "autocomplete", "tabindex", "aria-label", "placeholder", "form", "autofocus"]
const _hoisted_3 = ["id", "tabindex", "disabled", "readonly", "autocomplete", "aria-label", "placeholder", "form", "autofocus"]

export function render(_ctx, _cache, $props, $setup, $data, $options) {
  return (_openBlock(), _createElementBlock("div", _mergeProps($setup.containerBindingAttrs, {
    class: $setup.containerKls,
    role: _ctx.containerRole,
    onMouseenter: $setup.handleMouseEnter,
    onMouseleave: $setup.handleMouseLeave
  }), [
    _createCommentVNode(" input "),
    (_ctx.type !== 'textarea')
      ? (_openBlock(), _createElementBlock(_Fragment, { key: 0 }, [
          _createCommentVNode(" prepend slot "),
          (_ctx.$slots.prepend)
            ? (_openBlock(), _createElementBlock("div", {
                key: 0,
                class: _normalizeClass($setup.nsInput.be('group', 'prepend'))
              }, [
                _renderSlot(_ctx.$slots, "prepend")
              ], 2 /* CLASS */))
            : _createCommentVNode("v-if", true),
          _createElementVNode("div", {
            ref: "wrapperRef",
            class: _normalizeClass($setup.wrapperKls)
          }, [
            _createCommentVNode(" prefix slot "),
            (_ctx.$slots.prefix || _ctx.prefixIcon)
              ? (_openBlock(), _createElementBlock("span", {
                  key: 0,
                  class: _normalizeClass($setup.nsInput.e('prefix'))
                }, [
                  _createElementVNode("span", {
                    class: _normalizeClass($setup.nsInput.e('prefix-inner'))
                  }, [
                    _renderSlot(_ctx.$slots, "prefix"),
                    (_ctx.prefixIcon)
                      ? (_openBlock(), _createBlock($setup["ElIcon"], {
                          key: 0,
                          class: _normalizeClass($setup.nsInput.e('icon'))
                        }, {
                          default: _withCtx(() => [
                            (_openBlock(), _createBlock(_resolveDynamicComponent(_ctx.prefixIcon)))
                          ]),
                          _: 1 /* STABLE */
                        }, 8 /* PROPS */, ["class"]))
                      : _createCommentVNode("v-if", true)
                  ], 2 /* CLASS */)
                ], 2 /* CLASS */))
              : _createCommentVNode("v-if", true),
            _createElementVNode("input", _mergeProps({
              id: $setup.inputId,
              ref: "input",
              class: $setup.nsInput.e('inner')
            }, $setup.inputBindingAttrs, {
              type: _ctx.showPassword ? ($setup.passwordVisible ? 'text' : 'password') : _ctx.type,
              disabled: $setup.inputDisabled,
              readonly: _ctx.readonly,
              autocomplete: _ctx.autocomplete,
              tabindex: _ctx.tabindex,
              "aria-label": $setup.nativeAriaLabel,
              placeholder: _ctx.placeholder,
              form: $setup.props.form,
              autofocus: $setup.props.autofocus,
              onCompositionstart: $setup.handleCompositionStart,
              onCompositionupdate: $setup.handleCompositionUpdate,
              onCompositionend: $setup.handleCompositionEnd,
              onInput: $setup.handleInput,
              onFocus: _cache[0] || (_cache[0] = (...args) => ($setup.handleFocus && $setup.handleFocus(...args))),
              onBlur: _cache[1] || (_cache[1] = (...args) => ($setup.handleBlur && $setup.handleBlur(...args))),
              onChange: $setup.handleChange,
              onKeydown: $setup.handleKeydown
            }), null, 16 /* FULL_PROPS */, _hoisted_2),
            _createCommentVNode(" suffix slot "),
            ($setup.suffixVisible)
              ? (_openBlock(), _createElementBlock("span", {
                  key: 1,
                  class: _normalizeClass($setup.nsInput.e('suffix'))
                }, [
                  _createElementVNode("span", {
                    class: _normalizeClass($setup.nsInput.e('suffix-inner'))
                  }, [
                    (!$setup.showClear || !$setup.showPwdVisible || !$setup.isWordLimitVisible)
                      ? (_openBlock(), _createElementBlock(_Fragment, { key: 0 }, [
                          _renderSlot(_ctx.$slots, "suffix"),
                          (_ctx.suffixIcon)
                            ? (_openBlock(), _createBlock($setup["ElIcon"], {
                                key: 0,
                                class: _normalizeClass($setup.nsInput.e('icon'))
                              }, {
                                default: _withCtx(() => [
                                  (_openBlock(), _createBlock(_resolveDynamicComponent(_ctx.suffixIcon)))
                                ]),
                                _: 1 /* STABLE */
                              }, 8 /* PROPS */, ["class"]))
                            : _createCommentVNode("v-if", true)
                        ], 64 /* STABLE_FRAGMENT */))
                      : _createCommentVNode("v-if", true),
                    ($setup.showClear)
                      ? (_openBlock(), _createBlock($setup["ElIcon"], _mergeProps({
                          key: 1,
                          class: [$setup.nsInput.e('icon'), $setup.nsInput.e('clear')]
                        }, _toHandlers($setup.clearIconEvents)), {
                          default: _withCtx(() => [
                            _createVNode($setup["CircleClose"])
                          ]),
                          _: 1 /* STABLE */
                        }, 16 /* FULL_PROPS */, ["class"]))
                      : _createCommentVNode("v-if", true),
                    ($setup.showPwdVisible)
                      ? (_openBlock(), _createBlock($setup["ElIcon"], _mergeProps({
                          key: 2,
                          class: [$setup.nsInput.e('icon'), $setup.nsInput.e('password')]
                        }, _toHandlers($setup.passwordIconEvents)), {
                          default: _withCtx(() => [
                            (_openBlock(), _createBlock(_resolveDynamicComponent($setup.passwordIcon)))
                          ]),
                          _: 1 /* STABLE */
                        }, 16 /* FULL_PROPS */, ["class"]))
                      : _createCommentVNode("v-if", true),
                    ($setup.isWordLimitVisible)
                      ? (_openBlock(), _createElementBlock("span", {
                          key: 3,
                          class: _normalizeClass($setup.nsInput.e('count'))
                        }, _toDisplayString($setup.textLength) + " / " + _toDisplayString($setup.attrs.maxlength), 3 /* TEXT, CLASS */))
                      : _createCommentVNode("v-if", true),
                    ($setup.validateState && $setup.validateIcon && $setup.needStatusIcon)
                      ? (_openBlock(), _createBlock($setup["ElIcon"], {
                          key: 4,
                          class: _normalizeClass([
                $setup.nsInput.e('icon'),
                $setup.nsInput.e('validateIcon'),
                $setup.nsInput.is('loading', $setup.validateState === 'validating'),
              ])
                        }, {
                          default: _withCtx(() => [
                            (_openBlock(), _createBlock(_resolveDynamicComponent($setup.validateIcon)))
                          ]),
                          _: 1 /* STABLE */
                        }, 8 /* PROPS */, ["class"]))
                      : _createCommentVNode("v-if", true)
                  ], 2 /* CLASS */)
                ], 2 /* CLASS */))
              : _createCommentVNode("v-if", true)
          ], 2 /* CLASS */),
          _createCommentVNode(" append slot "),
          (_ctx.$slots.append)
            ? (_openBlock(), _createElementBlock("div", {
                key: 1,
                class: _normalizeClass($setup.nsInput.be('group', 'append'))
              }, [
                _renderSlot(_ctx.$slots, "append")
              ], 2 /* CLASS */))
            : _createCommentVNode("v-if", true)
        ], 64 /* STABLE_FRAGMENT */))
      : (_openBlock(), _createElementBlock(_Fragment, { key: 1 }, [
          _createCommentVNode(" textarea "),
          _createElementVNode("textarea", _mergeProps({
            id: $setup.inputId,
            ref: "textarea",
            class: $setup.nsTextarea.e('inner')
          }, $setup.textareaBindingAttrs, {
            tabindex: _ctx.tabindex,
            disabled: $setup.inputDisabled,
            readonly: _ctx.readonly,
            autocomplete: _ctx.autocomplete,
            "aria-label": $setup.nativeAriaLabel,
            placeholder: _ctx.placeholder,
            form: $setup.props.form,
            autofocus: $setup.props.autofocus,
            onCompositionstart: $setup.handleCompositionStart,
            onCompositionupdate: $setup.handleCompositionUpdate,
            onCompositionend: $setup.handleCompositionEnd,
            onInput: $setup.handleInput,
            onFocus: _cache[2] || (_cache[2] = (...args) => ($setup.handleFocus && $setup.handleFocus(...args))),
            onBlur: _cache[3] || (_cache[3] = (...args) => ($setup.handleBlur && $setup.handleBlur(...args))),
            onChange: $setup.handleChange,
            onKeydown: $setup.handleKeydown
          }), null, 16 /* FULL_PROPS */, _hoisted_3),
          ($setup.isWordLimitVisible)
            ? (_openBlock(), _createElementBlock("span", _mergeProps({ key: 0 }, _ctx.cspSafe ? {} : { style: $setup.countStyle }, {
                class: $setup.nsInput.e('count')
              }), _toDisplayString($setup.textLength) + " / " + _toDisplayString($setup.attrs.maxlength), 17 /* TEXT, FULL_PROPS */))
            : _createCommentVNode("v-if", true)
        ], 64 /* STABLE_FRAGMENT */))
  ], 16 /* FULL_PROPS */, _hoisted_1))
}